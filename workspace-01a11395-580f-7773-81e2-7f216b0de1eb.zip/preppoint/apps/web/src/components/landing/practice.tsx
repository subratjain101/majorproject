import { Card, Chip, SectionHeading } from "@/components/ui/primitives";
import { Section } from "./chrome";

/* ==========================================================================
   Landing sections: the practice loop -- gaps, adaptive interview, scorecard.
   ========================================================================== */

export function SkillGapRoadmapSection() {
  const gaps = [
    {
      severity: "HIGH",
      color: "var(--color-severity-high)",
      skill: "System Design",
      why: "Required by your target role at 95% importance, and interviewers commonly probe it — but your resume carries only a passing mention.",
      evidence: ["Mentioned service boundaries once in a project bullet", "No dated evidence of designing at scale"],
      actions: [
        "Learn system design fundamentals end to end (2–5 hours)",
        "Complete 3 architecture exercises with written trade-offs",
        "Take a backend DSA assessment",
        "Re-run the adaptive interview",
      ],
      effort: "≈4 focused hours",
    },
    {
      severity: "MEDIUM",
      color: "var(--color-severity-medium)",
      skill: "Docker",
      why: "Preferred for the role. You have containerised one service, which sits just below the proficiency bar the role assumes.",
      evidence: ["Containerised the billing service (2023)"],
      actions: [
        "Deepen Docker beyond single-container builds (6–10 hours)",
        "Add a compose-based multi-service project",
      ],
      effort: "≈8 hours",
    },
    {
      severity: "LOW",
      color: "var(--color-severity-low)",
      skill: "Kubernetes",
      why: "Nice-to-have at 40% importance. Absent entirely, but cheap to defer relative to the required gaps above it.",
      evidence: [],
      actions: ["Learn fundamentals when the required gaps are closed (17–26 hours)"],
      effort: "Defer",
    },
  ];

  return (
    <Section id="skill-gap-roadmap">
      <SectionHeading
        eyebrow="Skill gap roadmap"
        title="Not &ldquo;missing Python&rdquo; — a plan you can start tonight."
        description="Severity blends how much the role cares with how big your gap actually is, then requirement kind caps the result: a missing nice-to-have can never outrank a missing requirement. Order respects prerequisites, so you are never told to learn orchestration before containers."
      />

      <div className="mt-10 flex flex-col gap-4">
        {gaps.map((gap) => (
          <Card key={gap.skill} className="overflow-hidden">
            <div className="grid gap-5 p-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)]">
              <div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <span
                    className="rounded-[var(--radius-pill)] px-2.5 py-0.5 text-[0.6875rem] font-bold tracking-[0.06em] text-[var(--color-void)]"
                    style={{ backgroundColor: gap.color }}
                  >
                    {gap.severity}
                  </span>
                  <h3 className="text-base font-semibold text-[var(--color-foreground)]">{gap.skill}</h3>
                  <Chip tone="muted" className="ml-auto">
                    {gap.effort}
                  </Chip>
                </div>

                <div className="mt-4">
                  <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
                    Why this severity
                  </p>
                  <p className="mt-1.5 text-sm leading-relaxed text-[var(--color-muted)]">{gap.why}</p>
                </div>

                <div className="mt-4">
                  <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
                    Evidence we found
                  </p>
                  {gap.evidence.length ? (
                    <ul className="mt-1.5 flex flex-col gap-1.5">
                      {gap.evidence.map((item) => (
                        <li key={item} className="flex gap-2 text-xs text-[var(--color-foreground-soft)]">
                          <span aria-hidden className="mt-1.5 size-1 shrink-0 rounded-full bg-[var(--color-success)]" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="mt-1.5 text-xs italic text-[var(--color-not-assessed)]">
                      No evidence found in your resume or practice history.
                    </p>
                  )}
                </div>
              </div>

              <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/60 p-4">
                <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-accent-bright)]">
                  Recommended actions
                </p>
                <ol className="mt-3 flex flex-col gap-2.5">
                  {gap.actions.map((action, index) => (
                    <li key={action} className="flex gap-2.5">
                      <span className="mt-px grid size-4.5 shrink-0 place-items-center rounded border border-[var(--color-border-strong)] font-mono text-[0.5625rem] text-[var(--color-muted)]">
                        {index + 1}
                      </span>
                      <span className="text-xs leading-relaxed text-[var(--color-foreground-soft)]">{action}</span>
                    </li>
                  ))}
                </ol>
                <p className="mt-3.5 border-t border-[var(--color-border)] pt-3 text-[0.6875rem] text-[var(--color-muted-deep)]">
                  Reassessment: re-run the match, then take an adaptive interview. Both feed back into this report.
                </p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </Section>
  );
}

export function AdaptiveInterviewSection() {
  const turns = [
    { n: 1, difficulty: "MEDIUM", score: 8.1, theta: "0.53 → 0.61", action: "Raise", color: "var(--color-success)" },
    { n: 2, difficulty: "HARD", score: 7.4, theta: "0.61 → 0.66", action: "Hold", color: "var(--color-muted)" },
    { n: 3, difficulty: "HARD", score: 4.6, theta: "0.66 → 0.59", action: "Lower", color: "var(--color-warning)" },
    { n: 4, difficulty: "MEDIUM", score: 9.0, theta: "0.59 → 0.65", action: "Raise", color: "var(--color-success)" },
  ];

  return (
    <Section id="adaptive-interview" muted>
      <div className="grid gap-10 lg:grid-cols-[1fr_1fr] lg:items-start">
        <div>
          <SectionHeading
            eyebrow="Adaptive interview"
            title="The interview responds to how you are actually doing."
            description="Not a fixed questionnaire. Each answer updates an estimate of your ability, and the next question is chosen to sit where the information is greatest — hard enough to be informative, never so hard that failure teaches us nothing."
          />

          <div className="mt-6 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/60 p-4">
            <p className="font-mono text-xs text-[var(--color-accent-bright)]">
              E<t>t</t> = 1 / (1 + e<sup>−a(θ<sub>t</sub> − d<sub>t</sub>)</sup>)
            </p>
            <p className="mt-2 font-mono text-xs text-[var(--color-electric-bright)]">
              θ<t>t+1</t> = clip(θ<t>t</t> + η(s<t>t</t> − E<t>t</t>), 0, 1)
            </p>
            <p className="mt-3 text-xs leading-relaxed text-[var(--color-muted)]">
              The update is driven by surprise: beating the model&rsquo;s expectation of you moves your estimate more
              than an answer it already predicted. A first answer cannot redefine the session — updates are tempered
              through a warm-up.
            </p>
          </div>

          <ul className="mt-5 flex flex-col gap-2.5">
            {[
              "Score ≥ 7.8 raises difficulty. Below 5.0 lowers it. Between them, difficulty holds.",
              "Hard is the ceiling and Easy is the floor — neither is ever exceeded.",
              "No question is asked twice in a session.",
              "Answers we cannot score with evidence do not steer the interview at all.",
            ].map((rule) => (
              <li key={rule} className="flex gap-2.5 text-sm text-[var(--color-muted)]">
                <span aria-hidden className="mt-1.5 size-1.5 shrink-0 rounded-full bg-[var(--color-electric)]" />
                {rule}
              </li>
            ))}
          </ul>
        </div>

        <Card raised className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--color-border)] bg-[var(--color-surface-raised)] px-5 py-3">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Session trace</h3>
            <span className="flex items-center gap-1.5 text-[0.6875rem] font-medium text-[var(--color-success)]">
              <span aria-hidden className="live-dot size-1.5 rounded-full bg-current" />
              Adapting
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <caption className="sr-only">Adaptive difficulty trace across four interview questions</caption>
              <thead>
                <tr className="border-b border-[var(--color-border)] text-[0.6875rem] uppercase tracking-[0.06em] text-[var(--color-muted-deep)]">
                  <th scope="col" className="px-5 py-2.5 font-semibold">#</th>
                  <th scope="col" className="px-3 py-2.5 font-semibold">Difficulty</th>
                  <th scope="col" className="px-3 py-2.5 font-semibold">Score</th>
                  <th scope="col" className="px-3 py-2.5 font-semibold">θ</th>
                  <th scope="col" className="px-5 py-2.5 font-semibold">Transition</th>
                </tr>
              </thead>
              <tbody className="tabular">
                {turns.map((turn) => (
                  <tr key={turn.n} className="border-b border-[var(--color-border)]/60 last:border-0">
                    <td className="px-5 py-3 font-mono text-[var(--color-muted-deep)]">{turn.n}</td>
                    <td className="px-3 py-3 text-[var(--color-foreground-soft)]">{turn.difficulty}</td>
                    <td className="px-3 py-3 font-semibold text-[var(--color-foreground)]">{turn.score.toFixed(1)}</td>
                    <td className="px-3 py-3 font-mono text-[var(--color-muted)]">{turn.theta}</td>
                    <td className="px-5 py-3" style={{ color: turn.color }}>
                      {turn.action}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="border-t border-[var(--color-border)] p-5">
            <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
              Why question 4 was Medium, not Hard
            </p>
            <p className="mt-2 text-xs leading-relaxed text-[var(--color-muted)]">
              Question 3 scored 4.6, which is below the 5.0 threshold, so difficulty dropped and your ability estimate
              fell from 0.66 to 0.59. Question 4 sits at the Medium band where your expected score is closest to 50% —
              the point of maximum information. You scored 9.0, so the next band raises again.
            </p>
          </div>
        </Card>
      </div>
    </Section>
  );
}

export function TransparentScorecardSection() {
  const dimensions = [
    {
      label: "Technical correctness",
      weight: "40%",
      score: 82,
      quote: "I'd put a thin gateway in front of the write path so the API layer stays stateless",
      rationale: "Correct high-level architecture, and the stateless claim is right. Edge-case handling around partial failure was not addressed.",
      improvement: "Practise distributed caching and failure recovery patterns.",
    },
    {
      label: "Problem solving",
      weight: "30%",
      score: 71,
      quote: "so we could either shard by merchant or by time — sharding by merchant keeps a merchant's writes on one node",
      rationale: "Two options compared explicitly, and the sharding trade-off was reasoned correctly. No failure-mode analysis for a hot merchant.",
      improvement: "Add a hot-key or skew analysis to at least one design answer.",
    },
    {
      label: "Communication",
      weight: "20%",
      score: 79,
      quote: "Let me restate the constraint first: we need idempotency across retries",
      rationale: "Ordered and followable. Restating the constraint before answering made the reasoning easy to track.",
      improvement: "State the conclusion explicitly before walking through the detail.",
    },
    {
      label: "Role relevance",
      weight: "10%",
      score: 74,
      quote: "in a payments context that matters because double-charging is the failure everyone remembers",
      rationale: "Grounded in the target role's domain rather than generic textbook material.",
      improvement: "Reference the role's likely transaction volume to sharpen the scale discussion.",
    },
  ];

  return (
    <Section id="transparent-scorecard">
      <SectionHeading
        eyebrow="Transparent scorecard"
        title="Every score shows the sentence it came from."
        description="Each dimension carries its weight, the quoted evidence it was judged on, the rationale, and one concrete improvement. The overall score is the weighted mean of the dimensions we could actually assess."
      />

      <Card className="mt-10 overflow-hidden">
        {/* Disclaimer: always present, never dismissible, never shrunk. */}
        <div className="border-b border-[color-mix(in_oklab,var(--color-warning)_30%,transparent)] bg-[color-mix(in_oklab,var(--color-warning)_8%,transparent)] px-5 py-3">
          <p className="text-xs font-semibold tracking-[0.04em] text-[var(--color-warning)]">
            PRACTICE FEEDBACK — NOT A HIRING DECISION
          </p>
          <p className="mt-1 text-xs leading-relaxed text-[var(--color-muted)]">
            This measures one practice exercise, reviewed by no human. No employer can see it unless you share it.
          </p>
        </div>

        <div className="grid lg:grid-cols-[220px_1fr]">
          <div className="border-b border-[var(--color-border)] p-5 lg:border-b-0 lg:border-r">
            <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
              Overall
            </p>
            <div className="mt-2 flex items-end gap-1.5">
              <span className="score-display text-5xl font-semibold text-[var(--color-foreground)]">76</span>
              <span className="pb-1.5 text-base text-[var(--color-muted)]">/100</span>
            </div>
            <dl className="mt-5 flex flex-col gap-2 text-[0.6875rem]">
              {[
                ["Type", "Adaptive interview"],
                ["Rubric", "interview-rubric-2024.1"],
                ["Prompt", "interview-eval-prompt-2024.1"],
                ["Schema", "scorecard-schema-1.0"],
                ["Model", "gemini-1.5-pro"],
                ["Evaluated", "2026-10-07 14:22 UTC"],
                ["Latency", "1,420 ms"],
              ].map(([key, value]) => (
                <div key={key} className="flex justify-between gap-3">
                  <dt className="text-[var(--color-muted-deep)]">{key}</dt>
                  <dd className="tabular text-right font-mono text-[var(--color-foreground-soft)]">{value}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-5 flex flex-col gap-2">
              <button type="button" className="btn-secondary w-full px-3 py-2 text-xs">
                Dispute this score
              </button>
              <button type="button" className="btn-secondary w-full px-3 py-2 text-xs">
                Export scorecard
              </button>
            </div>
          </div>

          <div className="divide-y divide-[var(--color-border)]">
            {dimensions.map((dimension) => (
              <div key={dimension.label} className="p-5">
                <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                  <h3 className="text-sm font-semibold text-[var(--color-foreground)]">
                    {dimension.label}
                    <span className="ml-2 font-mono text-[0.6875rem] font-normal text-[var(--color-muted-deep)]">
                      weight {dimension.weight}
                    </span>
                  </h3>
                  <span className="tabular text-lg font-semibold text-[var(--color-foreground)]">
                    {dimension.score}
                  </span>
                </div>

                {/* Ten-segment bar, matching the SRS scorecard sketch. */}
                <div className="mt-2 flex gap-1" role="img" aria-label={`${dimension.label} scored ${dimension.score} out of 100`}>
                  {Array.from({ length: 10 }).map((_, index) => {
                    const filled = index < Math.round(dimension.score / 10);
                    const color =
                      dimension.score >= 80
                        ? "var(--color-success)"
                        : dimension.score >= 70
                          ? "var(--color-electric)"
                          : "var(--color-warning)";
                    return (
                      <span
                        key={index}
                        aria-hidden
                        className="h-1.5 flex-1 rounded-sm"
                        style={{ backgroundColor: filled ? color : "var(--color-surface-overlay)" }}
                      />
                    );
                  })}
                </div>

                <div className="mt-3.5 grid gap-3 sm:grid-cols-2">
                  <div>
                    <p className="text-[0.625rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-muted-deep)]">
                      Evidence
                    </p>
                    <blockquote className="mt-1.5 border-l-2 border-[var(--color-accent)] pl-3 text-xs italic leading-relaxed text-[var(--color-foreground-soft)]">
                      &ldquo;{dimension.quote}&rdquo;
                    </blockquote>
                  </div>
                  <div>
                    <p className="text-[0.625rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-muted-deep)]">
                      Rationale
                    </p>
                    <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-muted)]">
                      {dimension.rationale}
                    </p>
                  </div>
                </div>

                <p className="mt-3 rounded-md border border-[color-mix(in_oklab,var(--color-electric)_28%,transparent)] bg-[color-mix(in_oklab,var(--color-electric)_7%,transparent)] px-3 py-2 text-xs text-[var(--color-foreground-soft)]">
                  <span className="font-semibold text-[var(--color-electric-bright)]">Improvement: </span>
                  {dimension.improvement}
                </p>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </Section>
  );
}
