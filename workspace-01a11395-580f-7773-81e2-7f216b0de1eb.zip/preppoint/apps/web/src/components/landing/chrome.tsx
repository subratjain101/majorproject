import Link from "next/link";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const nav = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/scorecard", label: "Scorecard" },
    { href: "#how-it-works", label: "How it works" },
    { href: "#open-source", label: "Open source" },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--color-border)] bg-[color-mix(in_oklab,var(--color-background)_88%,transparent)] backdrop-blur-md">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-3 focus:z-50 focus:rounded-md focus:bg-[var(--color-accent)] focus:px-3 focus:py-1.5 focus:text-sm focus:font-medium focus:text-white"
      >
        Skip to content
      </a>
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center gap-6 px-5">
        <Link href="/" className="flex items-center gap-2.5" aria-label="PrepPoint home">
          {/* Inline SVG mark: no network request, no icon-font dependency. */}
          <svg viewBox="0 0 28 28" className="size-7" aria-hidden focusable="false">
            <rect x="0.75" y="0.75" width="26.5" height="26.5" rx="7.5" fill="var(--color-surface-raised)" stroke="var(--color-border-strong)" />
            <path d="M9 20V8h5.4a3.4 3.4 0 0 1 0 6.8H9" fill="none" stroke="var(--color-accent-bright)" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="18.6" cy="19.4" r="2.1" fill="var(--color-electric)" />
          </svg>
          <span className="text-[0.9375rem] font-semibold tracking-tight">
            Prep<span className="text-[var(--color-accent-bright)]">Point</span>
          </span>
        </Link>

        <nav aria-label="Primary" className="hidden items-center gap-1 md:flex">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-md px-3 py-2 text-sm text-[var(--color-muted)] transition-colors hover:bg-[var(--color-surface)] hover:text-[var(--color-foreground)]"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2.5">
          <Link
            href="/dashboard"
            className="hidden rounded-md px-3 py-2 text-sm text-[var(--color-muted)] transition-colors hover:text-[var(--color-foreground)] sm:block"
          >
            Sign in
          </Link>
          <Link href="/dashboard" className="btn-primary px-4 py-2 text-sm">
            Start Preparing Free
          </Link>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  const columns: { title: string; links: { label: string; href: string; external?: boolean }[] }[] = [
    {
      title: "Product",
      links: [
        { label: "Dashboard", href: "/dashboard" },
        { label: "Resume & Skills", href: "/dashboard" },
        { label: "Adaptive Interview", href: "/dashboard" },
        { label: "Transparent Scorecard", href: "/scorecard" },
      ],
    },
    {
      title: "Career Intelligence",
      links: [
        { label: "Jobs", href: "/dashboard" },
        { label: "Companies", href: "/dashboard" },
        { label: "Applications", href: "/dashboard" },
        { label: "Career Roadmap", href: "/dashboard" },
      ],
    },
    {
      title: "Trust",
      links: [
        { label: "Privacy & Consent", href: "/dashboard" },
        { label: "Responsible AI", href: "#responsible-ai" },
        { label: "Dispute a score", href: "/scorecard" },
        { label: "Audit logs", href: "#open-source" },
      ],
    },
    {
      title: "Open source",
      links: [
        { label: "GitHub", href: "https://github.com/BnoGaming/PrepPoint", external: true },
        { label: "Contributing", href: "#open-source" },
        { label: "Architecture", href: "#open-source" },
        { label: "License (MIT)", href: "#open-source" },
      ],
    },
  ];

  return (
    <footer className="border-t border-[var(--color-border)] bg-[var(--color-void)]">
      <div className="mx-auto w-full max-w-6xl px-5 py-12">
        <div className="grid gap-10 md:grid-cols-[1.4fr_repeat(4,1fr)]">
          <div>
            <div className="flex items-center gap-2.5">
              <svg viewBox="0 0 28 28" className="size-7" aria-hidden focusable="false">
                <rect x="0.75" y="0.75" width="26.5" height="26.5" rx="7.5" fill="var(--color-surface-raised)" stroke="var(--color-border-strong)" />
                <path d="M9 20V8h5.4a3.4 3.4 0 0 1 0 6.8H9" fill="none" stroke="var(--color-accent-bright)" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
                <circle cx="18.6" cy="19.4" r="2.1" fill="var(--color-electric)" />
              </svg>
              <span className="text-[0.9375rem] font-semibold tracking-tight">
                Prep<span className="text-[var(--color-accent-bright)]">Point</span>
              </span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-[var(--color-muted)]">
              Built for candidates. Designed for transparency.
            </p>
            <p className="mt-4 text-xs text-[var(--color-muted-deep)]">
              Open source under the MIT License.
            </p>
          </div>

          {columns.map((column) => (
            <nav key={column.title} aria-label={column.title}>
              <h2 className="text-[0.6875rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-muted-deep)]">
                {column.title}
              </h2>
              <ul className="mt-3 flex flex-col gap-2">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-[var(--color-muted)] transition-colors hover:text-[var(--color-foreground)]"
                      {...(link.external ? { target: "_blank", rel: "noreferrer noopener" } : {})}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-10 flex flex-col gap-3 border-t border-[var(--color-border)] pt-6 text-xs text-[var(--color-muted-deep)] sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} PrepPoint contributors. MIT licensed.</p>
          <p className="max-w-xl">
            Practice scores are formative feedback and are never a hiring decision.
          </p>
        </div>
      </div>
    </footer>
  );
}

/** Consistent section wrapper so vertical rhythm is not re-decided per section. */
export function Section({
  id,
  className,
  children,
  muted = false,
}: {
  id?: string;
  className?: string;
  children: React.ReactNode;
  muted?: boolean;
}) {
  return (
    <section
      id={id}
      className={cn(
        "scroll-mt-20 border-t border-[var(--color-border)] py-16 sm:py-20",
        muted && "bg-[color-mix(in_oklab,var(--color-surface)_55%,transparent)]",
        className,
      )}
    >
      <div className="mx-auto w-full max-w-6xl px-5">{children}</div>
    </section>
  );
}
