import { Card, Chip, SectionHeading, ScoreBar } from "@/components/ui/primitives";
import { Section } from "./chrome";

/* ==========================================================================
   Landing sections: problem framing, product flow, and the intelligence loop.
   ========================================================================== */

export function ProblemSection() {
  const failures = [
    {
      title: "Scores without reasons",
      body: "An ATS checker tells you 63/100 and stops. You cannot act on a number that never says what it measured, what it ignored, or what to do next.",
    },
    {
      title: "Preparation in fragments",
      body: "A resume tool, a DSA site, an interview simulator and a job board that never talk to each other. You re-enter your context four times and learn nothing across them.",
    },
    {
      title: "Feedback that invents certainty",
      body: "Tools that score your personality from a webcam, or grade an answer the model never actually understood. Confidence without evidence is worse than silence.",
    },
    {
      title: "Gaps described as keywords",
      body: "\u201cMissing Python.\u201d Useful how? No severity, no evidence, no effort estimate, no order of attack, no way to prove it is closed.",
    },
  ];

  return (
    <Section id="problem">
      <SectionHeading
        eyebrow="The problem"
        title="Career tools measure you. Almost none of them explain themselves."
        description="Candidates are handed scores they cannot audit, from systems they cannot question, on evidence they cannot see. PrepPoint was built on the opposite premise: if a system cannot show its reasoning, it should not be giving career advice."
      />

      <div className="mt-10 grid gap-4 sm:grid-cols-2">
        {failures.map((item, index) => (
          <Card key={item.title} className="p-5">
            <div className="flex items-start gap-3">
              <span
                aria-hidden
                className="mt-0.5 grid size-7 shrink-0 place-items-center rounded-md border border-[var(--color-border)] bg-[var(--color-surface-raised)] font-mono text-xs text-[var(--color-danger)]"
              >
                {String(index + 1).padStart(2, "0")}
              </span>
              <div>
                <h3 className="text-sm font-semibold text-[var(--color-foreground)]">{item.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-[var(--color-muted)]">{item.body}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </Section>
  );
}

export function HowItWorksSection() {
  const steps = [
    { label: "Register", detail: "Consent-first onboarding" },
    { label: "Create profile", detail: "Education, experience, goals" },
    { label: "Upload resume", detail: "PDF or DOCX, versioned forever" },
    { label: "Resume intelligence", detail: "Sections, quality, evidence" },
    { label: "Skill extraction", detail: "Mapped to a versioned taxonomy" },
    { label: "Role matching", detail: "Jobs and target roles" },
    { label: "Career Match Index", detail: "Explainable, component by component" },
    { label: "Skill gap analysis", detail: "Severity, effort, evidence" },
    { label: "Personalised roadmap", detail: "Prerequisite-aware ordering" },
    { label: "Aptitude practice", detail: "Quant, logical, verbal" },
    { label: "DSA practice", detail: "Sandboxed, real test cases" },
    { label: "Adaptive mock interview", detail: "Difficulty responds to you" },
    { label: "Evidence-linked scorecard", detail: "Every score cited" },
    { label: "Progress tracking", detail: "Trends across attempts" },
    { label: "Job discovery", detail: "Matched, not sprayed" },
    { label: "Application tracking", detail: "Saved → Offer, with timelines" },
    { label: "Company intelligence", detail: "Moderated interview experiences" },
    { label: "Recruiter ecosystem", detail: "Consent-based sharing only" },
  ];

  return (
    <Section id="how-it-works" muted>
      <SectionHeading
        eyebrow="How PrepPoint works"
        title="One loop, eighteen steps, no dead ends."
        description="Every stage feeds the next and every stage reports back. That is the difference between a collection of tools and a preparation system."
      />

      <ol className="mt-10 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
        {steps.map((step, index) => (
          <li
            key={step.label}
            className="group flex items-center gap-3 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-3 transition-colors hover:border-[var(--color-border-strong)]"
          >
            <span className="grid size-6 shrink-0 place-items-center rounded-md bg-[var(--color-surface-overlay)] font-mono text-[0.625rem] font-semibold text-[var(--color-accent-bright)] tabular">
              {String(index + 1).padStart(2, "0")}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-medium text-[var(--color-foreground)]">
                {step.label}
              </span>
              <span className="block truncate text-xs text-[var(--color-muted-deep)]">{step.detail}</span>
            </span>
          </li>
        ))}
      </ol>
    </Section>
  );
}

export function ResumeIntelligenceSection() {
  const pipeline = [
    "Upload",
    "Validate",
    "Safety check",
    "Extract text",
    "Extract sections",
    "Quality report",
    "Redact identifiers",
    "Normalise skills",
    "Map to taxonomy",
    "Analyse",
    "Persist version",
  ];

  return (
    <Section id="resume-intelligence">
      <div className="grid gap-10 lg:grid-cols-[1fr_1.1fr] lg:items-start">
        <div>
          <SectionHeading
            eyebrow="Resume intelligence"
            title="Your resume, read properly — and never thrown away."
            description="PrepPoint parses PDF and DOCX into structured sections, grades the document on measurable qualities, and extracts skills against a versioned taxonomy. Identifiers are redacted before any content reaches an external model."
          />

          <ul className="mt-6 flex flex-col gap-3">
            {[
              ["Section extraction", "Education, experience, projects, skills, certifications, achievements, links and work history."],
              ["Quality report", "ATS readability, section completeness and evidence density — each with the specific reason for its grade."],
              ["Never destroys history", "Every upload is a new immutable version. Re-analysing never overwrites the evidence your past scores were built on."],
              ["Privacy by construction", "Names, emails and phone numbers are stripped before text leaves our boundary, so an external provider never receives your identity."],
            ].map(([title, body]) => (
              <li key={title} className="flex gap-3">
                <span aria-hidden className="mt-1.5 size-1.5 shrink-0 rounded-full bg-[var(--color-accent)]" />
                <span>
                  <span className="block text-sm font-medium text-[var(--color-foreground)]">{title}</span>
                  <span className="mt-0.5 block text-sm leading-relaxed text-[var(--color-muted)]">{body}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        <Card raised className="p-5">
          <div className="flex items-center justify-between gap-4">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Processing pipeline</h3>
            <Chip tone="accent">11 stages</Chip>
          </div>

          <ol className="mt-4 flex flex-wrap items-center gap-1.5">
            {pipeline.map((stage, index) => (
              <li key={stage} className="flex items-center gap-1.5">
                <span className="rounded-md border border-[var(--color-border)] bg-[var(--color-background)]/60 px-2 py-1 font-mono text-[0.6875rem] text-[var(--color-foreground-soft)]">
                  {stage}
                </span>
                {index < pipeline.length - 1 ? (
                  <span aria-hidden className="text-[var(--color-muted-deep)]">
                    →
                  </span>
                ) : null}
              </li>
            ))}
          </ol>

          <div className="mt-5 rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/60 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
              Quality report sample
            </p>
            <div className="mt-3 flex flex-col gap-3">
              {[
                { label: "ATS readability", value: 88, note: "Single column, no tables, standard headings" },
                { label: "Section completeness", value: 71, note: "No certifications section detected" },
                { label: "Evidence density", value: 64, note: "6 experience bullets lack measurable outcomes" },
                { label: "Skill evidence", value: null, note: "Skills listed without supporting context" },
              ].map((row) => (
                <div key={row.label}>
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="text-xs font-medium text-[var(--color-foreground-soft)]">{row.label}</span>
                    <span
                      className="tabular text-xs"
                      style={{ color: row.value === null ? "var(--color-not-assessed)" : "var(--color-foreground)" }}
                    >
                      {row.value === null ? "Not assessed" : `${row.value}%`}
                    </span>
                  </div>
                  <div className="mt-1.5">
                    <ScoreBar
                      value={row.value}
                      label={row.label}
                      size="sm"
                      color={
                        row.value === null
                          ? undefined
                          : row.value >= 80
                            ? "var(--color-success)"
                            : row.value >= 65
                              ? "var(--color-warning)"
                              : "var(--color-severity-high)"
                      }
                    />
                  </div>
                  <p className="mt-1 text-[0.6875rem] text-[var(--color-muted-deep)]">{row.note}</p>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>
    </Section>
  );
}

export function CareerMatchIndexSection() {
  // Education fit is shown unassessed on purpose: it is the honest common case
  // (an unparseable education section) and the clearest possible demonstration
  // of the renormalisation rule described alongside it.
  const components = [
    { label: "Skill fit", weight: "50%", value: 83.3, detail: "2 of 3 required skills evidenced at the role's bar" },
    { label: "Semantic fit", weight: "25%", value: 43.1, detail: "Blended cosine + concept coverage against the posting" },
    { label: "Experience fit", weight: "15%", value: 100.0, detail: "7.3 years sits inside the 3\u20137 year band" },
    { label: "Education fit", weight: "10%", value: null, detail: "No education section could be read from the resume" },
  ];

  return (
    <Section id="career-match-index" muted>
      <SectionHeading
        eyebrow="Career Match Index"
        title="A match score that shows its arithmetic."
        description="Four weighted components, published as configuration rather than buried in code. The index is renormalised over the components we could actually assess — so a missing resume section costs you confidence, not points."
      />

      <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.2fr] lg:items-start">
        <Card className="overflow-hidden">
          <div className="border-b border-[var(--color-border)] bg-[var(--color-surface-raised)] p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
              Backend Engineer
            </p>
            <div className="mt-2 flex items-end gap-2">
              <span className="score-display text-4xl font-semibold text-[var(--color-foreground)]">74.9</span>
              <span className="pb-1 text-sm text-[var(--color-muted)]">/ 100</span>
            </div>
            <p className="mt-1.5 text-xs text-[var(--color-muted)]">75% evidence coverage</p>
          </div>
          <div className="flex flex-col gap-4 p-5">
            {components.map((component) => (
              <div key={component.label}>
                <div className="flex items-baseline justify-between gap-4">
                  <span className="text-sm font-medium text-[var(--color-foreground-soft)]">
                    {component.label}
                    <span className="ml-2 font-mono text-[0.6875rem] text-[var(--color-muted-deep)]">
                      {component.weight}
                    </span>
                  </span>
                  {component.value === null ? (
                    <span className="text-xs font-semibold uppercase tracking-[0.05em] text-[var(--color-not-assessed)]">
                      Not assessed
                    </span>
                  ) : (
                    <span className="tabular text-sm font-semibold text-[var(--color-foreground)]">
                      {component.value}%
                    </span>
                  )}
                </div>
                <div className="mt-1.5">
                  <ScoreBar value={component.value} label={component.label} size="sm" />
                </div>
                <p className="mt-1.5 text-[0.6875rem] leading-relaxed text-[var(--color-muted-deep)]">
                  {component.detail}
                </p>
              </div>
            ))}
          </div>
        </Card>

        <div className="flex flex-col gap-4">
          <Card className="p-5">
            <h3 className="font-mono text-xs text-[var(--color-accent-bright)]">
              M = 100 × min(1, 0.50·fsk + 0.25·fse + 0.15·fex + 0.10·fed)
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-[var(--color-muted)]">
              The published formula, implemented exactly as specified and configurable without touching business logic.
              Every result is stamped with the configuration version that produced it, so a historical score can always
              be replayed and defended.
            </p>
          </Card>

          <Card className="p-5">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">
              What &ldquo;renormalised&rdquo; means
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">
              If we cannot read an education section, education fit is marked{" "}
              <span className="font-medium text-[var(--color-not-assessed)]">not assessed</span> and excluded from the
              calculation. Its 10% weight is redistributed across the terms we did measure.
            </p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div className="rounded-[var(--radius-card)] border border-[color-mix(in_oklab,var(--color-success)_35%,transparent)] bg-[color-mix(in_oklab,var(--color-success)_8%,transparent)] p-3.5">
                <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-success)]">
                  What we do
                </p>
                <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-foreground-soft)]">
                  Exclude the term, renormalise, and lower the reported evidence coverage so you can see what is unknown.
                </p>
              </div>
              <div className="rounded-[var(--radius-card)] border border-[color-mix(in_oklab,var(--color-danger)_35%,transparent)] bg-[color-mix(in_oklab,var(--color-danger)_8%,transparent)] p-3.5">
                <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-danger)]">
                  What we refuse to do
                </p>
                <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-foreground-soft)]">
                  Score the missing section as zero. That would silently deduct points for a document-parsing failure you
                  did not cause.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </Section>
  );
}
