import { Card, Chip, SectionHeading } from "@/components/ui/primitives";
import { Section } from "./chrome";

/* ==========================================================================
   Landing sections: career intelligence, the recruiter ecosystem, and the
   trust posture that differentiates the platform (SRS §2, §19).
   ========================================================================== */

export function CareerIntelligenceSection() {
  const statuses = [
    { label: "Saved", tone: "var(--color-muted)" },
    { label: "Applied", tone: "var(--color-electric)" },
    { label: "Assessment", tone: "var(--color-info)" },
    { label: "Interview", tone: "var(--color-accent-bright)" },
    { label: "Offer", tone: "var(--color-success)" },
    { label: "Rejected", tone: "var(--color-danger)" },
    { label: "Withdrawn", tone: "var(--color-muted-deep)" },
  ];

  const jobs = [
    { title: "Backend Engineer", company: "Northwind", match: 77.5, location: "Bengaluru · Hybrid", gap: "System Design" },
    { title: "Platform Engineer", company: "Cirrus Labs", match: 74.1, location: "Remote (India)", gap: "Kubernetes" },
    { title: "Software Engineer II", company: "Halcyon", match: 71.8, location: "Pune · On-site", gap: "SQL depth" },
  ];

  return (
    <Section id="career-intelligence" muted>
      <SectionHeading
        eyebrow="Career intelligence"
        title="Jobs connected to your preparation, not floating beside it."
        description="Every posting is matched against your current evidence and links straight into the gaps it exposes. Apply once, and the same job continues to track your preparation until you are ready."
      />

      <div className="mt-10 grid gap-6 lg:grid-cols-[1.3fr_1fr] lg:items-start">
        <Card className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--color-border)] bg-[var(--color-surface-raised)] px-5 py-3">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Matched roles</h3>
            <Chip tone="accent">Sorted by evidence coverage, then index</Chip>
          </div>
          <ul className="divide-y divide-[var(--color-border)]">
            {jobs.map((job) => (
              <li key={job.title} className="flex items-center gap-4 p-5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-[var(--color-foreground)]">{job.title}</p>
                  <p className="mt-0.5 truncate text-xs text-[var(--color-muted)]">
                    {job.company} · {job.location}
                  </p>
                  <p className="mt-1.5 flex items-center gap-1.5 text-[0.6875rem] text-[var(--color-warning)]">
                    <span aria-hidden>⚠</span>
                    Primary gap: {job.gap}
                  </p>
                </div>
                <div className="text-right">
                  <p className="score-display text-xl font-semibold text-[var(--color-foreground)]">
                    {job.match}
                  </p>
                  <p className="text-[0.625rem] uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
                    match
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </Card>

        <div className="flex flex-col gap-4">
          <Card className="p-5">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Application timeline</h3>
            <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-muted)]">
              Seven explicit states, each timestamped and editable. No more guessing whether a silence is a no.
            </p>
            <ul className="mt-4 flex flex-wrap gap-2">
              {statuses.map((status) => (
                <li
                  key={status.label}
                  className="rounded-[var(--radius-pill)] border border-[var(--color-border)] px-2.5 py-1 text-xs"
                  style={{ color: status.tone }}
                >
                  {status.label}
                </li>
              ))}
            </ul>
          </Card>

          <Card className="p-5">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Smart application</h3>
            <ul className="mt-3 flex flex-col gap-2.5 text-xs text-[var(--color-muted)]">
              {[
                "Choose which resume version to send, with its analysis attached",
                "Optionally share a read-only CV link",
                "Attach portfolio, GitHub and LinkedIn",
                "Track the exact version you sent, per application",
              ].map((item) => (
                <li key={item} className="flex gap-2.5">
                  <span aria-hidden className="mt-1.5 size-1 shrink-0 rounded-full bg-[var(--color-accent)]" />
                  {item}
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </Section>
  );
}

export function RecruiterHubSection() {
  return (
    <Section id="recruiter-hub">
      <SectionHeading
        eyebrow="Company & recruiter hub"
        title="A separate, permissioned experience for employers."
        description="Recruiters get their own role-scoped workspace with its own access controls. They see a candidate's preparation profile only where that candidate has explicitly opted in, and they never see practice scores as a hiring signal."
      />

      <div className="mt-10 grid gap-4 md:grid-cols-3">
        {[
          {
            title: "Consent-based sharing",
            body: "A candidate chooses which roles a recruiter may view and can revoke access at any time. Revocation is immediate and audit-logged, not eventual.",
          },
          {
            title: "Practice is not a hiring signal",
            body: "Interview and aptitude scores are formative feedback to the candidate. Recruiters evaluate candidates on their own process, not on our practice data.",
          },
          {
            title: "Moderated company intelligence",
            body: "Interview experiences and company reviews pass through moderation before publication, with an appeal path and a full audit trail behind every decision.",
          },
        ].map((item) => (
          <Card key={item.title} className="p-5">
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">{item.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">{item.body}</p>
          </Card>
        ))}
      </div>
    </Section>
  );
}

export function ResponsibleAiSection() {
  const prohibitions = [
    "Personality, temperament or culture-fit inference",
    "Emotion, mood or sentiment detection from face or voice",
    "Health, disability or medical inference",
    "Age, gender, caste, religion, ethnicity or nationality",
    "Any prediction about a candidate's likelihood of being hired",
    "Inference about protected attributes from proxies such as photographs or names",
  ];

  const safeguards = [
    ["Everything a model produces is advisory", "AI output can suggest, summarise and explain. It can never change permissions, grant roles, alter a stored score, approve content or delete an audit record."],
    ["Uploaded content is data, never instruction", "Resumes, job descriptions and reviews are treated as untrusted input. Prompt injection from any document cannot change system behaviour, rubric, or score."],
    ["No evidence, no score", "When a dimension cannot be judged from the available evidence, it is marked not assessed and excluded from the overall. A fabricated mid-band score is never emitted."],
    ["Every score is attributable", "Each result records the rubric version, prompt version, schema version, provider, model, latency and failure status."],
    ["Provider-agnostic by design", "Gemini, OpenAI, Groq and self-hosted models sit behind one interface. Falling back degrades the experience and says so — it never silently invents a result."],
    ["Failure is reported, not hidden", "When a provider fails, the failure, the retry state and the session progress are all persisted, and the candidate is told the score is a fallback."],
  ];

  return (
    <Section id="responsible-ai" muted>
      <SectionHeading
        eyebrow="Privacy & responsible AI"
        title="Some things this platform will not do, by design."
        description="Refusing to infer is a feature. Every capability below is deliberately absent, and each is enforced by a test in the repository rather than by a policy document."
      />

      <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1.35fr] lg:items-start">
        <Card className="p-5">
          <div className="flex items-center gap-2.5">
            <span aria-hidden className="grid size-6 place-items-center rounded-full border border-[color-mix(in_oklab,var(--color-danger)_45%,transparent)] text-sm text-[var(--color-danger)]">
              ✕
            </span>
            <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Never inferred, never scored</h3>
          </div>
          <ul className="mt-4 flex flex-col gap-2.5">
            {prohibitions.map((item) => (
              <li key={item} className="flex gap-2.5 text-sm text-[var(--color-muted)]">
                <span aria-hidden className="mt-2 size-1 shrink-0 rounded-full bg-[var(--color-danger)]" />
                {item}
              </li>
            ))}
          </ul>
          <p className="mt-5 border-t border-[var(--color-border)] pt-4 text-xs leading-relaxed text-[var(--color-muted-deep)]">
            The original prototype inferred facial and behavioural signals from webcam frames. That capability was
            removed rather than ported: it is unfalsifiable, it correlates with protected attributes, and no candidate
            should be scored on it.
          </p>
        </Card>

        <div className="grid gap-3 sm:grid-cols-2">
          {safeguards.map(([title, body]) => (
            <Card key={title} className="p-4">
              <div className="flex items-center gap-2">
                <span aria-hidden className="grid size-5 place-items-center rounded-full border border-[color-mix(in_oklab,var(--color-success)_45%,transparent)] text-[0.625rem] text-[var(--color-success)]">
                  ✓
                </span>
                <h3 className="text-xs font-semibold text-[var(--color-foreground)]">{title}</h3>
              </div>
              <p className="mt-2 text-xs leading-relaxed text-[var(--color-muted)]">{body}</p>
            </Card>
          ))}
        </div>
      </div>
    </Section>
  );
}

export function OpenSourceSection() {
  const stack = [
    ["Frontend", "Next.js · TypeScript · Tailwind · shadcn/ui · TanStack Query · Recharts"],
    ["API", "FastAPI · Python · SQLAlchemy 2 · Pydantic v2 · OpenAPI"],
    ["Data", "PostgreSQL · Alembic migrations · versioned seed taxonomy"],
    ["Async", "Worker service for resume processing, evaluation, moderation, notifications"],
    ["Execution", "Isolated sandbox: no network, CPU/memory caps, timeout, filesystem and process isolation"],
    ["AI", "Provider-agnostic adapters with schema validation, bounded retries and safe degradation"],
    ["Quality", "pytest unit/integration suites, end-to-end tests, security tests"],
    ["Delivery", "Docker Compose for local parity, Nginx, Terraform and CI workflows"],
  ];

  return (
    <Section id="open-source">
      <div className="grid gap-10 lg:grid-cols-[1fr_1.15fr] lg:items-start">
        <div>
          <SectionHeading
            eyebrow="Open source"
            title="Auditable by anyone, including the parts that score you."
            description="PrepPoint is MIT licensed and published in full. Scoring configuration, rubrics, prompts and taxonomies all live in versioned config rather than in application code, so a claim about how a score was produced can be checked by reading the repository."
          />

          <div className="mt-6 flex flex-wrap gap-2.5">
            <a
              href="https://github.com/BnoGaming/PrepPoint"
              target="_blank"
              rel="noreferrer noopener"
              className="btn-primary px-4 py-2 text-sm"
            >
              View the repository
            </a>
            <a href="#final-cta" className="btn-secondary px-4 py-2 text-sm">
              Read the architecture
            </a>
          </div>

          <ul className="mt-6 flex flex-col gap-2.5">
            {[
              "MIT licensed — fork it, self-host it, audit it",
              "Scoring weights, thresholds and rubrics are configuration, not code",
              "Every AI output is schema-validated before it is persisted",
              "Security tests assert that AI output cannot mutate permissions or scores",
            ].map((item) => (
              <li key={item} className="flex gap-2.5 text-sm text-[var(--color-muted)]">
                <span aria-hidden className="mt-1.5 size-1.5 shrink-0 rounded-full bg-[var(--color-accent)]" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <Card raised className="p-5">
          <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Built on</h3>
          <dl className="mt-4 flex flex-col divide-y divide-[var(--color-border)]">
            {stack.map(([layer, detail]) => (
              <div key={layer} className="grid grid-cols-[110px_1fr] gap-4 py-3 first:pt-0 last:pb-0">
                <dt className="text-xs font-semibold text-[var(--color-accent-bright)]">{layer}</dt>
                <dd className="text-xs leading-relaxed text-[var(--color-muted)]">{detail}</dd>
              </div>
            ))}
          </dl>
        </Card>
      </div>
    </Section>
  );
}

export function FinalCtaSection() {
  return (
    <Section id="final-cta" className="bg-ambient" muted>
      <div className="mx-auto flex max-w-3xl flex-col items-center text-center">
        <span className="eyebrow">
          <span aria-hidden className="live-dot size-1.5 rounded-full bg-current" />
          Open source · MIT
        </span>
        <h2 className="mt-5 text-balance text-3xl font-semibold tracking-tight text-[var(--color-foreground)] sm:text-4xl">
          Know exactly where you stand, and exactly what to do next.
        </h2>
        <p className="mt-4 max-w-xl text-pretty text-sm leading-relaxed text-[var(--color-muted)] sm:text-base">
          Upload a resume, see your gaps ranked by what actually matters for the roles you want, and practise until the
          evidence says you are ready.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <a href="/dashboard" className="btn-primary px-6 py-3 text-sm">
            Start Preparing Free
          </a>
          <a href="#how-it-works" className="btn-secondary px-6 py-3 text-sm">
            Explore the Platform
          </a>
        </div>
        <p className="mt-7 text-base font-medium text-[var(--color-foreground-soft)]">
          Built for candidates. Designed for transparency.
        </p>
      </div>
    </Section>
  );
}
