import Link from "next/link";
import { HeroPreview } from "./hero-preview";

/* ==========================================================================
   SRS §7 hero.

   Copy is fixed by the specification and treated as content, not styling
   decisions: headline, subheadline, primary and secondary CTA.
   ========================================================================== */

export function Hero() {
  const proofPoints = [
    "Evidence-linked scoring",
    "Adaptive difficulty",
    "Consent-based sharing",
    "MIT licensed",
  ];

  return (
    <section className="relative overflow-hidden">
      {/* Ambient wash + grid, decoration only */}
      <div aria-hidden className="pointer-events-none absolute inset-0 bg-grid opacity-[0.25]" />
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 h-[42rem] w-[70rem] -translate-x-1/2 rounded-full opacity-[0.16] blur-3xl"
        style={{
          background:
            "radial-gradient(closest-side, var(--color-accent), transparent), radial-gradient(closest-side, var(--color-electric), transparent)",
        }}
      />

      <div className="relative mx-auto w-full max-w-6xl px-5 pb-16 pt-14 sm:pb-20 sm:pt-20">
        <div className="grid items-center gap-12 lg:grid-cols-[1fr_1.12fr]">
          {/* ---------------- Left: copy ---------------- */}
          <div className="animate-rise">
            <span className="eyebrow">
              <span aria-hidden className="live-dot size-1.5 rounded-full bg-current" />
              Open source career intelligence
            </span>

            <h1 className="mt-6 text-balance text-4xl font-semibold leading-[1.08] tracking-tight text-[var(--color-foreground)] sm:text-5xl lg:text-[3.4rem]">
              <span className="block bg-gradient-to-br from-[var(--color-foreground)] via-[var(--color-foreground)] to-[var(--color-accent-bright)] bg-clip-text text-transparent">
                PREPPOINT
              </span>
              <span className="mt-3 block text-[1.75rem] font-medium leading-tight text-[var(--color-foreground-soft)] sm:text-[2.1rem]">
                AI Career Intelligence
                <br />
                for the way you actually get hired.
              </span>
            </h1>

            <p className="mt-6 max-w-xl text-pretty text-sm leading-relaxed text-[var(--color-muted)] sm:text-base">
              Understand your resume. Discover your gaps. Practise the right skills. Face adaptive interviews. See
              exactly why you scored the way you did.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/dashboard" className="btn-primary px-6 py-3 text-sm">
                Start Preparing Free
              </Link>
              <Link href="#how-it-works" className="btn-secondary px-6 py-3 text-sm">
                Explore the Platform
              </Link>
            </div>

            <ul className="mt-9 flex flex-wrap items-center gap-x-5 gap-y-2.5">
              {proofPoints.map((point) => (
                <li key={point} className="flex items-center gap-2 text-xs text-[var(--color-muted)]">
                  <span aria-hidden className="text-[var(--color-success)]">
                    ✓
                  </span>
                  {point}
                </li>
              ))}
            </ul>
          </div>

          {/* ---------------- Right: product preview ---------------- */}
          <div className="animate-rise [animation-delay:120ms]">
            <HeroPreview />
            <p className="mt-3 text-center text-[0.6875rem] text-[var(--color-muted-deep)]">
              Illustrative dashboard. Every number shown is produced by the same engine the app runs on.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
