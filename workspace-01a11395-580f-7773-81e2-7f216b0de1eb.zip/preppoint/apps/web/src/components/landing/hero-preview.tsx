import { cn } from "@/lib/utils";

/* ==========================================================================
   Hero visual: interactive career intelligence dashboard preview (SRS §7).

   Implemented as a server component with a small amount of CSS-only motion so
   it renders instantly and costs nothing on the client. Every animated element
   is aria-hidden and disabled under prefers-reduced-motion, because a marketing
   decoration must never be the reason someone cannot read the page.
   ========================================================================== */

type SkillState = "matched" | "weak" | "missing";

const SKILLS: { name: string; state: SkillState; note: string }[] = [
  { name: "Python", state: "matched", note: "Evidenced in 2 roles" },
  { name: "SQL", state: "matched", note: "Evidenced in work history" },
  { name: "React", state: "matched", note: "Evidenced in projects" },
  { name: "Docker", state: "weak", note: "Below the role's proficiency bar" },
  { name: "System Design", state: "weak", note: "Thin evidence — 8% below bar" },
];

const STATE_GLYPH: Record<SkillState, string> = {
  matched: "✓",
  weak: "⚠",
  missing: "✕",
};

const STATE_COLOR: Record<SkillState, string> = {
  matched: "var(--color-success)",
  weak: "var(--color-warning)",
  missing: "var(--color-not-assessed)",
};

/** Sparkline for the 8-week match trajectory. Pure SVG, no chart library. */
function MatchSparkline({ points, className }: { points: number[]; className?: string }) {
  const width = 260;
  const height = 56;
  const pad = 4;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const span = max - min || 1;

  const coords = points.map((value, index) => {
    const x = pad + (index / (points.length - 1)) * (width - pad * 2);
    const y = height - pad - ((value - min) / span) * (height - pad * 2);
    return [x, y] as const;
  });

  const line = coords.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${line} L${width - pad},${height} L${pad},${height} Z`;
  const last = coords[coords.length - 1];

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className={cn("h-14 w-full", className)}
      role="img"
      aria-label={`Career Match Index trend over the last ${points.length} weeks, rising from ${min} to ${max}.`}
      preserveAspectRatio="none"
    >
      <defs>
        <linearGradient id="pp-spark-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--color-accent)" stopOpacity="0.28" />
          <stop offset="100%" stopColor="var(--color-accent)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill="url(#pp-spark-fill)" />
      <path
        d={line}
        fill="none"
        stroke="var(--color-accent-bright)"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        vectorEffect="non-scaling-stroke"
      />
      <circle cx={last[0]} cy={last[1]} r="3" fill="var(--color-electric-bright)" />
    </svg>
  );
}

/** Radial gauge for the headline index. */
function IndexGauge({ value, coverage }: { value: number; coverage: number }) {
  const radius = 52;
  const circumference = 2 * Math.PI * radius;
  const dash = (value / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center">
      <svg viewBox="0 0 130 130" className="size-36" role="img" aria-label={`Career Match Index ${value} out of 100, based on ${coverage} percent evidence coverage.`}>
        <defs>
          <linearGradient id="pp-gauge" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--color-accent)" />
            <stop offset="100%" stopColor="var(--color-electric)" />
          </linearGradient>
        </defs>
        <circle cx="65" cy="65" r={radius} fill="none" stroke="var(--color-surface-overlay)" strokeWidth="9" />
        <circle
          cx="65"
          cy="65"
          r={radius}
          fill="none"
          stroke="url(#pp-gauge)"
          strokeWidth="9"
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circumference}`}
          transform="rotate(-90 65 65)"
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="score-display text-3xl font-semibold text-[var(--color-foreground)]">{value}%</span>
        <span className="mt-0.5 text-[0.625rem] font-semibold uppercase tracking-[0.1em] text-[var(--color-muted-deep)]">
          Match
        </span>
      </div>
    </div>
  );
}

export function HeroPreview() {
  const trend = [58, 61, 63, 66, 70, 73, 78, 82];

  return (
    <div
      className={cn(
        "relative w-full overflow-hidden rounded-[var(--radius-panel)]",
        "border border-[var(--color-border)] bg-[var(--color-surface)]",
        "shadow-[var(--shadow-raised)]",
      )}
    >
      {/* Window chrome */}
      <div className="flex items-center gap-2 border-b border-[var(--color-border)] bg-[var(--color-surface-raised)] px-4 py-2.5">
        <span aria-hidden className="size-2.5 rounded-full bg-[#ff5f57]" />
        <span aria-hidden className="size-2.5 rounded-full bg-[#febc2e]" />
        <span aria-hidden className="size-2.5 rounded-full bg-[#28c840]" />
        <span className="ml-3 font-mono text-[0.6875rem] text-[var(--color-muted-deep)]">
          preppoint / dashboard / backend-engineer
        </span>
        <span className="ml-auto flex items-center gap-1.5 text-[0.6875rem] font-medium text-[var(--color-success)]">
          <span aria-hidden className="live-dot size-1.5 rounded-full bg-current" />
          Live
        </span>
      </div>

      <div className="relative">
        {/* Grid texture, decoration only */}
        <div aria-hidden className="pointer-events-none absolute inset-0 bg-grid opacity-[0.35]" />

        <div className="relative grid gap-4 p-4 sm:p-5 lg:grid-cols-[auto_1fr]">
          {/* Headline index */}
          <div className="flex flex-col items-center rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/70 p-4">
            <IndexGauge value={82} coverage={84} />
            <div className="mt-1 text-center">
              <p className="text-[0.6875rem] font-medium text-[var(--color-muted)]">
                Target: Backend Engineer
              </p>
              <p className="mt-1 text-[0.6875rem] text-[var(--color-muted-deep)]">
                84% evidence coverage
              </p>
            </div>
          </div>

          {/* Right column */}
          <div className="flex flex-col gap-4">
            {/* Interview readiness */}
            <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/70 p-4">
              <div className="flex items-baseline justify-between gap-4">
                <span className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
                  Interview readiness
                </span>
                <span className="score-display text-lg font-semibold text-[var(--color-electric-bright)]">
                  74%
                </span>
              </div>
              <div className="mt-2.5 h-2 w-full overflow-hidden rounded-full bg-[var(--color-surface-overlay)]">
                <div
                  className="h-full rounded-full animate-bar-grow"
                  style={{
                    width: "74%",
                    background: "linear-gradient(90deg, var(--color-electric), var(--color-accent))",
                  }}
                />
              </div>
              <MatchSparkline points={trend} className="mt-3" />
            </div>

            {/* Skills */}
            <div className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/70 p-4">
              <span className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
                Skills
              </span>
              <ul className="mt-2.5 flex flex-wrap gap-2">
                {SKILLS.map((skill) => (
                  <li
                    key={skill.name}
                    className="inline-flex items-center gap-1.5 rounded-[var(--radius-pill)] border border-[var(--color-border)] bg-[var(--color-surface-raised)] px-2.5 py-1 text-xs"
                  >
                    <span aria-hidden style={{ color: STATE_COLOR[skill.state] }} className="font-semibold">
                      {STATE_GLYPH[skill.state]}
                    </span>
                    <span className="text-[var(--color-foreground-soft)]">{skill.name}</span>
                    <span className="sr-only">
                      {skill.state === "matched" ? "matched — " : skill.state === "weak" ? "partial — " : "missing — "}
                      {skill.note}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Next action */}
            <div className="flex items-center gap-3 rounded-[var(--radius-card)] border border-[color-mix(in_oklab,var(--color-accent)_35%,transparent)] bg-[color-mix(in_oklab,var(--color-accent)_10%,transparent)] p-4">
              <div className="flex flex-col gap-0.5">
                <span className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-accent-bright)]">
                  Next action
                </span>
                <span className="text-sm font-medium text-[var(--color-foreground)]">
                  Practice System Design
                </span>
                <span className="text-xs text-[var(--color-muted)]">
                  Highest-leverage gap · ~4 hours · 3 linked modules
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
