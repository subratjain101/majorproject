import * as React from "react";
import { cn } from "@/lib/utils";

export { Card } from "@/components/ui/primitives";

/* ==========================================================================
   Scorecard presentation primitives.

   These exist so the scorecard reads as one artefact rather than a page of
   loosely styled divs, and so the "not assessed" treatment is defined once and
   cannot drift between dimensions.
   ========================================================================== */

export function CheckRow({
  children,
  tone = "success",
}: {
  children: React.ReactNode;
  tone?: "success" | "danger";
}) {
  const color = tone === "success" ? "var(--color-success)" : "var(--color-danger)";
  return (
    <li className="flex gap-2.5 text-xs leading-relaxed text-[var(--color-foreground-soft)]">
      <span aria-hidden className="mt-0.5 shrink-0 font-semibold" style={{ color }}>
        {tone === "success" ? "✓" : "✕"}
      </span>
      {children}
    </li>
  );
}

/**
 * Ten-segment meter matching the SRS scorecard sketch.
 *
 * Rendering ten discrete segments rather than a continuous bar is intentional:
 * it communicates that the underlying score is a coarse rubric judgement, not
 * a measurement with three significant figures.
 */
export function SegmentMeter({
  score,
  label,
  className,
}: {
  score: number;
  label: string;
  className?: string;
}) {
  const filledCount = Math.round(score / 10);
  const color =
    score >= 80
      ? "var(--color-success)"
      : score >= 70
        ? "var(--color-electric)"
        : score >= 55
          ? "var(--color-warning)"
          : "var(--color-severity-high)";

  return (
    <div
      className={cn("flex gap-1", className)}
      role="img"
      aria-label={`${label}: ${score} out of 100`}
    >
      {Array.from({ length: 10 }).map((_, index) => (
        <span
          key={index}
          aria-hidden
          className="h-1.5 flex-1 rounded-sm transition-colors"
          style={{
            backgroundColor: index < filledCount ? color : "var(--color-surface-overlay)",
          }}
        />
      ))}
    </div>
  );
}

/** Provenance strip: the audit trail, always visible, never behind a toggle. */
export function ProvenanceGrid({ entries }: { entries: [string, string][] }) {
  return (
    <dl className="grid gap-x-4 gap-y-2.5 sm:grid-cols-2">
      {entries.map(([key, value]) => (
        <div key={key} className="flex flex-col gap-0.5">
          <dt className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
            {key}
          </dt>
          <dd className="truncate font-mono text-xs text-[var(--color-foreground-soft)]" title={value}>
            {value}
          </dd>
        </div>
      ))}
    </dl>
  );
}

/** A quoted evidence citation. */
export function EvidenceQuote({
  quote,
  point,
  supports = true,
}: {
  quote: string;
  point?: string;
  supports?: boolean;
}) {
  return (
    <li className="flex gap-3">
      <span
        aria-hidden
        className="mt-0.5 w-0.5 shrink-0 rounded-full"
        style={{ backgroundColor: supports ? "var(--color-success)" : "var(--color-danger)" }}
      />
      <div className="min-w-0">
        <blockquote className="text-xs italic leading-relaxed text-[var(--color-foreground-soft)]">
          &ldquo;{quote}&rdquo;
        </blockquote>
        {point ? (
          <p className="mt-1 text-[0.6875rem] text-[var(--color-muted-deep)]">
            {supports ? "Supports" : "Counts against"}: {point}
          </p>
        ) : null}
      </div>
    </li>
  );
}

/** The NOT_ASSESSED treatment: a distinct state, never a zero. */
export function NotAssessedNotice({ reason, missing }: { reason: string; missing: string[] }) {
  return (
    <div className="rounded-[var(--radius-card)] border border-dashed border-[color-mix(in_oklab,var(--color-not-assessed)_45%,transparent)] bg-[color-mix(in_oklab,var(--color-not-assessed)_7%,transparent)] p-4">
      <p className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-not-assessed)]">
        Not assessed — excluded from your overall score
      </p>
      <p className="mt-2 text-xs leading-relaxed text-[var(--color-muted)]">{reason}</p>
      {missing.length ? (
        <div className="mt-3">
          <p className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
            What would let us assess this
          </p>
          <ul className="mt-1.5 flex flex-col gap-1">
            {missing.map((item) => (
              <li key={item} className="text-[0.6875rem] text-[var(--color-muted)]">
                · {item}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
