import { Card } from "@/components/ui/primitives";
import type { Dimension, Scorecard } from "@/content/scorecard-data";
import { RENORMALISATION_DEMO } from "@/content/scorecard-data";
import { EvidenceQuote, NotAssessedNotice, ProvenanceGrid, SegmentMeter } from "./parts";

/* ==========================================================================
   The scorecard itself (SRS §15).

   Reading order is deliberate: overall → why → per-dimension evidence →
   provenance → what we excluded. A candidate should be able to stop at any
   layer and still have an honest picture.
   ========================================================================== */

function DimensionBlock({ dimension }: { dimension: Dimension }) {
  const assessed = dimension.status === "assessed" && dimension.score !== null;

  return (
    <section
      className="border-b border-[var(--color-border)] p-5 last:border-b-0 sm:p-6"
      aria-labelledby={`dim-${dimension.dimension}`}
    >
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h3 id={`dim-${dimension.dimension}`} className="text-sm font-semibold text-[var(--color-foreground)]">
          {dimension.label}
          <span className="ml-2 font-mono text-[0.6875rem] font-normal text-[var(--color-muted-deep)]">
            weight {Math.round(dimension.weight * 100)}%
          </span>
        </h3>

        {assessed ? (
          <div className="flex items-baseline gap-2">
            <span className="tabular text-2xl font-semibold text-[var(--color-foreground)]">
              {dimension.score}
            </span>
            <span className="text-xs text-[var(--color-muted-deep)]">/100</span>
          </div>
        ) : (
          <span className="text-xs font-semibold uppercase tracking-[0.06em] text-[var(--color-not-assessed)]">
            Not assessed
          </span>
        )}
      </div>

      {assessed ? (
        <SegmentMeter score={dimension.score!} label={dimension.label} className="mt-3 max-w-md" />
      ) : null}

      {!assessed ? (
        <div className="mt-4">
          <NotAssessedNotice
            reason={
              dimension.notAssessedReason ??
              "There was not enough evidence in this answer to judge this dimension."
            }
            missing={dimension.missingPoints}
          />
        </div>
      ) : (
        <div className="mt-5 grid gap-5 lg:grid-cols-2">
          {/* Evidence */}
          <div>
            <h4 className="text-[0.625rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-muted-deep)]">
              Evidence cited
            </h4>
            <ul className="mt-2.5 flex flex-col gap-3">
              {dimension.evidence.map((item) => (
                <EvidenceQuote
                  key={item.quote}
                  quote={item.quote}
                  point={item.point}
                  supports={item.supports !== false}
                />
              ))}
            </ul>
          </div>

          {/* Rationale + improvement */}
          <div>
            <h4 className="text-[0.625rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-muted-deep)]">
              Rationale
            </h4>
            <p className="mt-2.5 text-xs leading-relaxed text-[var(--color-muted)]">{dimension.rationale}</p>

            {dimension.improvement ? (
              <div className="mt-3.5 rounded-md border border-[color-mix(in_oklab,var(--color-electric)_28%,transparent)] bg-[color-mix(in_oklab,var(--color-electric)_7%,transparent)] px-3 py-2.5">
                <p className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-electric-bright)]">
                  Improvement
                </p>
                <p className="mt-1 text-xs leading-relaxed text-[var(--color-foreground-soft)]">
                  {dimension.improvement}
                </p>
              </div>
            ) : null}

            {dimension.missingPoints.length ? (
              <div className="mt-3">
                <p className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
                  Rubric points not addressed
                </p>
                <ul className="mt-1.5 flex flex-col gap-1">
                  {dimension.missingPoints.map((point) => (
                    <li key={point} className="flex gap-2 text-[0.6875rem] text-[var(--color-muted)]">
                      <span aria-hidden className="mt-1.5 size-1 shrink-0 rounded-full bg-[var(--color-warning)]" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}

            <p className="mt-3.5 text-[0.625rem] text-[var(--color-muted-deep)]">
              Measurement confidence {Math.round(dimension.confidence * 100)}%
            </p>
          </div>
        </div>
      )}
    </section>
  );
}

export function ScorecardView({ scorecard }: { scorecard: Scorecard }) {
  return (
    <div className="flex flex-col gap-5">
      {/* Disclaimer — always first, never collapsible. */}
      <div
        className="rounded-[var(--radius-card)] border border-[color-mix(in_oklab,var(--color-warning)_35%,transparent)] bg-[color-mix(in_oklab,var(--color-warning)_9%,transparent)] px-5 py-3.5"
        role="note"
      >
        <p className="text-xs font-bold tracking-[0.05em] text-[var(--color-warning)]">
          PRACTICE FEEDBACK — NOT A HIRING DECISION
        </p>
        <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-muted)]">
          This measures one practice exercise, reviewed by no human. No employer can see it unless you share it. You
          can dispute any dimension below.
        </p>
      </div>

      <Card className="overflow-hidden">
        <div className="grid lg:grid-cols-[240px_1fr]">
          {/* Left rail: overall + provenance */}
          <div className="border-b border-[var(--color-border)] bg-[var(--color-surface-raised)] p-5 lg:border-b-0 lg:border-r">
            <p className="text-[0.625rem] font-semibold uppercase tracking-[0.1em] text-[var(--color-muted-deep)]">
              Overall
            </p>
            <div className="mt-2 flex items-end gap-1.5">
              <span className="score-display text-5xl font-semibold text-[var(--color-foreground)]">
                {scorecard.overall}
              </span>
              <span className="pb-1.5 text-base text-[var(--color-muted)]">/100</span>
            </div>
            <p className="mt-2 text-xs text-[var(--color-muted)]">
              {Math.round(scorecard.assessedWeightFraction * 100)}% of rubric weight assessed
            </p>

            <div className="mt-4 rounded-md border border-[var(--color-border)] bg-[var(--color-background)]/60 p-3">
              <p className="text-[0.625rem] leading-relaxed text-[var(--color-muted-deep)]">
                Weighted mean of assessed dimensions only:
              </p>
              <p className="mt-1 font-mono text-[0.625rem] leading-relaxed text-[var(--color-foreground-soft)]">
                0.40·82 + 0.30·71 + 0.20·79 + 0.10·74
                <br />= 77.3 → 77
              </p>
            </div>

            <p className="mt-5 text-[0.625rem] font-semibold uppercase tracking-[0.1em] text-[var(--color-muted-deep)]">
              Provenance
            </p>
            <div className="mt-2.5">
              <ProvenanceGrid entries={scorecard.provenance} />
            </div>
          </div>

          {/* Right: summary + dimensions */}
          <div className="min-w-0">
            <div className="border-b border-[var(--color-border)] p-5 sm:p-6">
              <h2 className="text-sm font-semibold text-[var(--color-foreground)]">Summary</h2>
              <p className="mt-2 text-sm leading-relaxed text-[var(--color-muted)]">{scorecard.summary}</p>

              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-success)]">
                    Strengths
                  </p>
                  <ul className="mt-2 flex flex-col gap-1.5">
                    {scorecard.strengths.map((item) => (
                      <li key={item} className="flex gap-2 text-xs leading-relaxed text-[var(--color-muted)]">
                        <span aria-hidden className="mt-1.5 size-1 shrink-0 rounded-full bg-[var(--color-success)]" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <p className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-accent-bright)]">
                    Priorities
                  </p>
                  <ul className="mt-2 flex flex-col gap-1.5">
                    {scorecard.priorities.map((item) => (
                      <li key={item} className="flex gap-2 text-xs leading-relaxed text-[var(--color-muted)]">
                        <span aria-hidden className="mt-1.5 size-1 shrink-0 rounded-full bg-[var(--color-accent)]" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {scorecard.dimensions.map((dimension) => (
              <DimensionBlock key={dimension.dimension} dimension={dimension} />
            ))}
          </div>
        </div>
      </Card>

      {/* Renormalisation worked example */}
      <Card className="p-5">
        <h2 className="text-sm font-semibold text-[var(--color-foreground)]">
          How an unassessable dimension would change this score
        </h2>
        <p className="mt-1.5 text-xs text-[var(--color-muted)]">{RENORMALISATION_DEMO.scenario}</p>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[26rem] text-left text-xs">
            <caption className="sr-only">Dimension weights and scores, with one dimension unassessed</caption>
            <thead>
              <tr className="border-b border-[var(--color-border)] text-[0.625rem] uppercase tracking-[0.06em] text-[var(--color-muted-deep)]">
                <th scope="col" className="py-2 font-semibold">Dimension</th>
                <th scope="col" className="py-2 font-semibold">Weight</th>
                <th scope="col" className="py-2 font-semibold">Score</th>
                <th scope="col" className="py-2 font-semibold">Contribution</th>
              </tr>
            </thead>
            <tbody className="tabular">
              {RENORMALISATION_DEMO.rows.map((row) => (
                <tr key={row.label} className="border-b border-[var(--color-border)]/60">
                  <td className="py-2.5 text-[var(--color-foreground-soft)]">{row.label}</td>
                  <td className="py-2.5 font-mono text-[var(--color-muted)]">{row.weight.toFixed(2)}</td>
                  <td className="py-2.5">
                    {row.assessed ? (
                      <span className="font-semibold text-[var(--color-foreground)]">{row.score}</span>
                    ) : (
                      <span className="text-[var(--color-not-assessed)]">not assessed</span>
                    )}
                  </td>
                  <td className="py-2.5 text-[var(--color-muted)]">
                    {row.assessed ? (row.weight * (row.score ?? 0)).toFixed(2) : "excluded"}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t border-[var(--color-border-strong)]">
                <td className="py-3 font-medium text-[var(--color-foreground-soft)]" colSpan={2}>
                  Overall
                </td>
                <td className="py-3 font-semibold text-[var(--color-foreground)]">
                  {RENORMALISATION_DEMO.renormalised}
                </td>
                <td className="py-3 text-[var(--color-muted)]">
                  69.9 ÷ 0.90 = 77.7 → {RENORMALISATION_DEMO.renormalised}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        <p className="mt-4 border-t border-[var(--color-border)] pt-4 text-xs leading-relaxed text-[var(--color-muted)]">
          {RENORMALISATION_DEMO.explanation}
        </p>
      </Card>
    </div>
  );
}
