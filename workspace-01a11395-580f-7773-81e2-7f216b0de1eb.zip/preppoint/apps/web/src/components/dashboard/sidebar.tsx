import Link from "next/link";
import { cn } from "@/lib/utils";

/* ==========================================================================
   Candidate navigation (SRS §6).

   Groups mirror the specification exactly. Rendered as plain semantic
   landmarks so keyboard and screen-reader navigation works without any
   client-side JavaScript.
   ========================================================================== */

type NavItem = { label: string; href: string; badge?: string };

export const CANDIDATE_NAV: { heading?: string; items: NavItem[] }[] = [
  { items: [{ label: "Dashboard", href: "/dashboard" }] },
  {
    heading: "Preparation",
    items: [
      { label: "Resume & Skills", href: "/dashboard" },
      { label: "Adaptive Interview", href: "/dashboard" },
      { label: "Transparent Scorecard", href: "/scorecard" },
      { label: "Progress", href: "/dashboard" },
    ],
  },
  {
    heading: "Career Intelligence",
    items: [
      { label: "Jobs", href: "/dashboard" },
      { label: "Companies", href: "/dashboard" },
      { label: "Saved Jobs", href: "/dashboard" },
      { label: "Applications", href: "/dashboard" },
      { label: "Career Roadmap", href: "/dashboard" },
    ],
  },
  {
    heading: "Practice",
    items: [
      { label: "Aptitude", href: "/dashboard" },
      { label: "DSA", href: "/dashboard" },
      { label: "Interview", href: "/dashboard" },
    ],
  },
  {
    heading: "Account",
    items: [
      { label: "Privacy & Consent", href: "/dashboard" },
      { label: "Settings", href: "/dashboard" },
    ],
  },
  {
    heading: "Admin",
    items: [
      { label: "Moderation queue", href: "/dashboard", badge: "7" },
      { label: "Audit logs", href: "/dashboard" },
      { label: "System health", href: "/dashboard" },
    ],
  },
];

export function DashboardSidebar({ active = "/dashboard" }: { active?: string }) {
  return (
    <aside
      aria-label="Candidate navigation"
      className="w-full shrink-0 border-[var(--color-border)] lg:w-60 lg:border-r"
    >
      <nav className="flex flex-col gap-5 p-4">
        {CANDIDATE_NAV.map((group, index) => (
          <div key={group.heading ?? `group-${index}`}>
            {group.heading ? (
              <h2 className="px-2 text-[0.625rem] font-semibold uppercase tracking-[0.1em] text-[var(--color-muted-deep)]">
                {group.heading}
              </h2>
            ) : null}
            <ul className="mt-2 flex flex-col gap-0.5">
              {group.items.map((item) => {
                const isActive = item.href === active && item.label === "Dashboard";
                return (
                  <li key={item.label}>
                    <Link
                      href={item.href}
                      aria-current={isActive ? "page" : undefined}
                      className={cn(
                        "flex items-center gap-2 rounded-md px-2 py-1.5 text-sm transition-colors",
                        isActive
                          ? "bg-[color-mix(in_oklab,var(--color-accent)_16%,transparent)] font-medium text-[var(--color-foreground)]"
                          : "text-[var(--color-muted)] hover:bg-[var(--color-surface)] hover:text-[var(--color-foreground)]",
                      )}
                    >
                      <span className="truncate">{item.label}</span>
                      {item.badge ? (
                        <span className="ml-auto rounded-full bg-[var(--color-surface-overlay)] px-1.5 py-0.5 font-mono text-[0.625rem] text-[var(--color-warning)]">
                          {item.badge}
                        </span>
                      ) : null}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
