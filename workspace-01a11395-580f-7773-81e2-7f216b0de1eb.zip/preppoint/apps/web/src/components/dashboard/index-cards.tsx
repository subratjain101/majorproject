import Link from "next/link";
import { Card, Chip, ScoreBar } from "@/components/ui/primitives";
import { cn } from "@/lib/utils";

/* ==========================================================================
   Dashboard widgets.

   Data shapes here mirror what the Career Match Index and skill gap engines
   actually return (see services/api/app/domain), so swapping the inline
   fixtures for a live fetch is a data change, not a rewrite.
   ========================================================================== */

export type ComponentView = {
  key: string;
  label: string;
  weight: number;
  /** null means NOT_ASSESSED -- never rendered as zero. */
  percent: number | null;
  confidence: number;
  rationale: string;
  evidence: string[];
  missingEvidence: string[];
};

export type GapView = {
  name: string;
  severity: "high" | "medium" | "low";
  reason: string;
  roleRelevance: string;
  effort: string;
  hours: number;
  modules: string[];
  reassessment: string;
};

const SEVERITY_COLOR: Record<GapView["severity"], string> = {
  high: "var(--color-severity-high)",
  medium: "var(--color-severity-medium)",
  low: "var(--color-severity-low)",
};

/** Headline index card. Refuses to render a number when coverage is too low. */
export function MatchIndexCard({
  index,
  coverage,
  roleTitle,
  reportable = true,
  summary,
}: {
  index: number;
  coverage: number;
  roleTitle: string;
  reportable?: boolean;
  summary: string;
}) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-[0.625rem] font-semibold uppercase tracking-[0.1em] text-[var(--color-muted-deep)]">
            Career Match Index
          </p>
          <p className="mt-1 text-sm text-[var(--color-muted)]">{roleTitle}</p>
        </div>
        <Chip tone="accent">cmi-2024.1</Chip>
      </div>

      {reportable ? (
        <div className="mt-4 flex items-end gap-2">
          <span className="score-display text-5xl font-semibold text-[var(--color-foreground)]">
            {index.toFixed(1)}
          </span>
          <span className="pb-1.5 text-base text-[var(--color-muted)]">/100</span>
        </div>
      ) : (
        <div className="mt-4">
          <p className="text-lg font-semibold text-[var(--color-not-assessed)]">Not enough evidence yet</p>
          <p className="mt-1 text-xs text-[var(--color-muted)]">
            The index is withheld until coverage improves, so no number can be read out of context.
          </p>
        </div>
      )}

      <div className="mt-4">
        <div className="flex items-baseline justify-between text-xs">
          <span className="text-[var(--color-muted)]">Evidence coverage</span>
          <span className="tabular font-medium text-[var(--color-foreground-soft)]">
            {Math.round(coverage * 100)}%
          </span>
        </div>
        <div className="mt-1.5">
          <ScoreBar
            value={coverage * 100}
            label="Evidence coverage"
            size="sm"
            color={coverage >= 0.6 ? "var(--color-success)" : "var(--color-warning)"}
          />
        </div>
      </div>

      <p className="mt-4 border-t border-[var(--color-border)] pt-3 text-xs leading-relaxed text-[var(--color-muted)]">
        {summary}
      </p>
    </Card>
  );
}

/** Per-component breakdown. The NOT_ASSESSED branch is the whole point. */
export function IndexBreakdownCard({ components }: { components: ComponentView[] }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-[var(--color-foreground)]">Why you scored this</h2>
        <span className="text-[0.625rem] text-[var(--color-muted-deep)]">Weights renormalised over assessed terms</span>
      </div>

      <ul className="mt-4 flex flex-col gap-4">
        {components.map((component) => {
          const assessed = component.percent !== null;
          return (
            <li key={component.key}>
              <div className="flex flex-wrap items-baseline justify-between gap-x-3">
                <span className="text-sm font-medium text-[var(--color-foreground-soft)]">
                  {component.label}
                  <span className="ml-2 font-mono text-[0.625rem] text-[var(--color-muted-deep)]">
                    w {Math.round(component.weight * 100)}%
                  </span>
                </span>
                {assessed ? (
                  <span className="tabular text-sm font-semibold text-[var(--color-foreground)]">
                    {component.percent!.toFixed(1)}%
                  </span>
                ) : (
                  <span className="text-xs font-semibold uppercase tracking-[0.06em] text-[var(--color-not-assessed)]">
                    Not assessed
                  </span>
                )}
              </div>

              <div className="mt-1.5">
                <ScoreBar
                  value={component.percent}
                  label={component.label}
                  size="sm"
                  color={
                    component.percent === null
                      ? undefined
                      : component.percent >= 75
                        ? "var(--color-success)"
                        : component.percent >= 50
                          ? "var(--color-warning)"
                          : "var(--color-severity-high)"
                  }
                />
              </div>

              <p className="mt-2 text-xs leading-relaxed text-[var(--color-muted)]">{component.rationale}</p>

              {assessed && component.evidence.length ? (
                <ul className="mt-2 flex flex-col gap-1">
                  {component.evidence.slice(0, 3).map((item) => (
                    <li key={item} className="flex gap-2 text-[0.6875rem] text-[var(--color-foreground-soft)]">
                      <span aria-hidden className="mt-1.5 size-1 shrink-0 rounded-full bg-[var(--color-success)]" />
                      {item}
                    </li>
                  ))}
                </ul>
              ) : null}

              {component.missingEvidence.length ? (
                <div className="mt-2.5 rounded-md border border-[color-mix(in_oklab,var(--color-electric)_25%,transparent)] bg-[color-mix(in_oklab,var(--color-electric)_6%,transparent)] px-3 py-2">
                  <p className="text-[0.625rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-electric-bright)]">
                    To include this term
                  </p>
                  <ul className="mt-1 flex flex-col gap-0.5">
                    {component.missingEvidence.map((item) => (
                      <li key={item} className="text-[0.6875rem] text-[var(--color-muted)]">
                        · {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}

              <p className="mt-1.5 text-[0.625rem] text-[var(--color-muted-deep)]">
                Measurement confidence {Math.round(component.confidence * 100)}%
              </p>
            </li>
          );
        })}
      </ul>
    </Card>
  );
}

/** Ranked gaps with the SRS-required fields per gap. */
export function GapListCard({ gaps }: { gaps: GapView[] }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-[var(--color-foreground)]">Prioritised gaps</h2>
        <Link href="/dashboard" className="text-xs text-[var(--color-accent-bright)] hover:underline">
          Open roadmap
        </Link>
      </div>

      <ul className="mt-4 flex flex-col gap-3">
        {gaps.map((gap) => (
          <li
            key={gap.name}
            className="rounded-[var(--radius-card)] border border-[var(--color-border)] bg-[var(--color-background)]/50 p-4"
          >
            <div className="flex flex-wrap items-center gap-2.5">
              <span
                className="rounded-full px-2 py-0.5 text-[0.5625rem] font-bold tracking-[0.06em] text-[var(--color-void)]"
                style={{ backgroundColor: SEVERITY_COLOR[gap.severity] }}
              >
                {gap.severity.toUpperCase()}
              </span>
              <span className="text-sm font-semibold text-[var(--color-foreground)]">{gap.name}</span>
              <span className="ml-auto font-mono text-[0.625rem] text-[var(--color-muted-deep)]">
                {gap.effort} · {gap.hours}h
              </span>
            </div>

            <p className="mt-2.5 text-xs leading-relaxed text-[var(--color-muted)]">{gap.roleRelevance}</p>
            <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-foreground-soft)]">
              <span className="font-medium text-[var(--color-muted-deep)]">Reason: </span>
              {gap.reason}
            </p>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {gap.modules.map((module) => (
                <span
                  key={module}
                  className="rounded-md border border-[var(--color-border)] bg-[var(--color-surface-raised)] px-2 py-0.5 font-mono text-[0.625rem] text-[var(--color-accent-bright)]"
                >
                  {module}
                </span>
              ))}
            </div>

            <p className="mt-2.5 border-t border-[var(--color-border)] pt-2 text-[0.625rem] text-[var(--color-muted-deep)]">
              {gap.reassessment}
            </p>
          </li>
        ))}
      </ul>
    </Card>
  );
}

/** Preparation progress across the four practice surfaces. */
export function ProgressCard({
  rows,
}: {
  rows: { label: string; attempted: number; accuracy: number; trend: string; tone?: "up" | "flat" | "down" }[];
}) {
  return (
    <Card className="p-5">
      <h2 className="text-sm font-semibold text-[var(--color-foreground)]">Preparation progress</h2>
      <ul className="mt-4 flex flex-col gap-3.5">
        {rows.map((row) => (
          <li key={row.label}>
            <div className="flex items-baseline justify-between gap-3">
              <span className="text-xs font-medium text-[var(--color-foreground-soft)]">{row.label}</span>
              <span className="tabular text-xs text-[var(--color-muted)]">
                {row.attempted} attempts · {row.accuracy}%
              </span>
            </div>
            <div className="mt-1.5">
              <ScoreBar value={row.accuracy} label={`${row.label} accuracy`} size="sm" />
            </div>
            <p
              className={cn(
                "mt-1 text-[0.625rem]",
                row.tone === "up"
                  ? "text-[var(--color-success)]"
                  : row.tone === "down"
                    ? "text-[var(--color-warning)]"
                    : "text-[var(--color-muted-deep)]",
              )}
            >
              {row.trend}
            </p>
          </li>
        ))}
      </ul>
    </Card>
  );
}

/** Next-action card driven by the top-ranked gap. */
export function NextActionCard({
  action,
  skill,
  effort,
  rationale,
  href = "/dashboard",
}: {
  action: string;
  skill: string;
  effort: string;
  rationale: string;
  href?: string;
}) {
  return (
    <Card className="border-[color-mix(in_oklab,var(--color-accent)_40%,transparent)] bg-[color-mix(in_oklab,var(--color-accent)_9%,transparent)] p-5">
      <p className="text-[0.625rem] font-semibold uppercase tracking-[0.1em] text-[var(--color-accent-bright)]">
        Next action
      </p>
      <p className="mt-1.5 text-base font-semibold text-[var(--color-foreground)]">{action}</p>
      <p className="mt-1 text-xs text-[var(--color-muted)]">
        {skill} · {effort}
      </p>
      <p className="mt-3 text-xs leading-relaxed text-[var(--color-muted)]">{rationale}</p>
      <Link href={href} className="btn-primary mt-4 inline-block px-4 py-2 text-xs">
        Start now
      </Link>
    </Card>
  );
}
