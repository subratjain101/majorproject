import * as React from "react";
import { cn } from "@/lib/utils";

/* ==========================================================================
   Shared presentational primitives.

   Deliberately small and unopinionated: the design system lives in
   globals.css, so these compose classes rather than redefining visual rules.
   ========================================================================== */

export function Card({
  className,
  raised = false,
  ...props
}: React.HTMLAttributes<HTMLDivElement> & { raised?: boolean }) {
  return <div className={cn(raised ? "card-raised" : "card", className)} {...props} />;
}

export function Chip({
  className,
  tone = "neutral",
  children,
  ...props
}: React.HTMLAttributes<HTMLSpanElement> & {
  tone?: "neutral" | "accent" | "success" | "warning" | "danger" | "muted";
}) {
  const tones: Record<string, string> = {
    neutral: "",
    accent: "border-[color-mix(in_oklab,var(--color-accent)_45%,transparent)] text-[var(--color-accent-bright)]",
    success: "border-[color-mix(in_oklab,var(--color-success)_40%,transparent)] text-[var(--color-success)]",
    warning: "border-[color-mix(in_oklab,var(--color-warning)_40%,transparent)] text-[var(--color-warning)]",
    danger: "border-[color-mix(in_oklab,var(--color-danger)_40%,transparent)] text-[var(--color-danger)]",
    muted: "text-[var(--color-muted)]",
  };
  return (
    <span className={cn("chip", tones[tone], className)} {...props}>
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className,
}: {
  eyebrow?: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-3",
        align === "center" && "items-center text-center",
        className,
      )}
    >
      {eyebrow ? (
        <span className="eyebrow">
          <span aria-hidden className="size-1.5 rounded-full bg-current" />
          {eyebrow}
        </span>
      ) : null}
      <h2 className="text-balance text-2xl font-semibold tracking-tight text-[var(--color-foreground)] sm:text-3xl">
        {title}
      </h2>
      {description ? (
        <p className="max-w-2xl text-pretty text-sm leading-relaxed text-[var(--color-muted)] sm:text-base">
          {description}
        </p>
      ) : null}
    </div>
  );
}

/**
 * Horizontal score bar with an accessible role.
 *
 * Renders the "not assessed" state distinctly from zero -- a hollow track with
 * a label -- because collapsing the two is the exact failure mode this product
 * exists to prevent.
 */
export function ScoreBar({
  value,
  label,
  color,
  suffix = "",
  indeterminate = false,
  size = "md",
}: {
  value: number | null;
  label: string;
  color?: string;
  suffix?: string;
  indeterminate?: boolean;
  size?: "sm" | "md" | "lg";
}) {
  const height = { sm: "h-1.5", md: "h-2", lg: "h-2.5" }[size];
  const pct = value === null ? 0 : Math.max(0, Math.min(100, value));

  return (
    <div className="w-full">
      <div
        className={cn("w-full overflow-hidden rounded-full bg-[var(--color-surface-overlay)]", height)}
        role="meter"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={value === null ? undefined : Math.round(pct)}
        aria-valuetext={value === null ? "Not assessed" : `${Math.round(pct)} percent`}
        aria-label={label}
      >
        {!indeterminate && value !== null ? (
          <div
            className={cn("h-full rounded-full animate-bar-grow")}
            style={{ width: `${pct}%`, backgroundColor: color ?? "var(--color-accent)" }}
          />
        ) : null}
      </div>
      {suffix ? <p className="mt-1.5 text-xs text-[var(--color-muted)]">{suffix}</p> : null}
    </div>
  );
}

/** Small labelled figure. */
export function Stat({
  label,
  value,
  hint,
  accent,
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  accent?: string;
}) {
  return (
    <div className="flex flex-col gap-1">
      <span className="text-[0.6875rem] font-semibold uppercase tracking-[0.08em] text-[var(--color-muted-deep)]">
        {label}
      </span>
      <span
        className="score-display text-xl font-semibold text-[var(--color-foreground)]"
        style={accent ? { color: accent } : undefined}
      >
        {value}
      </span>
      {hint ? <span className="text-xs text-[var(--color-muted)]">{hint}</span> : null}
    </div>
  );
}
