import type { Metadata } from "next";
import Link from "next/link";
import { DashboardSidebar } from "@/components/dashboard/sidebar";
import {
  GapListCard,
  IndexBreakdownCard,
  MatchIndexCard,
  NextActionCard,
  ProgressCard,
} from "@/components/dashboard/index-cards";
import { Card, Chip } from "@/components/ui/primitives";
import {
  CANDIDATE,
  GAPS,
  INDEX_COMPONENTS,
  MATCH_SUMMARY,
  PROGRESS_ROWS,
} from "@/content/dashboard-data";

export const metadata: Metadata = {
  title: "Dashboard",
  description: "Your career match index, prioritised skill gaps and preparation progress.",
};

/**
 * Candidate dashboard.
 *
 * A server component: there is no client-side state here, so none is shipped.
 * Interactive surfaces (the application modal, the interview runner) opt into
 * client rendering individually rather than forcing the whole page to hydrate.
 */
export default function DashboardPage() {
  return (
    <div className="mx-auto flex w-full max-w-[100rem] flex-col lg:flex-row">
      <DashboardSidebar active="/dashboard" />

      <main id="main" className="min-w-0 flex-1">
        {/* Header */}
        <div className="border-b border-[var(--color-border)] px-5 py-6 sm:px-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-xl font-semibold tracking-tight text-[var(--color-foreground)]">
                {CANDIDATE.name}
              </h1>
              <p className="mt-1 text-sm text-[var(--color-muted)]">{CANDIDATE.headline}</p>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Chip tone="accent">{CANDIDATE.resumeVersion}</Chip>
                <Chip tone={CANDIDATE.consent.recruiterSharing ? "success" : "muted"}>
                  {CANDIDATE.consent.recruiterSharing ? "Recruiter sharing on" : "Recruiter sharing off"}
                </Chip>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Link href="/dashboard" className="btn-secondary px-4 py-2 text-sm">
                Upload new resume
              </Link>
              <Link href="/scorecard" className="btn-primary px-4 py-2 text-sm">
                Start adaptive interview
              </Link>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="grid gap-5 p-5 sm:p-8 xl:grid-cols-[minmax(0,1.55fr)_minmax(0,1fr)]">
          <div className="flex flex-col gap-5">
            <MatchIndexCard
              index={MATCH_SUMMARY.index}
              coverage={MATCH_SUMMARY.coverage}
              roleTitle={MATCH_SUMMARY.roleTitle}
              reportable={MATCH_SUMMARY.reportable}
              summary={MATCH_SUMMARY.summary}
            />
            <IndexBreakdownCard components={INDEX_COMPONENTS} />
          </div>

          <div className="flex flex-col gap-5">
            <NextActionCard
              action="Practise System Design"
              skill="Highest-leverage gap"
              effort="≈4 focused hours · 3 linked modules"
              rationale="Required at 95% importance for your target role, and interviewers commonly probe it. You are 8% below the role's bar, so this is a small gap with a large index payoff."
            />
            <GapListCard gaps={GAPS} />
            <ProgressCard rows={PROGRESS_ROWS} />

            <Card className="p-5">
              <h2 className="text-sm font-semibold text-[var(--color-foreground)]">Privacy & consent</h2>
              <p className="mt-1.5 text-xs leading-relaxed text-[var(--color-muted)]">
                Practice scores are formative feedback, never a hiring decision. Recruiters see your preparation profile
                only for roles you explicitly share, and you can revoke access at any time.
              </p>
              <dl className="mt-4 flex flex-col gap-2 text-xs">
                {[
                  ["Recruiter sharing", CANDIDATE.consent.recruiterSharing],
                  ["Voice interview data retention", CANDIDATE.consent.voiceInterview],
                  ["Anonymised benchmarking", CANDIDATE.consent.anonymisedBenchmarking],
                ].map(([label, enabled]) => (
                  <div key={label as string} className="flex items-center justify-between gap-3">
                    <dt className="text-[var(--color-muted)]">{label as string}</dt>
                    <dd
                      className="font-medium"
                      style={{ color: enabled ? "var(--color-success)" : "var(--color-muted-deep)" }}
                    >
                      {enabled ? "Enabled" : "Disabled"}
                    </dd>
                  </div>
                ))}
              </dl>
              <Link href="/dashboard" className="btn-secondary mt-4 inline-block px-4 py-2 text-xs">
                Manage consent
              </Link>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
