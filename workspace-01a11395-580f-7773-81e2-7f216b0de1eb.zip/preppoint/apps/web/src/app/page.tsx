import { SiteFooter, SiteHeader } from "@/components/landing/chrome";
import { Hero } from "@/components/landing/hero";
import {
  CareerMatchIndexSection,
  HowItWorksSection,
  ProblemSection,
  ResumeIntelligenceSection,
} from "@/components/landing/intelligence";
import {
  AdaptiveInterviewSection,
  SkillGapRoadmapSection,
  TransparentScorecardSection,
} from "@/components/landing/practice";
import {
  CareerIntelligenceSection,
  FinalCtaSection,
  OpenSourceSection,
  RecruiterHubSection,
  ResponsibleAiSection,
} from "@/components/landing/ecosystem";

export default function LandingPage() {
  return (
    <>
      <SiteHeader />
      <main id="main">
        <Hero />
        <ProblemSection />
        <HowItWorksSection />
        <ResumeIntelligenceSection />
        <CareerMatchIndexSection />
        <SkillGapRoadmapSection />
        <AdaptiveInterviewSection />
        <TransparentScorecardSection />
        <CareerIntelligenceSection />
        <RecruiterHubSection />
        <ResponsibleAiSection />
        <OpenSourceSection />
        <FinalCtaSection />
      </main>
      <SiteFooter />
    </>
  );
}
