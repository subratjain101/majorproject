import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "PrepPoint — AI Career Intelligence",
    template: "%s · PrepPoint",
  },
  description:
    "Understand your resume, discover your gaps, practise the right skills, face adaptive interviews, and see exactly why you scored the way you did.",
  applicationName: "PrepPoint",
  keywords: [
    "career intelligence",
    "resume analysis",
    "interview preparation",
    "skill gap analysis",
    "adaptive interview",
    "transparent recruitment",
  ],
  authors: [{ name: "PrepPoint contributors" }],
  license: "MIT",
  openGraph: {
    title: "PrepPoint — AI Career Intelligence",
    description:
      "AI career intelligence for the way you actually get hired. Evidence-linked scoring, adaptive interviews, transparent recruitment.",
    type: "website",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#070b14",
  colorScheme: "dark",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-dvh bg-ambient">{children}</body>
    </html>
  );
}
