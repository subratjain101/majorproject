import type { Metadata } from "next";
import Link from "next/link";
import { DashboardSidebar } from "@/components/dashboard/sidebar";
import { Card, CheckRow } from "@/components/scorecard/parts";
import { ScorecardView } from "@/components/scorecard/scorecard-view";
import { SCORECARD } from "@/content/scorecard-data";

export const metadata: Metadata = {
  title: "Transparent Scorecard",
  description:
    "Every dimension of your practice interview score, with the evidence, reasoning, provenance and improvement path behind it.",
};

export default function ScorecardPage() {
  return (
    <div className="mx-auto flex w-full max-w-[100rem] flex-col lg:flex-row">
      <DashboardSidebar />

      <main id="main" className="min-w-0 flex-1">
        <div className="border-b border-[var(--color-border)] px-5 py-6 sm:px-8">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Link href="/dashboard" className="text-xs text-[var(--color-muted)] hover:underline">
                  Dashboard
                </Link>
                <span aria-hidden className="text-xs text-[var(--color-muted-deep)]">
                  /
                </span>
                <span className="text-xs text-[var(--color-muted-deep)]">Transparent Scorecard</span>
              </div>
              <h1 className="mt-2 text-xl font-semibold tracking-tight text-[var(--color-foreground)]">
                Adaptive interview scorecard
              </h1>
              <p className="mt-1 text-sm text-[var(--color-muted)]">
                {SCORECARD.sessionLabel} · {SCORECARD.questionCount} questions ·{" "}
                {SCORECARD.durationLabel}
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button type="button" className="btn-secondary px-4 py-2 text-sm">
                Export scorecard
              </button>
              <button type="button" className="btn-secondary px-4 py-2 text-sm">
                Request human review
              </button>
              <button type="button" className="btn-primary px-4 py-2 text-sm">
                Retake interview
              </button>
            </div>
          </div>
        </div>

        <div className="p-5 sm:p-8">
          <ScorecardView scorecard={SCORECARD} />

          {/* What this score is not */}
          <Card className="mt-5 p-5">
            <h2 className="text-sm font-semibold text-[var(--color-foreground)]">
              What this scorecard is — and is not
            </h2>
            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <div className="rounded-[var(--radius-card)] border border-[color-mix(in_oklab,var(--color-success)_30%,transparent)] bg-[color-mix(in_oklab,var(--color-success)_7%,transparent)] p-4">
                <p className="text-[0.625rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-success)]">
                  This is
                </p>
                <ul className="mt-3 flex flex-col gap-2.5">
                  {[
                    "Formative feedback on one practice exercise",
                    "A weighted rubric judgement, with cited evidence per dimension",
                    "Reproducible: the rubric, prompt and model versions are recorded",
                    "Disputable — you can request a review or contest any dimension",
                  ].map((item) => (
                    <CheckRow key={item} tone="success">
                      {item}
                    </CheckRow>
                  ))}
                </ul>
              </div>

              <div className="rounded-[var(--radius-card)] border border-[color-mix(in_oklab,var(--color-danger)_30%,transparent)] bg-[color-mix(in_oklab,var(--color-danger)_7%,transparent)] p-4">
                <p className="text-[0.625rem] font-semibold uppercase tracking-[0.09em] text-[var(--color-danger)]">
                  This is not
                </p>
                <ul className="mt-3 flex flex-col gap-2.5">
                  {[
                    "A hiring decision, or any prediction that you will or will not be hired",
                    "A personality, culture-fit, emotion or temperament assessment",
                    "A judgement of your accent, fluency, or any protected attribute",
                    "Visible to any employer unless you explicitly share it",
                  ].map((item) => (
                    <CheckRow key={item} tone="danger">
                      {item}
                    </CheckRow>
                  ))}
                </ul>
              </div>
            </div>

            <p className="mt-5 border-t border-[var(--color-border)] pt-4 text-xs leading-relaxed text-[var(--color-muted-deep)]">
              Disagree with a dimension? Disputes are recorded against the scorecard with the full provenance attached,
              so a reviewer sees exactly what the model saw and which rubric version produced the score.
            </p>
          </Card>
        </div>
      </main>
    </div>
  );
}
