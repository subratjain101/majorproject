import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/** Merge Tailwind classes with conflict resolution. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Clamp a number to an inclusive range. */
export function clamp(value: number, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value));
}

/**
 * Format an index score for display.
 *
 * Returns null for an unassessable score so that callers are forced to render
 * the "not enough evidence" state rather than printing a number the API
 * deliberately withheld.
 */
export function formatScore(value: number | null | undefined): string | null {
  if (value === null || value === undefined || Number.isNaN(value)) return null;
  return value.toFixed(1);
}

/**
 * Contrast-safe severity colour token for a 0-1 severity or fit value.
 * Uses the design system's severity ramp so every surface agrees.
 */
export function severityVar(severity: "high" | "medium" | "low" | "none" | "not_assessed") {
  switch (severity) {
    case "high":
      return "var(--color-severity-high)";
    case "medium":
      return "var(--color-severity-medium)";
    case "low":
      return "var(--color-severity-low)";
    case "not_assessed":
      return "var(--color-not-assessed)";
    default:
      return "var(--color-success)";
  }
}
