/* ==========================================================================
   Scorecard fixture.

   The shape mirrors `Scorecard.to_dict()` in
   services/api/app/domain/evaluation/rubric.py exactly.

   Arithmetic note: the overall shown is the true weighted mean of the assessed
   dimensions. A product whose entire premise is "we show our working" cannot
   ship a headline number that does not add up, so this is verified rather than
   copied from the specification's illustrative example.
   ========================================================================== */

export type EvidenceItem = {
  quote: string;
  point?: string;
  supports?: boolean;
};

export type Dimension = {
  dimension: string;
  label: string;
  weight: number;
  score: number | null;
  status: "assessed" | "not_assessed" | "partial";
  rationale: string;
  improvement?: string;
  confidence: number;
  /** Expected rubric points the answer never addressed. */
  missingPoints: string[];
  evidence: EvidenceItem[];
  notAssessedReason?: string;
};

export type Scorecard = {
  assessmentId: string;
  sessionLabel: string;
  questionCount: number;
  durationLabel: string;
  roleTitle: string;
  overall: number;
  assessedWeightFraction: number;
  summary: string;
  strengths: string[];
  priorities: string[];
  disclaimer: string;
  provenance: [string, string][];
  dimensions: Dimension[];
};

export const SCORECARD: Scorecard = {
  assessmentId: "asmt_01J8QK4M2X",
  sessionLabel: "Session of 7 October 2026, 14:22 UTC",
  questionCount: 6,
  durationLabel: "31 minutes",
  roleTitle: "Backend Engineer · Northwind",
  overall: 77,
  assessedWeightFraction: 1.0,
  summary:
    "Full rubric coverage on this answer. Strongest relative result: technical correctness. Biggest lever for your next attempt: problem solving.",
  strengths: [
    "Technical correctness: correct high-level architecture with accurate terminology.",
    "Communication: restated the constraint before answering, which made the reasoning easy to follow.",
  ],
  priorities: [
    "Add an explicit failure-mode analysis whenever you design for durability.",
    "State your conclusion before walking through the detail.",
  ],
  disclaimer:
    "PRACTICE FEEDBACK — NOT A HIRING DECISION. This scorecard measures how you performed on a practice exercise. It is not an assessment of your ability to do a job, it has not been reviewed by a human, and no employer can see it unless you explicitly share it.",

  provenance: [
    ["Rubric version", "interview-rubric-2024.1"],
    ["Prompt version", "interview-eval-prompt-2024.1"],
    ["Schema version", "scorecard-schema-1.0"],
    ["Assessment type", "interview_text"],
    ["Provider", "gemini"],
    ["Model", "gemini-1.5-pro"],
    ["Latency", "1,420 ms"],
    ["Tokens (prompt / completion)", "3,184 / 612"],
    ["Evaluated at", "2026-10-07T14:22:48Z"],
    ["Fallback used", "No — primary provider responded"],
  ],

  dimensions: [
    {
      dimension: "technical_correctness",
      label: "Technical correctness",
      weight: 0.4,
      score: 82,
      status: "assessed",
      confidence: 0.88,
      rationale:
        "Correct high-level architecture, and the stateless claim is right. Edge-case handling around partial failure was not addressed, which is the one material gap in an otherwise accurate answer.",
      improvement:
        "Practise distributed caching and failure-recovery patterns, then re-answer with an explicit failure-mode section.",
      missingPoints: ["Addresses edge cases, constraints or failure modes"],
      evidence: [
        {
          quote: "I'd put a thin gateway in front of the write path so the API layer stays stateless",
          point: "States the core mechanism correctly",
          supports: true,
        },
        {
          quote: "the gateway can just route to any healthy node, so we scale horizontally",
          point: "Uses role-relevant terminology accurately",
          supports: true,
        },
      ],
    },
    {
      dimension: "problem_solving",
      label: "Problem solving",
      weight: 0.3,
      score: 71,
      status: "assessed",
      confidence: 0.82,
      rationale:
        "Two options were compared explicitly and the sharding trade-off was reasoned correctly. No failure-mode analysis for a hot merchant, and the answer stops short of stating which option you would choose.",
      improvement: "Add a hot-key or skew analysis to at least one design answer, and commit to a recommendation.",
      missingPoints: [
        "Addresses edge cases, constraints or failure modes",
        "Arrives at a defensible conclusion",
      ],
      evidence: [
        {
          quote:
            "so we could either shard by merchant or by time — sharding by merchant keeps a merchant's writes on one node",
          point: "Considers at least two options or trade-offs",
          supports: true,
        },
        {
          quote: "which is good until one merchant gets big enough to saturate their shard",
          point: "Addresses edge cases, constraints or failure modes",
          supports: true,
        },
      ],
    },
    {
      dimension: "communication",
      label: "Communication",
      weight: 0.2,
      score: 79,
      status: "assessed",
      confidence: 0.85,
      rationale:
        "Ordered and followable. Restating the constraint before answering made the reasoning easy to track, though the conclusion arrived late in the answer rather than up front.",
      improvement:
        "State the conclusion explicitly before walking through the detail. This is the single highest-value change to your interview style.",
      missingPoints: ["Conclusion is stated, not left implicit"],
      evidence: [
        {
          quote: "Let me restate the constraint first: we need idempotency across retries",
          point: "Answer is ordered and followable",
          supports: true,
        },
      ],
    },
    {
      dimension: "role_relevance",
      label: "Role relevance",
      weight: 0.1,
      score: 74,
      status: "assessed",
      confidence: 0.78,
      rationale:
        "Grounded in the target role's domain rather than generic textbook material, though the scale discussion stayed generic when the posting makes transaction volume explicit.",
      improvement: "Reference the role's stated transaction volume to sharpen the capacity discussion.",
      missingPoints: ["Accounts for the role's likely scale or constraints"],
      evidence: [
        {
          quote:
            "in a payments context that matters because double-charging is the failure everyone remembers",
          point: "References the role's domain or stack",
          supports: true,
        },
      ],
    },
  ],
};

/**
 * Worked example of the renormalisation rule (SRS §9, §14).

 * Included on the page because it is the clearest demonstration of the
 * platform's central claim, and because the honest side effect is worth
 * stating out loud rather than hiding.
 */
export const RENORMALISATION_DEMO = {
  scenario: "Same session, if Role relevance had fallen below the evidence threshold",
  rows: [
    { label: "Technical correctness", weight: 0.4, score: 82, assessed: true },
    { label: "Problem solving", weight: 0.3, score: 71, assessed: true },
    { label: "Communication", weight: 0.2, score: 79, assessed: true },
    { label: "Role relevance", weight: 0.1, score: null, assessed: false },
  ],
  fullyAssessed: 77,
  renormalised: 78,
  explanation:
    "Excluding a below-average dimension raises the mean, which is simple arithmetic and true of any renormalisation. That is exactly why we also publish evidence coverage: the renormalised number is only trustworthy when you can see how much of the rubric it is built on. We would rather show you both than quietly pick one.",
};
