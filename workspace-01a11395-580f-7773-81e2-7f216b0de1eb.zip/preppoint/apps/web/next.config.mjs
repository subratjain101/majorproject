/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Standalone output keeps the production image small (see
  // infrastructure/docker/web.Dockerfile). It has no effect on `next dev`.
  output: "standalone",
  poweredByHeader: false,
  // Preview environments proxy the app from a different origin, so the dev
  // server must accept that host rather than reject it.
  allowedDevOrigins: ["*.e2b.app", "*.arena.ai", "localhost"],
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          {
            key: "Permissions-Policy",
            // No microphone or camera access is requested anywhere outside the
            // optional voice interview, which asks explicitly at the point of use.
            value: "camera=(), geolocation=(), microphone=(self)",
          },
        ],
      },
    ];
  },
};
export default nextConfig;
