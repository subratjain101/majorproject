# PrepPoint

**AI Career Intelligence, interview preparation and transparent recruitment — open source.**

Built for candidates. Designed for transparency.

[![tests](https://img.shields.io/badge/tests-145%20passing-brightgreen)](#testing)
[![license](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![python](https://img.shields.io/badge/python-3.13-blue)](services/api)
[![next](https://img.shields.io/badge/next.js-15-black)](apps/web)

---

## What this is

Most career tools measure you and stop there. An ATS checker tells you 63/100
and never says what it measured, what it ignored, or what to do next. A practice
site generates interview questions without adapting to your answers. A job board
matches on keywords and calls it intelligence.

PrepPoint is one integrated preparation loop, built on a single premise:

> **If a system cannot show its reasoning, it has no business giving career advice.**

So every meaningful score on this platform answers five questions: *what was
assessed, what evidence supported it, what evidence was missing, why this score,
and which rubric/model/prompt version produced it.* Where there is insufficient
evidence, the platform says **not assessed** rather than inventing a number.

---

## The three ideas that make it different

### 1. Missing evidence is not a zero

The Career Match Index is renormalised over the components we could actually
assess:

```
M = 100 × min(1, 0.50·fsk + 0.25·fse + 0.15·fex + 0.10·fed)
```

If a resume's education section cannot be parsed, **education fit is excluded**
and the remaining weights are renormalised — it is not counted as zero. The
confidence-weighted evidence coverage is reported alongside so the candidate can
see exactly how much of the index is backed by evidence, and below a configurable
coverage floor the headline number is withheld entirely.

The API enforces this through the type system: an unreportable index is returned
as `display_index: null`, so a client cannot render an indefensible number by
forgetting a flag.

### 2. Scores cite their evidence

Every evaluated dimension carries the quoted text it was judged on, the rubric
version, the model version, the prompt version, the latency, and an improvement
step. If a dimension cannot be judged, it is `NOT_ASSESSED` and excluded from the
weighted overall:

```
Overall = Σ(wₖ · Dₖ) / Σ(wₖ)     over assessed dimensions only
```

This renormalisation is the mechanism that stops *"we could not tell"* from
silently becoming *"you were average"* — the most common way AI interview tools
mislead people.

### 3. Refusing to infer is a feature

The platform will not infer personality, emotion, health, or any protected
attribute — not from text, not from voice, not from video. The original prototype
inferred facial and behavioural signals from webcam frames; that capability was
**deleted rather than ported**. Prompts do not carry the policy alone: structural
tests assert that AI output shapes contain no control fields, so model output can
never change permissions, grant roles, alter scores or publish moderation
decisions.

---

## Repository layout

```
preppoint/
├── apps/
│   ├── web/                 Next.js 15 · TypeScript · Tailwind 4 · server components
│   └── docs/                documentation site
├── services/
│   ├── api/                 FastAPI · SQLAlchemy 2 · Pydantic v2
│   │   └── app/
│   │       ├── domain/      PURE domain logic — no web, no DB, no vendor SDK
│   │       │   ├── matching/    Career Match Index, fitness terms, semantic fit
│   │       │   ├── skills/      skill gap engine, severity, roadmap ordering
│   │       │   ├── interview/   adaptive ability estimation
│   │       │   └── evaluation/  evidence-linked rubrics and scorecards
│   │       ├── ai/          provider-agnostic gateway, retries, validation
│   │       ├── core/        settings, redaction, security primitives
│   │       ├── api/v1/      transport only
│   │       └── schemas/     OpenAPI wire contracts
│   ├── worker/              background jobs: resume, evaluation, moderation
│   └── sandbox/             isolated code execution — no network, capped, timed
├── packages/                shared-types · ui · config · validation
├── database/                migrations · seeds · schema
├── infrastructure/          docker · nginx · terraform · deployment
├── tests/                   unit · integration · e2e · security
└── docs/                    architecture · api · security · ai · contributing
```

The `domain/` packages import **no** web framework, ORM or vendor SDK. They are
plain Python, unit-testable without a database or network, and reusable by the
worker and API alike.

---

## Quick start

### Web (no configuration required)

```bash
cd apps/web
npm install
npm run dev                      # http://localhost:3000
```

### API

```bash
cd services/api
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload    # http://localhost:8000/docs
```

The API runs with **no AI provider configured**. Resume analysis and interview
evaluation report themselves as degraded rather than failing, and every
deterministic engine (match index, gap analysis, adaptation, scoring) works
fully offline.

### Full stack

```bash
cp .env.example .env             # add provider keys if you have them
docker compose up --build
```

Brings up Postgres, Redis, the API, the worker, the sandbox runner, the web app
and Nginx.

---

## Testing

```bash
cd services/api && pytest -q     # 145 tests
cd apps/web && npm run typecheck
```

The suite deliberately includes tests that **assert refusals**, because the
failures that matter here are not user-visible bugs:

| Area | What is asserted |
|---|---|
| `test_career_match.py` | SRS formula implemented exactly; missing sections never score zero; weights sum to 1; unreportable index is unreadable |
| `test_skill_gap.py` | Severity tracks gap size, not job-description shape; requirement kind caps severity; prerequisite cycles cannot hang the worker |
| `test_interview_and_scorecard.py` | Difficulty never escapes [Easy, Hard] against 40 consecutive extremes; unassessed answers cannot steer the interview; overall renormalises over assessed dimensions only |
| `test_security.py` | Emails, phones, DOB, protected attributes and names are redacted; redaction **fails closed**; the gateway never fabricates a score; malformed model output is rejected, not clamped; AI output shapes contain no control fields |

---

## Two real bugs this process caught

Recorded because they are the reason the tests exist.

**Severity measured the job description, not the candidate.** The first severity
formula added a flat bonus for a skill being *required*. The effect: a candidate
8% below the bar on an important skill — a four-hour fix — was flagged **HIGH**
priority alongside a genuinely absent forty-hour skill. Every required skill
cleared the HIGH threshold regardless of gap size. Fixed by weighting severity by
shortfall and capping it by requirement kind.

**Skill-fit confidence counted keywords, not evidence.** Confidence was computed
from the *number* of skills present, so a resume listing thirty skills with no
supporting detail scored identical confidence to one with a deep work history. A
confidence-weighted coverage metric replaced it — which is also what stopped a
single listed skill from publishing a headline match index.

Both are now regression-tested.

---

## Documentation

- [`docs/architecture/ASSUMPTIONS.md`](docs/architecture/ASSUMPTIONS.md) — **read this first.** Every decision that goes beyond the written brief, with reasoning and revisit conditions.
- [`docs/architecture/DECISIONS.md`](docs/architecture/DECISIONS.md) — architecture decision records
- [`docs/ai/SCORING.md`](docs/ai/SCORING.md) — the scoring model in detail
- [`docs/security/THREAT-MODEL.md`](docs/security/THREAT-MODEL.md) — threat model and mitigations
- [`docs/contributing/`](docs/contributing/) — how to contribute

---

## Configuration

Nothing security-relevant is hard-coded, and no scoring weight lives in
application code. Scoring configuration is versioned and stamped onto every
result:

```bash
CAREER_MATCH_CONFIG_VERSION=cmi-2024.1     # recorded with every score
AI_PROVIDER_ORDER=gemini,openai,groq,local # preference order; falls back on failure
GEMINI_API_KEY=                            # omit to run degraded
SANDBOX_URL=http://sandbox:8100
MIN_EVIDENCE_COVERAGE=0.60                 # index withheld below this coverage
```

See [`.env.example`](.env.example) for the full list.

---

## Status

Honest accounting of what is built versus specified.

**Complete and tested**

- Career Match Index engine with four explainable fitness terms, versioned config, evidence-coverage gating
- Skill gap engine: severity, evidence, effort estimates, prerequisite-aware roadmap, reassessment paths
- Adaptive interview: logistic ability estimation, tempered updates, SRS difficulty transitions, unassessed-item handling
- Evidence-linked scorecard with full provenance and renormalised overall
- Identifier redaction that fails closed
- AI gateway: bounded retries, schema validation, provider fallback, safe degradation
- FastAPI service with OpenAPI, correlation IDs, health reporting
- Landing page (all 13 sections), candidate dashboard, transparent scorecard — responsive, keyboard accessible, WCAG 2.2 AA targeted

**Scaffolded, not yet implemented**

- Resume parsing pipeline (PDF/DOCX extraction, section detection) — the domain contract exists, the extractor does not
- Persistence layer: models, Alembic migrations, seed taxonomy
- Auth, sessions, RBAC, consent records, audit log storage
- DSA problem bank, aptitude question bank, and the sandbox runner
- Worker queue, moderation queue, notification dispatch
- Recruiter console
- Voice interview adapters (STT/TTS interfaces are defined; no adapters are wired)

This is a foundation with the hard, differentiating logic implemented and tested
— not a finished product. The [`ASSUMPTIONS.md`](docs/architecture/ASSUMPTIONS.md)
file records every extrapolation.

---

## Contributing

Contributions are welcome. Two rules matter more than the rest:

1. **Never fabricate a score.** If evidence is insufficient, return
   `NOT_ASSESSED`. A missing score is recoverable; a confidently wrong one is not.
2. **Never add an inference we have committed to refusing.** No emotion,
   personality, health or protected-attribute inference — not even as an
   experiment behind a flag.

Run `pytest` before opening a pull request. New scoring behaviour requires a new
configuration version.

---

## License

MIT — see [LICENSE](LICENSE).

---

Practice scores on this platform are formative feedback and are never a hiring
decision.
