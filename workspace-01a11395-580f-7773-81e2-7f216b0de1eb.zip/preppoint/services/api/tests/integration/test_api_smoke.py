"""Integration smoke tests for the HTTP layer.

These assert the *contract* the frontend depends on, in particular that an
unreportable index arrives as ``display_index: null`` rather than as a
plausible-looking number.
"""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)

STRONG_ROLE = {
    "role_id": "role-backend-eng",
    "title": "Backend Engineer",
    "description": "Build and operate distributed payment services on AWS.",
    "min_years_experience": 3.0,
    "max_years_experience": 7.0,
    "education_level": 4,
    "requirements": [
        {"skill_id": "python", "canonical_name": "Python", "kind": "required",
         "importance": 1.0, "required_proficiency": 0.7, "prep_hours_from_zero": 12},
        {"skill_id": "sql", "canonical_name": "SQL", "kind": "required",
         "importance": 0.9, "required_proficiency": 0.6, "prep_hours_from_zero": 10},
        {"skill_id": "system-design", "canonical_name": "System Design", "kind": "required",
         "importance": 0.95, "required_proficiency": 0.6, "prep_hours_from_zero": 40,
         "prerequisites": ["python"]},
        {"skill_id": "docker", "canonical_name": "Docker", "kind": "preferred",
         "importance": 0.6, "required_proficiency": 0.5, "prep_hours_from_zero": 14},
    ],
}

STRONG_CANDIDATE = {
    "summary_text": "Backend engineer with seven years building distributed payment systems in Python.",
    "skills": [
        {"skill_id": "python", "proficiency": 0.9, "confidence": 0.95,
         "evidence": ["Built Python payment services at Acme"]},
        {"skill_id": "sql", "proficiency": 0.8, "confidence": 0.9,
         "evidence": ["Owned PostgreSQL schema"]},
        {"skill_id": "docker", "proficiency": 0.75, "confidence": 0.85},
        {"skill_id": "system-design", "proficiency": 0.55, "confidence": 0.7},
    ],
    "educations": [{"level": 4, "degree_name": "B.Tech", "institution": "IIT Delhi", "end_year": 2019}],
    "experiences": [
        {"title": "Backend Engineer", "company": "Acme",
         "start_date": "2019-07-01T00:00:00", "end_date": "2023-06-30T00:00:00",
         "description": "Built distributed payment services in Python on AWS."},
        {"title": "Senior Backend Engineer", "company": "Globex",
         "start_date": "2023-07-01T00:00:00", "is_current": True},
    ],
}


def test_health_reports_config_versions():
    response = client.get("/api/v1/health")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "ok"
    assert body["match_config_version"] == "cmi-2024.1"
    assert body["ai_providers"]["degraded"] is True  # no keys in test env


def test_health_never_leaks_key_material():
    body = client.get("/api/v1/health").json()
    serialised = str(body).lower()
    for forbidden in ("api_key", "apikey", "secret", "sk-", "bearer"):
        assert forbidden not in serialised


def test_match_returns_full_component_breakdown():
    response = client.post("/api/v1/matching/match", json={"candidate": STRONG_CANDIDATE, "role": STRONG_ROLE})
    assert response.status_code == 200, response.text
    body = response.json()

    assert body["is_reportable"] is True
    assert body["display_index"] is not None
    assert body["config_version"] == "cmi-2024.1"
    assert len(body["components"]) == 4
    for component in body["components"]:
        assert component["rationale"], f"{component['key']} must explain itself"

    weights = {c["key"]: c["weight"] for c in body["components"]}
    assert weights == {"skill": 0.5, "semantic": 0.25, "experience": 0.15, "education": 0.1}


def test_unreportable_index_arrives_as_null_not_a_number():
    """The client renders the empty state from null; it must never receive 0."""
    payload = {
        "candidate": {"skills": [{"skill_id": "python", "proficiency": 0.8, "confidence": 0.2}]},
        "role": STRONG_ROLE,
    }
    body = client.post("/api/v1/matching/match", json=payload).json()
    assert body["display_index"] is None
    assert body["is_reportable"] is False
    assert body["index"] is not None  # internal value retained for admin/ranking
    assert body["warnings"]


def test_missing_section_is_not_assessed_and_not_zero():
    candidate = {k: v for k, v in STRONG_CANDIDATE.items() if k != "educations"}
    body = client.post("/api/v1/matching/match", json={"candidate": candidate, "role": STRONG_ROLE}).json()
    education = next(c for c in body["components"] if c["key"] == "education")
    assert education["status"] == "not_assessed"
    assert education["value"] is None
    assert education["missing_evidence"]


def test_skill_gaps_endpoint_returns_actionable_plan():
    response = client.post(
        "/api/v1/matching/skill-gaps", json={"candidate": STRONG_CANDIDATE, "role": STRONG_ROLE}
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["role_title"] == "Backend Engineer"
    assert body["summary"]
    assert body["roadmap_order"]
    for gap in body["high"] + body["medium"] + body["low"]:
        assert gap["role_relevance"]
        assert gap["actions"]
        assert gap["reassessment"]
        assert gap["estimated_preparation_hours"] > 0


def test_roadmap_orders_prerequisites_first():
    body = client.post(
        "/api/v1/matching/skill-gaps",
        json={"candidate": {"skills": []}, "role": STRONG_ROLE},
    ).json()
    order = body["roadmap_order"]
    assert order.index("python") < order.index("system-design")


def test_match_many_ranks_roles():
    junior = {
        "role_id": "role-junior",
        "title": "Junior Engineer",
        "requirements": [{"skill_id": "python", "canonical_name": "Python"}],
        "min_years_experience": 0.0,
        "education_level": 4,
    }
    response = client.post(
        "/api/v1/matching/match-many",
        json={"candidate": STRONG_CANDIDATE, "roles": [STRONG_ROLE, junior]},
    )
    assert response.status_code == 200
    body = response.json()
    assert body["count"] == 2
    assert body["results"][0]["index"] >= body["results"][1]["index"]


def test_invalid_role_band_is_rejected_with_422():
    bad_role = dict(STRONG_ROLE, min_years_experience=8.0, max_years_experience=2.0)
    response = client.post("/api/v1/matching/match", json={"candidate": STRONG_CANDIDATE, "role": bad_role})
    assert response.status_code == 422


def test_out_of_range_proficiency_is_rejected():
    bad = {"skills": [{"skill_id": "python", "proficiency": 1.5}]}
    response = client.post("/api/v1/matching/match", json={"candidate": bad, "role": STRONG_ROLE})
    assert response.status_code == 422


def test_end_date_before_start_date_is_rejected():
    candidate = {
        "experiences": [
            {"title": "Engineer", "start_date": "2024-01-01T00:00:00", "end_date": "2020-01-01T00:00:00"}
        ]
    }
    response = client.post("/api/v1/matching/match", json={"candidate": candidate, "role": STRONG_ROLE})
    assert response.status_code == 422


def test_request_id_header_is_returned_for_tracing():
    response = client.get("/api/v1/health")
    assert response.headers.get("X-Request-ID")
    assert response.headers.get("X-Content-Type-Options") == "nosniff"


def test_unknown_route_does_not_leak_internals():
    response = client.get("/api/v1/does-not-exist")
    assert response.status_code == 404
