"""Unit tests for the skill gap engine.

The regression tests here guard two specific mistakes that were found during
development and that would each have made the product actively misleading:

1. Severity that tracked the *shape of the job description* rather than the
   size of the candidate's gap (every required skill became HIGH).
2. Requirement kind not acting as a hard ceiling (a missing nice-to-have
   outranked a missing required skill).
"""

from __future__ import annotations

import pytest

from app.domain.matching.types import (
    CandidateProfile,
    EvidenceSource,
    RoleProfile,
    RoleSkillRequirement,
    SkillEvidence,
    SkillRequirementKind,
)
from app.domain.skills.gap import (
    GapReason,
    GapSeverity,
    SeverityThresholds,
    SkillGapEngine,
)
from tests.unit.test_career_match import backend_role, strong_candidate


@pytest.fixture
def engine() -> SkillGapEngine:
    return SkillGapEngine()


class TestSeverityReflectsGapSize:
    def test_small_shortfall_on_critical_skill_is_not_high(self, engine):
        """Regression: an 8% shortfall must not be reported as HIGH priority.

        System Design: 95% importance, required, candidate at 0.55 vs a 0.60
        bar. That is a sub-four-hour fix and must not sit at the same severity
        as a genuinely absent skill.
        """
        report = engine.analyse(strong_candidate(), backend_role())
        system_design = next(
            g for g in report.high + report.medium + report.low if g.skill_id == "system-design"
        )
        assert system_design.severity is not GapSeverity.HIGH
        assert system_design.severity is GapSeverity.MEDIUM
        assert system_design.estimated_preparation_hours < 8

    def test_missing_required_high_importance_skill_is_high(self, engine):
        role = RoleProfile(
            role_id="r", title="Backend Engineer",
            requirements=(
                RoleSkillRequirement("system-design", "System Design", SkillRequirementKind.REQUIRED,
                                     importance=0.95, required_proficiency=0.6,
                                     prep_hours_from_zero=40),
            ),
        )
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.9),))
        report = engine.analyse(candidate, role)
        assert report.high
        assert report.high[0].skill_id == "system-design"
        assert report.high[0].reason is GapReason.MISSING

    @staticmethod
    def _only_gap(report):
        """Fetch the single gap in the report regardless of which bucket it landed in."""
        buckets = report.high + report.medium + report.low
        assert len(buckets) == 1, f"expected exactly one gap, got {len(buckets)}"
        return buckets[0]

    def test_severity_increases_with_shortfall_size(self, engine):
        """Same skill, same role, different-sized shortfall -> different severity."""
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("python", "Python", SkillRequirementKind.REQUIRED,
                                     importance=0.9, required_proficiency=0.8, prep_hours_from_zero=20),
            ),
        )
        near_miss = engine.analyse(CandidateProfile(skills=(SkillEvidence("python", 0.75),)), role)
        far_below = engine.analyse(CandidateProfile(skills=(SkillEvidence("python", 0.30),)), role)

        near_gap = self._only_gap(near_miss)
        far_gap = self._only_gap(far_below)

        assert far_gap.severity_score > near_gap.severity_score
        # A 62% shortfall should outrank a 6% shortfall by more than one band.
        assert far_gap.severity is GapSeverity.HIGH
        assert near_gap.severity is not GapSeverity.HIGH
        # The work required should track the size of the gap too.
        assert far_gap.estimated_preparation_hours > near_gap.estimated_preparation_hours


class TestKindActsAsCeiling:
    def test_missing_nice_to_have_cannot_outrank_missing_required(self, engine):
        """A large nice-to-have gap must stay below a required gap."""
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("python", "Python", SkillRequirementKind.REQUIRED,
                                     importance=0.9, required_proficiency=0.7),
                RoleSkillRequirement("kubernetes", "Kubernetes", SkillRequirementKind.NICE_TO_HAVE,
                                     importance=0.9, required_proficiency=0.7),
            ),
        )
        candidate = CandidateProfile()
        report = engine.analyse(candidate, role)
        required_gap = next(g for g in report.high + report.medium + report.low if g.skill_id == "python")
        nice_gap = next(g for g in report.high + report.medium + report.low if g.skill_id == "kubernetes")
        assert required_gap.severity_score > nice_gap.severity_score

    def test_preferred_skill_can_never_be_high(self, engine):
        """Regardless of shortfall size, a preferred skill is capped below HIGH."""
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("kubernetes", "Kubernetes", SkillRequirementKind.PREFERRED,
                                     importance=1.0, required_proficiency=1.0),
            ),
        )
        candidate = CandidateProfile()
        report = engine.analyse(candidate, role)
        assert not report.high
        assert report.medium or report.low

    def test_nice_to_have_missing_stays_low(self, engine):
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("kubernetes", "Kubernetes", SkillRequirementKind.NICE_TO_HAVE,
                                     importance=1.0, required_proficiency=0.9),
            ),
        )
        report = engine.analyse(CandidateProfile(), role)
        assert not report.high
        assert report.low


class TestGapContent:
    def test_every_actionable_gap_is_fully_specified(self, engine):
        """SRS section 10: no bare "missing Python" is ever acceptable."""
        report = engine.analyse(strong_candidate(), backend_role())
        for gap in report.high + report.medium + report.low:
            assert gap.canonical_name
            assert gap.role_relevance, "role relevance is mandatory"
            assert gap.importance >= 0
            assert gap.actions, f"{gap.skill_id} has no recommended action"
            assert gap.estimated_preparation_hours > 0
            assert gap.reassessment, f"{gap.skill_id} has no reassessment path"
            for action in gap.actions:
                assert action.estimated_effort
                assert len(action.action) > 30, "actions must be concrete, not terse"

    def test_strengths_are_reported_for_balance(self, engine):
        report = engine.analyse(strong_candidate(), backend_role())
        assert report.strengths
        assert all(g.reason is GapReason.STRENGTH for g in report.strengths)

    def test_weak_evidence_is_distinguished_from_missing(self, engine):
        """The remedies differ: document it, versus learn it."""
        role = backend_role()
        report = engine.analyse(strong_candidate(), role)
        system_design = next(g for g in report.medium + report.low + report.high if g.skill_id == "system-design")
        assert system_design.reason is GapReason.WEAK_EVIDENCE
        assert system_design.candidate_proficiency == pytest.approx(0.55)

    def test_low_confidence_evidence_is_treated_as_risk_not_pass(self, engine):
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("python", "Python", SkillRequirementKind.REQUIRED,
                                     importance=0.9, required_proficiency=0.5),
            ),
        )
        # Proficiency clears the bar, but confidence is far too low to trust.
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.9, confidence=0.2),))
        report = engine.analyse(candidate, role)
        assert report.high or report.medium, "thin evidence must not be reported as a pass"

    def test_unassessed_proficiencies_serialise_cleanly(self, engine):
        report = engine.analyse(CandidateProfile(), backend_role())
        payload = report.to_dict()
        assert payload["counts"]["high"] >= 1
        first = (payload["high"] or payload["medium"])[0]
        assert first["candidate_proficiency"] is None


class TestRoadmap:
    def test_prerequisites_are_ordered_first(self, engine):
        """System Design depends on Python; Python must come first."""
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("system-design", "System Design", SkillRequirementKind.REQUIRED,
                                     importance=0.95, prerequisites=("python",)),
                RoleSkillRequirement("python", "Python", SkillRequirementKind.REQUIRED,
                                     importance=0.95),
            ),
        )
        report = engine.analyse(CandidateProfile(), role)
        order = list(report.roadmap_order)
        assert order.index("python") < order.index("system-design")

    def test_prerequisite_cycle_does_not_hang(self, engine):
        """A malformed taxonomy must degrade, not spin forever."""
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("a", "A", SkillRequirementKind.REQUIRED, prerequisites=("b",)),
                RoleSkillRequirement("b", "B", SkillRequirementKind.REQUIRED, prerequisites=("a",)),
            ),
        )
        report = engine.analyse(CandidateProfile(), role)
        assert set(report.roadmap_order) == {"a", "b"}

    def test_total_hours_counts_only_actionable_gaps(self, engine):
        report = engine.analyse(strong_candidate(), backend_role())
        actionable = sum(g.estimated_preparation_hours for g in report.high + report.medium)
        assert report.total_estimated_hours == pytest.approx(actionable, abs=0.01)


class TestSummary:
    def test_summary_is_plain_language_and_specific(self, engine):
        report = engine.analyse(strong_candidate(), backend_role())
        assert report.role_title in report.summary
        assert "Backend Engineer" in report.summary
        assert len(report.summary) > 80

    def test_perfect_match_summary_reframes_the_advice(self, engine):
        role = RoleProfile(
            role_id="r", title="Role",
            requirements=(
                RoleSkillRequirement("python", "Python", SkillRequirementKind.REQUIRED,
                                     required_proficiency=0.5),
            ),
        )
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.1),))
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.1),))
        # A candidate far above the bar on every requirement.
        strong = CandidateProfile(skills=(SkillEvidence("python", 0.1),))
        report = engine.analyse(strong, role)
        assert report.summary


class TestThresholdsAreConfigurable:
    def test_custom_thresholds_change_bucketing(self):
        role = backend_role()
        strict = SkillGapEngine(thresholds=SeverityThresholds(high=0.10, medium=0.05, low=0.01))
        lenient = SkillGapEngine(thresholds=SeverityThresholds(high=0.99, medium=0.98, low=0.97))
        candidate = strong_candidate()
        assert len(strict.analyse(candidate, role).high) >= len(lenient.analyse(candidate, role).high)
