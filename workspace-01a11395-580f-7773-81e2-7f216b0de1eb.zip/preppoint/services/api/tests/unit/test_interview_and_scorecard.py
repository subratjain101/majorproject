"""Tests for adaptive difficulty and evidence-linked scoring.

These cover the SRS's hardest guarantees:

* difficulty never escapes [Easy, Hard];
* a NOT_ASSESSED dimension never becomes a number, and never drags the
  overall toward the middle;
* the overall is Σ(w·D)/Σ(w) over assessed dimensions only;
* every scorecard carries full provenance and the practice disclaimer.
"""

from __future__ import annotations

import math

import pytest

from app.domain.evaluation.rubric import (
    DEFAULT_INTERVIEW_RUBRIC,
    PRACTICE_DISCLAIMER,
    AssessmentStatus,
    AssessmentType,
    Dimension,
    DimensionScore,
    EvaluationProvenance,
    EvidencePoint,
    ScorecardBuilder,
)
from app.domain.interview.ability import AbilityState, AdaptationPolicy, Difficulty


# ---------------------------------------------------------------------------
# Ability estimation
# ---------------------------------------------------------------------------


class TestExpectedScoreCurve:
    def test_logistic_matches_srs_formula(self):
        """E_t = 1 / (1 + e^(-a(θ_t - d_t))) exactly."""
        theta, a = 0.7, 1.9
        difficulty = Difficulty.MEDIUM
        expected = AbilityState.expected_score(theta, difficulty, a)
        reference = 1.0 / (1.0 + math.exp(-a * (theta - difficulty.anchor)))
        assert expected == pytest.approx(reference)

    def test_bounded_in_unit_interval(self):
        for theta in (0.0, 0.25, 0.5, 0.99, 1.0):
            for difficulty in Difficulty:
                value = AbilityState.expected_score(theta, difficulty)
                assert 0.0 <= value <= 1.0

    def test_stronger_candidate_scores_higher_expected(self):
        low = AbilityState.expected_score(0.2, Difficulty.MEDIUM)
        high = AbilityState.expected_score(0.9, Difficulty.MEDIUM)
        assert high > low

    def test_harder_item_lowers_expected_score(self):
        easy = AbilityState.expected_score(0.6, Difficulty.EASY)
        hard = AbilityState.expected_score(0.6, Difficulty.HARD)
        assert easy > hard

    def test_extreme_inputs_do_not_overflow(self):
        """math.exp raises on large arguments, so the guard must saturate.

        Ability far *above* an easy item's difficulty means the candidate is
        expected to answer it: E -> 1. Ability far *below* a hard item's
        difficulty means E -> 0. The guard must produce those limits rather
        than raising OverflowError.
        """
        assert AbilityState.expected_score(50.0, Difficulty.EASY, discrimination=100.0) == 1.0
        assert AbilityState.expected_score(-50.0, Difficulty.HARD, discrimination=100.0) == 0.0
        # Inside the guard's range the logistic simply returns a very small
        # number (here ~9e-242) rather than exactly zero. That is correct
        # behaviour for a continuous function, so assert on magnitude.
        assert AbilityState.expected_score(5.0, Difficulty.MEDIUM, 100.0) == pytest.approx(1.0)
        assert AbilityState.expected_score(-5.0, Difficulty.MEDIUM, 100.0) < 1e-12


class TestDifficultyTransitions:
    @pytest.mark.parametrize(
        ("score", "start", "expected"),
        [
            (8.5, Difficulty.EASY, Difficulty.MEDIUM),
            (8.0, Difficulty.MEDIUM, Difficulty.HARD),
            (4.0, Difficulty.HARD, Difficulty.MEDIUM),
            (4.9, Difficulty.MEDIUM, Difficulty.EASY),
            (6.5, Difficulty.MEDIUM, Difficulty.MEDIUM),   # steady band holds
            (7.8, Difficulty.MEDIUM, Difficulty.HARD),     # boundary is inclusive
            (5.0, Difficulty.HARD, Difficulty.HARD),       # boundary is exclusive below
        ],
    )
    def test_srs_transition_rules(self, score, start, expected):
        state = AbilityState(difficulty=start, items_seen=2)
        state.record(item_id="q1", score_out_of_10=score, difficulty=start)
        assert state.difficulty is expected

    def test_never_exceeds_hard(self):
        state = AbilityState(difficulty=Difficulty.HARD, items_seen=5)
        for i in range(4):
            state.record(item_id=f"q{i}", score_out_of_10=10.0)
        assert state.difficulty is Difficulty.HARD

    def test_never_goes_below_easy(self):
        state = AbilityState(difficulty=Difficulty.EASY, items_seen=5)
        for i in range(4):
            state.record(item_id=f"q{i}", score_out_of_10=0.0)
        assert state.difficulty is Difficulty.EASY

    def test_perfect_run_reaches_hard(self):
        state = AbilityState()
        for i in range(6):
            state.record(item_id=f"q{i}", score_out_of_10=10.0)
        assert state.difficulty is Difficulty.HARD

    def test_poor_run_falls_to_easy(self):
        state = AbilityState()
        for i in range(6):
            state.record(item_id=f"q{i}", score_out_of_10=1.0)
        assert state.difficulty is Difficulty.EASY


class TestThetaUpdates:
    def test_theta_rises_on_good_scores(self):
        state = AbilityState()
        start = state.theta
        state.record(item_id="q", score_out_of_10=9.5)
        assert state.theta > start

    def test_theta_falls_on_poor_scores(self):
        state = AbilityState()
        start = state.theta
        state.record(item_id="q", score_out_of_10=1.0)
        assert state.theta < start

    def test_theta_stays_within_bounds_after_many_updates(self):
        state = AbilityState()
        for i in range(40):
            state.record(item_id=f"q{i}", score_out_of_10=10.0)
        assert 0.0 <= state.theta <= 1.0
        for i in range(40):
            state.record(item_id=f"r{i}", score_out_of_10=0.0)
        assert 0.0 <= state.theta <= 1.0

    def test_beating_expectation_moves_theta_more_than_confirmation(self):
        """The update is driven by surprise, which is what makes it adaptive."""
        ahead = AbilityState(theta=0.5, difficulty=Difficulty.HARD)
        ahead.record(item_id="q", score_out_of_10=9.0, difficulty=Difficulty.HARD)
        gain_surprising = ahead.theta - 0.5

        expected_match = AbilityState(theta=0.5, difficulty=Difficulty.EASY)
        expected_match.record(item_id="q", score_out_of_10=9.0, difficulty=Difficulty.EASY)
        gain_confirming = expected_match.theta - 0.5

        assert gain_surprising > gain_confirming

    def test_learning_rate_is_tempered_during_warmup(self):
        policy = AdaptationPolicy()
        assert policy.learning_rate_for(0) < policy.learning_rate_for(10)

    def test_first_update_cannot_leap_across_bands(self):
        """A single lucky answer must not redefine the interview."""
        state = AbilityState(theta=0.4, difficulty=Difficulty.EASY)
        state.record(item_id="q", score_out_of_10=10.0, difficulty=Difficulty.EASY)
        assert state.theta < 0.75


class TestUnassessedItemsDoNotSteer:
    def test_unassessed_answer_leaves_theta_untouched(self):
        """We must not let a score we refused to fabricate steer the session."""
        state = AbilityState(theta=0.55, difficulty=Difficulty.MEDIUM, items_seen=5)
        before_theta = state.theta
        before_difficulty = state.difficulty
        update = state.record(item_id="q", score_out_of_10=None, assessed=False)

        assert state.theta == before_theta
        assert state.difficulty is before_difficulty
        assert update.assessed is False
        assert "did not affect" in update.rationale

    def test_unassessed_item_is_still_recorded(self):
        state = AbilityState(items_seen=5)
        state.record(item_id="q", score_out_of_10=None, assessed=False)
        assert len(state.history) == 1
        assert state.history[0].assessed is False


class TestPiecewiseColdStart:
    def test_blends_toward_piecewise_until_confident(self):
        state = AbilityState(theta=0.9)
        assert state.effective_theta() != state.theta
        assert abs(state.effective_theta() - 0.5) < abs(state.theta - 0.5)

    def test_becomes_confident_after_enough_items(self):
        state = AbilityState()
        for i in range(5):
            state.record(item_id=f"q{i}", score_out_of_10=7.0)
        assert state.is_confident
        assert state.effective_theta() == pytest.approx(state.theta)

    def test_history_is_replayable(self):
        state = AbilityState()
        for i, score in enumerate([6.0, 8.5, 4.0, 9.0]):
            state.record(item_id=f"q{i}", score_out_of_10=score)
        payload = state.to_dict()
        assert len(payload["history"]) == 4
        for entry in payload["history"]:
            assert "theta_before" in entry and "theta_after" in entry
            assert "rationale" in entry and entry["rationale"]


# ---------------------------------------------------------------------------
# Evaluation and scorecard
# ---------------------------------------------------------------------------


def dimension_score(
    dimension: Dimension,
    score: int | None,
    *,
    status: AssessmentStatus = AssessmentStatus.ASSESSED,
    rationale: str = "Evidence-supported judgement.",
    evidence: tuple[EvidencePoint, ...] = (),
) -> DimensionScore:
    spec = DEFAULT_INTERVIEW_RUBRIC.spec(dimension)
    return DimensionScore(
        dimension=dimension,
        label=spec.label,
        weight=spec.weight,
        score=score,
        status=status,
        rationale=rationale,
        evidence=evidence,
    )


def provenance(**overrides) -> EvaluationProvenance:
    base = {
        "rubric_version": "interview-rubric-2024.1",
        "prompt_version": "interview-eval-prompt-2024.1",
        "schema_version": "scorecard-schema-1.0",
        "provider": "gemini",
        "model": "gemini-1.5-pro",
        "latency_ms": 1420,
    }
    base.update(overrides)
    return EvaluationProvenance(**base)  # type: ignore[arg-type]


class TestRubricWeights:
    def test_default_weights_match_srs(self):
        rubric = DEFAULT_INTERVIEW_RUBRIC
        assert rubric.spec(Dimension.TECHNICAL_CORRECTNESS).weight == 0.40
        assert rubric.spec(Dimension.PROBLEM_SOLVING).weight == 0.30
        assert rubric.spec(Dimension.COMMUNICATION).weight == 0.20
        assert rubric.spec(Dimension.ROLE_RELEVANCE).weight == 0.10

    def test_weights_sum_to_one(self):
        assert DEFAULT_INTERVIEW_RUBRIC.total_weight() == pytest.approx(1.0)

    def test_guidance_forbids_protected_attribute_inference(self):
        guidance = DEFAULT_INTERVIEW_RUBRIC.system_guidance
        assert "protected attribute" in guidance
        assert "never an instruction" in guidance


class TestOverallComputation:
    def test_overall_is_weighted_mean_of_assessed(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a1",
            dimensions=(
                dimension_score(Dimension.TECHNICAL_CORRECTNESS, 80),
                dimension_score(Dimension.PROBLEM_SOLVING, 60),
                dimension_score(Dimension.COMMUNICATION, 70),
                dimension_score(Dimension.ROLE_RELEVANCE, 50),
            ),
            provenance=provenance(),
        )
        expected = 0.40 * 80 + 0.30 * 60 + 0.20 * 70 + 0.10 * 50
        assert card.overall == int(round(expected))

    def test_unassessed_dimension_is_excluded_and_weights_renormalise(self):
        """Renormalisation is the mechanism that stops 'unknown' becoming 'average'."""
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a2",
            dimensions=(
                dimension_score(Dimension.TECHNICAL_CORRECTNESS, 90),
                dimension_score(
                    Dimension.PROBLEM_SOLVING,
                    None,
                    status=AssessmentStatus.NOT_ASSESSED,
                    rationale="Answer did not discuss any approach.",
                ),
                dimension_score(Dimension.COMMUNICATION, 80),
                dimension_score(Dimension.ROLE_RELEVANCE, 70),
            ),
            provenance=provenance(),
        )
        # Assessed weight = 0.40 + 0.20 + 0.10 = 0.70
        expected = (0.40 * 90 + 0.20 * 80 + 0.10 * 70) / 0.70
        assert card.overall == int(round(expected))
        # Crucially, NOT the naive zero-filled figure.
        assert card.overall > int(round(0.40 * 90 + 0.30 * 0 + 0.20 * 80 + 0.10 * 70))
        assert card.assessed_weight_fraction == pytest.approx(0.70)

    def test_no_assessed_dimensions_yields_no_overall(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a3",
            dimensions=tuple(
                dimension_score(d, None, status=AssessmentStatus.NOT_ASSESSED)
                for d in Dimension
            ),
            provenance=provenance(is_fallback=True, failure_reason="provider timeout"),
        )
        assert card.overall is None
        assert card.headline == "Not scored"
        assert card.overall_status is AssessmentStatus.NOT_ASSESSED
        assert "not about you" in card.summary

    def test_partial_coverage_is_labelled_partial(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a4",
            dimensions=(
                dimension_score(Dimension.TECHNICAL_CORRECTNESS, 85),
                dimension_score(Dimension.PROBLEM_SOLVING, None, status=AssessmentStatus.NOT_ASSESSED),
                dimension_score(Dimension.COMMUNICATION, None, status=AssessmentStatus.NOT_ASSESSED),
                dimension_score(Dimension.ROLE_RELEVANCE, None, status=AssessmentStatus.NOT_ASSESSED),
            ),
            provenance=provenance(),
        )
        assert card.overall_status is AssessmentStatus.PARTIAL
        assert "part of the rubric" in card.summary

    def test_overall_is_bounded(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a5",
            dimensions=tuple(dimension_score(d, 100) for d in Dimension),
            provenance=provenance(),
        )
        assert card.overall == 100
        assert 0 <= (card.overall or 0) <= 100


class TestScorecardTransparency:
    def test_every_dimension_carries_rationale(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a6",
            dimensions=tuple(dimension_score(d, 75) for d in Dimension),
            provenance=provenance(),
        )
        for dimension in card.dimensions:
            assert dimension.rationale.strip()
            assert dimension.rubric_version == "interview-rubric-2024.1"

    def test_evidence_quotes_are_preserved(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a7",
            dimensions=(
                DimensionScore(
                    dimension=Dimension.TECHNICAL_CORRECTNESS,
                    label="Technical correctness",
                    weight=0.40,
                    score=82,
                    status=AssessmentStatus.ASSESSED,
                    rationale="Correct high-level architecture; edge-case handling incomplete.",
                    evidence=(
                        EvidencePoint(
                            point="Described the API layer before discussing persistence",
                            quote="I'd put a thin gateway in front of the write path",
                            expected_point="States the core mechanism correctly",
                        ),
                    ),
                    improvement="Practice distributed caching and failure recovery.",
                    missing_points=("Addresses edge cases, constraints or failure modes",),
                ),
            ),
            provenance=provenance(),
        )
        payload = card.to_dict()
        first = payload["dimensions"][0]
        assert first["evidence"][0]["quote"].startswith("I'd put a thin gateway")
        assert first["missing_points"]
        assert first["improvement"]

    def test_provenance_is_complete(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a8",
            dimensions=tuple(dimension_score(d, 70) for d in Dimension),
            provenance=provenance(),
        )
        record = card.provenance.to_dict()
        for field in ("rubric_version", "prompt_version", "schema_version", "provider", "model", "evaluated_at"):
            assert record[field], f"{field} must be recorded"

    def test_practice_disclaimer_is_always_present(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a9",
            dimensions=tuple(dimension_score(d, 70) for d in Dimension),
            provenance=provenance(),
        )
        assert card.disclaimer == PRACTICE_DISCLAIMER
        assert "NOT A HIRING DECISION" in card.disclaimer
        assert card.to_dict()["disclaimer"] == PRACTICE_DISCLAIMER

    def test_dispute_path_is_advertised(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a10",
            dimensions=tuple(dimension_score(d, 70) for d in Dimension),
            provenance=provenance(),
        )
        assert card.dispute_available is True

    def test_fallback_provenance_is_flagged(self):
        """A deterministic fallback score must never masquerade as a model score."""
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a11",
            dimensions=tuple(dimension_score(d, 65) for d in Dimension),
            provenance=provenance(is_fallback=True, failure_reason="primary provider 503", retries=2),
        )
        record = card.provenance.to_dict()
        assert record["is_fallback"] is True
        assert record["failure_reason"] == "primary provider 503"
        assert record["retries"] == 2

    def test_summary_identifies_biggest_lever(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a12",
            dimensions=(
                dimension_score(Dimension.TECHNICAL_CORRECTNESS, 88),
                dimension_score(Dimension.PROBLEM_SOLVING, 45),
                dimension_score(Dimension.COMMUNICATION, 80),
                dimension_score(Dimension.ROLE_RELEVANCE, 75),
            ),
            provenance=provenance(),
        )
        assert "problem solving" in card.summary.lower()

    def test_assessment_type_is_recorded(self):
        builder = ScorecardBuilder()
        card = builder.build(
            assessment_id="a13",
            dimensions=tuple(dimension_score(d, 70) for d in Dimension),
            provenance=provenance(),
            assessment_type=AssessmentType.INTERVIEW_VOICE,
        )
        assert card.to_dict()["assessment_type"] == "interview_voice"
