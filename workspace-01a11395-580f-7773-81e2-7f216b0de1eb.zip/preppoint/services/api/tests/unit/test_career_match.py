"""Unit tests for the Career Match Index engine.

These tests encode the *product promises*, not just the arithmetic:

* the SRS formula is implemented exactly when partial credit is off;
* a missing resume section never becomes a zero;
* the overall index is renormalised over assessed components only;
* weights cannot be silently changed into something that breaks the scale.
"""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from app.domain.matching.config import (
    CareerMatchConfig,
    MatchWeights,
    SkillFitConfig,
)
from app.domain.matching.fitness import education_fit, experience_fit, skill_fit
from app.domain.matching.index import CareerMatchCalculator
from app.domain.matching.types import (
    CandidateProfile,
    ComponentStatus,
    EducationLevel,
    EducationRecord,
    EvidenceSource,
    ExperienceRecord,
    RoleProfile,
    RoleSkillRequirement,
    SkillEvidence,
    SkillRequirementKind,
)

NOW = datetime(2026, 10, 7, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def backend_role() -> RoleProfile:
    """A realistic backend role with required and preferred skills."""
    return RoleProfile(
        role_id="role-backend-eng",
        title="Backend Engineer",
        description=(
            "Build and operate distributed payment services on AWS. You will design "
            "service boundaries, own reliability, and work with container orchestration. "
            "You will collaborate with frontend engineers on API contracts and participate "
            "in an on-call rotation."
        ),
        requirements=(
            RoleSkillRequirement("python", "Python", SkillRequirementKind.REQUIRED, importance=1.0,
                                 required_proficiency=0.7, prep_hours_from_zero=12),
            RoleSkillRequirement("sql", "SQL", SkillRequirementKind.REQUIRED, importance=0.9,
                                 required_proficiency=0.6, prep_hours_from_zero=10),
            RoleSkillRequirement("system-design", "System Design", SkillRequirementKind.REQUIRED,
                                 importance=0.95, required_proficiency=0.6,
                                 prep_hours_from_zero=40,
                                 prerequisites=("python",)),
            RoleSkillRequirement("docker", "Docker", SkillRequirementKind.PREFERRED, importance=0.6,
                                 required_proficiency=0.5, prep_hours_from_zero=14,
                                 prerequisites=("python",)),
            RoleSkillRequirement("kubernetes", "Kubernetes", SkillRequirementKind.NICE_TO_HAVE,
                                 importance=0.4, required_proficiency=0.5, prep_hours_from_zero=24,
                                 prerequisites=("docker",)),
        ),
        min_years_experience=3.0,
        max_years_experience=7.0,
        education_level=EducationLevel.BACHELORS,
    )


def strong_candidate() -> CandidateProfile:
    return CandidateProfile(
        skills=(
            SkillEvidence("python", 0.90, 0.95, EvidenceSource.WORK_HISTORY,
                          ("Built Python payment services at Acme",)),
            SkillEvidence("sql", 0.80, 0.9, EvidenceSource.WORK_HISTORY,
                          ("Owned PostgreSQL schema and migrations",)),
            SkillEvidence("docker", 0.75, 0.85, EvidenceSource.PROJECT,
                          ("Containerised the billing service",)),
            SkillEvidence("system-design", 0.55, 0.7, EvidenceSource.RESUME,
                          ("Mentioned service boundaries",)),
        ),
        educations=(EducationRecord(EducationLevel.BACHELORS, "B.Tech", "IIT Delhi", "CS", end_year=2019),),
        experiences=(
            ExperienceRecord("Backend Engineer", "Acme", datetime(2019, 7, 1), datetime(2023, 6, 30),
                             description="Built distributed payment services in Python on AWS."),
            ExperienceRecord("Senior Backend Engineer", "Globex", datetime(2023, 7, 1), None,
                             is_current=True, description="Leads reliability for the payments platform."),
        ),
        summary_text="Backend engineer with seven years building distributed payment systems in Python.",
    )


# ---------------------------------------------------------------------------
# Configuration invariants
# ---------------------------------------------------------------------------


class TestConfigInvariants:
    def test_default_weights_match_srs(self):
        w = MatchWeights()
        assert (w.skill, w.semantic, w.experience, w.education) == (0.50, 0.25, 0.15, 0.10)

    def test_weights_must_sum_to_one(self):
        with pytest.raises(ValueError, match="must sum to 1.0"):
            MatchWeights(skill=0.6, semantic=0.3, experience=0.15, education=0.10)

    def test_config_is_immutable_and_versioned(self):
        config = CareerMatchConfig()
        assert config.version
        dumped = config.as_dict()
        assert dumped["weights"]["skill"] == 0.50
        with pytest.raises(Exception):
            config.version = "tampered"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# fsk -- skill fit
# ---------------------------------------------------------------------------


class TestSkillFit:
    def test_matches_srs_formula_exactly_when_counts_only(self):
        """fsk = min(1, (|SC∩SR| + 0.5|SC∩SP|) / |SR|) with partial credit off."""
        config = CareerMatchConfig(skill=SkillFitConfig(partial_credit_enabled=False))
        candidate = CandidateProfile(
            skills=(
                SkillEvidence("python", 0.9),
                SkillEvidence("sql", 0.9),
                SkillEvidence("docker", 0.9),  # preferred
            )
        )
        role = backend_role()
        # required met: python, sql (2 of 3). preferred met: docker (1).
        # fsk = (2 + 0.5*1) / 3 = 0.8333
        component = skill_fit(candidate, role, config)
        assert component.status is ComponentStatus.ASSESSED
        assert component.value == pytest.approx(0.8333, abs=1e-3)

    def test_below_bar_skill_does_not_count(self):
        """A keyword with no proficiency must not satisfy a requirement."""
        config = CareerMatchConfig(skill=SkillFitConfig(partial_credit_enabled=False))
        candidate = CandidateProfile(
            skills=(
                SkillEvidence("python", 0.9),
                SkillEvidence("sql", 0.10),  # listed, but nowhere near the 0.6 bar
            )
        )
        component = skill_fit(candidate, backend_role(), config)
        # only python counts: 1/3
        assert component.value == pytest.approx(1 / 3, abs=1e-3)
        assert "SQL" in component.missing_evidence

    def test_partial_credit_refinement_is_opt_in(self):
        strict = CareerMatchConfig(skill=SkillFitConfig(partial_credit_enabled=False))
        lenient = CareerMatchConfig(skill=SkillFitConfig(partial_credit_enabled=True))
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.72), SkillEvidence("sql", 0.8)))
        role = backend_role()
        assert skill_fit(candidate, role, lenient).value >= skill_fit(candidate, role, strict).value

    def test_capped_at_one(self):
        config = CareerMatchConfig()
        candidate = CandidateProfile(
            skills=(
                SkillEvidence("python", 1.0),
                SkillEvidence("sql", 1.0),
                SkillEvidence("system-design", 1.0),
                SkillEvidence("docker", 1.0),
                SkillEvidence("kubernetes", 1.0),
            )
        )
        component = skill_fit(candidate, backend_role(), config)
        assert component.value == 1.0
        assert "capped at 100%" in component.rationale

    def test_role_without_required_skills_is_not_assessed(self):
        """We must not divide by zero and call it 0%."""
        role = RoleProfile(role_id="r", title="Open Role", requirements=(
            RoleSkillRequirement("python", "Python", SkillRequirementKind.PREFERRED),
        ))
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.9),))
        component = skill_fit(candidate, role, CareerMatchConfig())
        assert component.status is ComponentStatus.NOT_ASSESSED
        assert component.value is None


# ---------------------------------------------------------------------------
# fex -- experience fit
# ---------------------------------------------------------------------------


class TestExperienceFit:
    def test_inside_band_scores_full(self):
        component = experience_fit(strong_candidate(), backend_role(), CareerMatchConfig())
        assert component.value == 1.0

    def test_shortfall_decays_but_never_zeros(self):
        candidate = CandidateProfile(
            total_years_experience=0.5,
            experiences=(ExperienceRecord("Intern", "Acme", datetime(2026, 1, 1), datetime(2026, 7, 1)),),
        )
        component = experience_fit(candidate, backend_role(), CareerMatchConfig())
        assert component.value is not None
        assert 0.0 < component.value < 1.0
        assert "floors at" in component.rationale

    def test_unknown_experience_is_not_assessed_not_zero(self):
        candidate = CandidateProfile(summary_text="No dates anywhere in this resume.")
        component = experience_fit(candidate, backend_role(), CareerMatchConfig())
        assert component.status is ComponentStatus.NOT_ASSESSED
        assert component.value is None

    def test_overflowing_experience_saturates_at_one(self):
        """Over-qualification is context, not a deduction (default policy)."""
        candidate = CandidateProfile(total_years_experience=20.0)
        component = experience_fit(candidate, backend_role(), CareerMatchConfig())
        assert component.value == 1.0
        assert "capped at 100%" in component.rationale
        # The candidate is still told about the mismatch, as context.
        assert any("beyond the stated upper bound" in e for e in component.evidence)

    def test_overqualification_penalty_is_opt_in_and_versioned(self):
        """An operator may enable the penalty, and it is never a hard zero."""
        from app.domain.matching.config import ExperienceFitConfig

        candidate = CandidateProfile(total_years_experience=20.0)
        config = CareerMatchConfig(experience=ExperienceFitConfig(overqualification_penalty_enabled=True))
        component = experience_fit(candidate, backend_role(), config)
        assert component.value == config.experience.overshoot_floor
        assert component.value > 0.0

    def test_overlapping_roles_are_merged_not_summed(self):
        """Two concurrent 2-year roles are 2 years of experience, not 4."""
        candidate = CandidateProfile(
            experiences=(
                ExperienceRecord("A", start_date=datetime(2024, 1, 1), end_date=datetime(2026, 1, 1)),
                ExperienceRecord("B", start_date=datetime(2024, 1, 1), end_date=datetime(2026, 1, 1)),
            )
        )
        assert candidate.effective_years_experience(now=NOW) == pytest.approx(2.0, abs=0.1)


# ---------------------------------------------------------------------------
# fed -- education fit
# ---------------------------------------------------------------------------


class TestEducationFit:
    def test_meets_requirement(self):
        component = education_fit(strong_candidate(), backend_role(), CareerMatchConfig())
        assert component.value == 1.0

    def test_unspecified_requirement_does_not_penalise(self):
        role = RoleProfile(role_id="r", title="Engineer")
        component = education_fit(strong_candidate(), role, CareerMatchConfig())
        assert component.value == 1.0

    def test_one_level_below_retains_partial_credit(self):
        candidate = CandidateProfile(educations=(EducationRecord(EducationLevel.DIPLOMA),))
        component = education_fit(candidate, backend_role(), CareerMatchConfig())
        assert component.value == pytest.approx(0.6)

    def test_missing_education_is_not_assessed(self):
        candidate = CandidateProfile(summary_text="Backend engineer, no education section.")
        component = education_fit(candidate, backend_role(), CareerMatchConfig())
        assert component.status is ComponentStatus.NOT_ASSESSED
        assert component.value is None

    @pytest.mark.parametrize(
        ("label", "expected"),
        [
            ("B.Tech in Computer Science", EducationLevel.BACHELORS),
            ("M.Tech, IIT Bombay", EducationLevel.MASTERS),
            ("PhD in Distributed Systems", EducationLevel.DOCTORATE),
            ("Diploma in Engineering", EducationLevel.DIPLOMA),
            ("", EducationLevel.UNKNOWN),
            ("Something unparseable", EducationLevel.UNKNOWN),
        ],
    )
    def test_degree_label_parsing(self, label, expected):
        assert EducationLevel.from_label(label) is expected

    def test_degree_parsing_never_guesses_upward(self):
        assert EducationLevel.from_label("studied computer science") is EducationLevel.UNKNOWN


# ---------------------------------------------------------------------------
# The index itself
# ---------------------------------------------------------------------------


class TestCareerMatchIndex:
    def test_full_pipeline_produces_explainable_result(self):
        calculator = CareerMatchCalculator()
        result = calculator.compute(strong_candidate(), backend_role(), now=NOW)

        assert 0 <= result.index <= 100
        # Coverage is confidence-weighted, so a realistic resume with one
        # thinly-evidenced skill lands in the high 0.8s rather than at 1.0.
        assert result.evidence_coverage > 0.80
        assert result.is_reportable
        assert len(result.components) == 4
        assert result.config_version == "cmi-2024.1"
        # Every assessed component must carry a non-empty rationale.
        for component in result.components:
            assert component.rationale.strip(), f"{component.key} has no rationale"

    def test_components_and_weights_match_srs(self):
        result = CareerMatchCalculator().compute(strong_candidate(), backend_role(), now=NOW)
        assert result.component("skill").weight == 0.50
        assert result.component("semantic").weight == 0.25
        assert result.component("experience").weight == 0.15
        assert result.component("education").weight == 0.10

    def test_index_uses_renormalised_weights_not_zero_filled(self):
        """A resume with no education section must not silently lose 10 points."""
        with_education = strong_candidate()
        without_education = CandidateProfile(
            skills=with_education.skills,
            experiences=with_education.experiences,
            summary_text=with_education.summary_text,
        )
        calculator = CareerMatchCalculator()
        a = calculator.compute(with_education, backend_role(), now=NOW)
        b = calculator.compute(without_education, backend_role(), now=NOW)

        assert b.component("education").status is ComponentStatus.NOT_ASSESSED
        assert b.evidence_coverage < a.evidence_coverage
        # The headline must be defensible: identical evidence elsewhere should
        # not be penalised for an absent section. Allow small drift from the
        # renormalised semantic term.
        assert abs(b.index - a.index) < 8.0
        assert b.index_zero_filled < b.index

    def test_all_unassessed_yields_no_headline(self):
        """An empty candidate against an empty role must publish nothing.

        Education is still *technically* assessable here (the role states no
        requirement, so nothing can be failed), which is why coverage is not
        exactly zero -- but the headline is withheld regardless.
        """
        role = RoleProfile(role_id="r", title="Empty Role")
        candidate = CandidateProfile()
        result = CareerMatchCalculator().compute(candidate, role, now=NOW)

        assert result.is_reportable is False
        assert result.display_index is None, "an indefensible index must not be readable"
        assert result.evidence_coverage < 0.2
        assert "not yet enough evidence" in result.explanation.lower()
        # The internal value stays available for ranking and auditing.
        assert result.index is not None

    def test_display_index_is_none_whenever_coverage_is_low(self):
        """The safe accessor closes the 'someone forgets to check the flag' hole."""
        role = backend_role()
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.5, 0.4),))
        result = CareerMatchCalculator().compute(candidate, role, now=NOW)
        assert result.is_reportable is False
        assert result.display_index is None
        assert result.to_dict()["display_index"] is None

    def test_display_index_present_when_coverage_is_good(self):
        result = CareerMatchCalculator().compute(strong_candidate(), backend_role(), now=NOW)
        assert result.is_reportable is True
        assert result.display_index == result.index

    def test_low_coverage_hides_headline(self):
        """One listed skill is not enough to publish a confident number.

        This is the regression guard for confidence-weighted coverage: before
        that change, simply *having* a value for skill + semantic pushed
        coverage to 0.75 and the index was published off a single keyword.
        """
        role = backend_role()
        candidate = CandidateProfile(skills=(SkillEvidence("python", 0.8, 0.9),))
        result = CareerMatchCalculator().compute(candidate, role, now=NOW)

        assert result.is_reportable is False
        assert result.display_index is None
        assert result.warnings
        assert any("evidence" in w.lower() for w in result.warnings)

    def test_thin_evidence_costs_more_coverage_than_thick_evidence(self):
        """Identical component values, different confidence, different coverage."""
        role = backend_role()
        thin = CandidateProfile(
            skills=(
                SkillEvidence("python", 0.9, 0.30),
                SkillEvidence("sql", 0.9, 0.30),
                SkillEvidence("system-design", 0.9, 0.30),
            ),
        )
        thick = CandidateProfile(
            skills=(
                SkillEvidence("python", 0.9, 0.95),
                SkillEvidence("sql", 0.9, 0.95),
                SkillEvidence("system-design", 0.9, 0.95),
            ),
        )
        calculator = CareerMatchCalculator()
        thin_result = calculator.compute(thin, role, now=NOW)
        thick_result = calculator.compute(thick, role, now=NOW)
        assert thin_result.evidence_coverage < thick_result.evidence_coverage

    def test_explanation_names_the_largest_lever(self):
        calculator = CareerMatchCalculator()
        result = calculator.compute(strong_candidate(), backend_role(), now=NOW)
        assert "largest lever" in result.explanation.lower()

    def test_deterministic_across_runs(self):
        calculator = CareerMatchCalculator()
        first = calculator.compute(strong_candidate(), backend_role(), now=NOW)
        second = calculator.compute(strong_candidate(), backend_role(), now=NOW)
        assert first.index == second.index

    def test_compute_many_sorts_best_first(self):
        calculator = CareerMatchCalculator()
        junior = RoleProfile(
            role_id="role-junior", title="Junior Engineer",
            requirements=(RoleSkillRequirement("python", "Python"),),
            min_years_experience=0.0, education_level=EducationLevel.BACHELORS,
        )
        results = calculator.compute_many(strong_candidate(), [backend_role(), junior], now=NOW)
        assert len(results) == 2
        assert results[0].index >= results[1].index

    def test_reportable_config_changes_are_versioned(self):
        """Weights are read from config, never from call sites."""
        custom = CareerMatchConfig(skill=SkillFitConfig(preferred_credit=1.0))
        result = CareerMatchCalculator(config=custom).compute(strong_candidate(), backend_role(), now=NOW)
        assert result.config_version == custom.version

    def test_serialises_for_the_api(self):
        result = CareerMatchCalculator().compute(strong_candidate(), backend_role(), now=NOW)
        payload = result.to_dict()
        assert payload["components"][0]["percent"] is not None
        assert isinstance(payload["warnings"], list)
        assert payload["index"] == result.index
