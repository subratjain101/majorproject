"""Security and responsible-AI tests.

These are the tests that assert *refusals*. They matter more than the feature
tests, because a regression here is a privacy incident or a fabricated score,
neither of which surfaces as a user-visible bug.

Mapped to SRS §18 (AI security) and §2G (responsible AI).
"""

from __future__ import annotations

import pytest

from app.ai.gateway import (
    AIGateway,
    GatewayPolicy,
    extract_json,
    validate_against_schema,
)
from app.ai.providers.base import (
    AIProviderError,
    AIRequest,
    AIResponse,
    AIUsage,
    AISchemaValidationError,
)
from app.core.redaction import assert_redaction_safe, redact_identifiers
from app.domain.evaluation.rubric import DEFAULT_INTERVIEW_RUBRIC, Dimension
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Redaction: identifiers must not survive
# ---------------------------------------------------------------------------


class TestIdentifierRedaction:
    def test_email_is_removed(self):
        result = redact_identifiers("Contact: aarav.sharma@example.com")
        assert "aarav.sharma@example.com" not in result.text
        assert "[EMAIL_1]" in result.text
        assert result.counts.emails == 1

    def test_phone_numbers_in_common_formats_are_removed(self):
        samples = [
            "+91 98765 43210",
            "+919876543210",
            "(080) 4123-4567",
            "98765-43210",
        ]
        for phone in samples:
            result = redact_identifiers(f"Phone: {phone}")
            digits = "".join(c for c in phone if c.isdigit())
            surviving = "".join(c for c in result.text if c.isdigit())
            assert digits not in surviving, f"phone {phone!r} survived redaction"

    def test_protected_attributes_are_removed_entirely(self):
        """These are removed, not replaced: the model must not even see the label."""
        resume = (
            "Name: Aarav Sharma\n"
            "Gender: Male\n"
            "Caste: General\n"
            "Religion: Hindu\n"
            "Marital Status: Single\n"
            "Nationality: Indian\n"
            "Blood Group: O+\n"
        )
        result = redact_identifiers(resume)
        lowered = result.text.casefold()
        for forbidden in ("male", "general", "hindu", "single", "indian", "o+"):
            assert forbidden not in lowered, f"{forbidden!r} survived redaction"
        assert result.counts.protected_attributes >= 5

    def test_date_of_birth_and_age_are_removed(self):
        result = redact_identifiers("Date of Birth: 14/08/1998\nAge: 28\n")
        assert "14/08/1998" not in result.text
        assert "28" not in result.text.replace("[REDACTED: AGE]", "")
        assert result.counts.dates_of_birth >= 1

    def test_urls_are_replaced(self):
        result = redact_identifiers("Portfolio: https://aarav.dev\nLinkedIn: linkedin.com/in/aarav-sharma")
        assert "aarav.dev" not in result.text
        assert "aarav-sharma" not in result.text
        assert result.counts.urls >= 2

    def test_url_credentials_are_stripped(self):
        result = redact_identifiers("Link: https://portal.example.com/cv?token=SECRET123")
        assert "SECRET123" not in result.text

    def test_labelled_name_is_replaced(self):
        result = redact_identifiers("Full Name: Aarav Sharma\nEmail: a@b.com")
        assert "Aarav Sharma" not in result.text
        assert result.counts.names >= 1

    def test_leading_bare_name_is_replaced(self):
        result = redact_identifiers("Aarav Sharma\nBackend Engineer\n\nExperience\n- Built things")
        assert "Aarav Sharma" not in result.text

    def test_technical_content_survives_redaction(self):
        """Redaction must not destroy the signal we are trying to measure."""
        resume = (
            "Name: Aarav Sharma\n"
            "Email: aarav@example.com\n"
            "\n"
            "Experience\n"
            "Senior Backend Engineer, Globex (2023-present)\n"
            "- Built a distributed payments platform handling 4,000 TPS in Python\n"
            "- Reduced p99 latency by 38% by adding read-through caching in Redis\n"
            "\n"
            "Skills\n"
            "Python, PostgreSQL, Docker, Kubernetes, gRPC\n"
        )
        result = redact_identifiers(resume)
        for preserved in ("distributed payments platform", "4,000 TPS", "Python", "PostgreSQL", "Redis", "gRPC"):
            assert preserved in result.text, f"redaction destroyed {preserved!r}"

    def test_mapping_is_not_written_to_the_audit_record(self):
        """The audit dict must be safe to log verbatim."""
        result = redact_identifiers("Name: Aarav Sharma\nEmail: secret@example.com")
        audit = result.to_audit_dict()
        serialised = str(audit)
        assert "Aarav" not in serialised
        assert "secret@example.com" not in serialised
        assert audit["redaction_applied"] is True

    def test_redaction_is_idempotent(self):
        once = redact_identifiers("Email: a@b.com\nName: Aarav Sharma")
        twice = redact_identifiers(once.text)
        assert twice.text == once.text


class TestRedactionFailsClosed:
    def test_failure_blocks_transmission(self):
        result = redact_identifiers("anything")
        result.redaction_failed = True
        result.error = "simulated"
        assert result.safe_to_transmit is False
        with pytest.raises(RuntimeError, match="refusing to transmit"):
            assert_redaction_safe(result)

    def test_empty_input_is_not_an_error(self):
        result = redact_identifiers("")
        assert result.safe_to_transmit is True
        assert result.text == ""


# ---------------------------------------------------------------------------
# AI gateway: never fabricate
# ---------------------------------------------------------------------------


class EvaluationPayload(BaseModel):
    score: int = Field(ge=0, le=100)
    rationale: str
    evidence: list[str] = Field(default_factory=list)


class FakeProvider:
    """Configurable provider double."""

    def __init__(self, name: str, responses: list[object], *, configured: bool = True) -> None:
        self.name = name
        self._responses = list(responses)
        self._configured = configured
        self.calls = 0

    def is_configured(self) -> bool:
        return self._configured

    async def generate(self, request: AIRequest) -> AIResponse:
        self.calls += 1
        item = self._responses.pop(0) if self._responses else AIProviderError("exhausted", retryable=False)
        if isinstance(item, Exception):
            raise item
        return AIResponse(
            text=str(item),
            provider=self.name,
            model=f"{self.name}-model",
            latency_ms=42,
            usage=AIUsage(prompt_tokens=100, completion_tokens=50, total_tokens=150),
        )


VALID = '{"score": 82, "rationale": "Correct architecture", "evidence": ["quote"]}'


class TestGatewayNeverFabricates:
    @pytest.mark.asyncio
    async def test_valid_response_is_returned_with_provenance(self):
        provider = FakeProvider("gemini", [VALID])
        gateway = AIGateway([provider])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)

        assert result.ok
        assert result.value.score == 82
        assert result.provider == "gemini"
        assert result.degraded is False
        provenance = result.to_provenance()
        assert provenance["is_fallback"] is False
        assert provenance["prompt_tokens"] == 100

    @pytest.mark.asyncio
    async def test_all_providers_failing_degrades_with_no_value(self):
        """THE central guarantee: no provider -> no score, never a guess."""
        gateway = AIGateway(
            [
                FakeProvider("gemini", [AIProviderError("503", retryable=True)] * 2),
                FakeProvider("openai", [AIProviderError("timeout", retryable=True)] * 2),
            ]
        )
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)

        assert result.ok is False
        assert result.value is None
        assert result.degraded is True
        assert len(result.failures) == 4
        assert result.to_provenance()["is_fallback"] is True

    @pytest.mark.asyncio
    async def test_malformed_json_is_retried_then_succeeds(self):
        provider = FakeProvider("gemini", ["I think the score is 82 out of 100.", VALID])
        gateway = AIGateway([provider])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)

        assert result.ok
        assert result.attempts == 2
        assert result.to_provenance()["retries"] == 1

    @pytest.mark.asyncio
    async def test_schema_violation_is_not_accepted(self):
        """A number out of range must be rejected, not clamped."""
        provider = FakeProvider("gemini", ['{"score": 850, "rationale": "wrong"}'] * 2)
        gateway = AIGateway([provider])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)
        assert result.ok is False
        assert result.degraded is True

    @pytest.mark.asyncio
    async def test_missing_required_field_is_rejected(self):
        provider = FakeProvider("gemini", ['{"score": 82}'] * 2)
        gateway = AIGateway([provider])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)
        assert result.ok is False

    @pytest.mark.asyncio
    async def test_falls_back_to_second_provider(self):
        primary = FakeProvider("gemini", [AIProviderError("rate limited", retryable=False)])
        secondary = FakeProvider("groq", [VALID])
        gateway = AIGateway([primary, secondary])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)

        assert result.ok
        assert result.provider == "groq"

    @pytest.mark.asyncio
    async def test_non_retryable_error_skips_straight_to_fallback(self):
        """Retrying a malformed-prompt 400 wastes quota."""
        primary = FakeProvider("gemini", [AIProviderError("bad request", retryable=False), VALID])
        secondary = FakeProvider("groq", [VALID])
        gateway = AIGateway([primary, secondary])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)

        assert result.ok
        assert primary.calls == 1, "must not retry a non-retryable error"
        assert result.provider == "groq"

    @pytest.mark.asyncio
    async def test_no_configured_provider_degrades_immediately(self):
        gateway = AIGateway([FakeProvider("gemini", [VALID], configured=False)])
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)
        assert result.ok is False
        assert result.attempts == 0
        assert "No AI provider is configured" in result.failures[0]

    @pytest.mark.asyncio
    async def test_unexpected_exception_is_caught_and_recorded(self):
        provider = FakeProvider("gemini", [RuntimeError("sdk exploded")])
        gateway = AIGateway([provider], policy=GatewayPolicy(max_attempts_per_provider=1))
        result = await gateway.generate_structured(AIRequest(prompt="x"), EvaluationPayload)
        assert result.ok is False
        assert any("RuntimeError" in failure for failure in result.failures)

    def test_status_reports_degradation_for_admin_console(self):
        gateway = AIGateway([FakeProvider("gemini", [VALID], configured=False)])
        status = gateway.status()
        assert status["degraded"] is True
        assert "gemini" in status["unconfigured_providers"]


class TestJsonExtraction:
    @pytest.mark.parametrize(
        "raw",
        [
            '{"score": 1, "rationale": "x"}',
            '```json\n{"score": 1, "rationale": "x"}\n```',
            '```\n{"score": 1, "rationale": "x"}\n```',
            'Here is the result:\n{"score": 1, "rationale": "x"}\nHope that helps!',
        ],
    )
    def test_extracts_valid_json_from_noisy_responses(self, raw):
        parsed = validate_against_schema(raw, EvaluationPayload)
        assert parsed.score == 1

    def test_prose_without_json_is_a_validation_error(self):
        with pytest.raises(AISchemaValidationError):
            validate_against_schema("The candidate did well, I'd say 82.", EvaluationPayload)

    def test_extract_json_does_not_invent_structure(self):
        assert extract_json("no json here") == "no json here"


# ---------------------------------------------------------------------------
# Responsible AI: prohibitions are enforced in prompt design
# ---------------------------------------------------------------------------


class TestResponsibleAiConstraints:
    def test_rubric_forbids_inference_of_protected_attributes(self):
        guidance = DEFAULT_INTERVIEW_RUBRIC.system_guidance.casefold()
        for forbidden in ("personality", "emotion", "accent", "health", "protected attribute"):
            assert forbidden in guidance, f"rubric must explicitly forbid {forbidden} inference"

    def test_rubric_treats_candidate_text_as_untrusted(self):
        guidance = DEFAULT_INTERVIEW_RUBRIC.system_guidance
        assert "untrusted" in guidance.casefold()
        assert "never an instruction" in guidance.casefold()

    def test_rubric_requires_not_assessed_over_guessing(self):
        guidance = DEFAULT_INTERVIEW_RUBRIC.system_guidance
        assert "not_assessed" in guidance
        assert "do not guess" in guidance.casefold()

    def test_communication_rubric_excludes_accent_and_fluency(self):
        rubric = DEFAULT_INTERVIEW_RUBRIC.spec(Dimension.COMMUNICATION).rubric.casefold()
        assert "never judge accent" in rubric
        assert "speech rate" in rubric

    def test_ai_has_no_capability_to_mutate_scores(self):
        """AI output shapes are data-only: no control fields exist on them.

        This is a structural guarantee. If a future change adds a field such as
        ``override_score`` to a model the AI is asked to produce, this test
        fails -- which is the point.
        """
        payload_fields = set(EvaluationPayload.model_fields)
        forbidden = {
            "permissions",
            "role",
            "grant",
            "override",
            "override_score",
            "approve",
            "publish",
            "delete",
            "final_score",
            "is_correct",
        }
        assert not (payload_fields & forbidden)
