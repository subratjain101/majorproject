"""Application settings.

All configuration arrives from the environment. Nothing in this project has a
hard-coded credential, a hard-coded provider preference, or a hard-coded
scoring weight -- the first two are security and portability requirements, the
third is an auditability requirement (see ``domain/matching/config.py``).
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # -- Runtime -----------------------------------------------------------
    environment: Literal["development", "staging", "production", "test"] = "development"
    debug: bool = False
    log_level: str = "INFO"
    api_host: str = "0.0.0.0"
    api_port: int = 8000

    # -- Security ----------------------------------------------------------
    secret_key: str = Field(
        default="dev-only-insecure-key-change-me",
        description="Used to sign tokens. MUST be overridden in production.",
    )
    access_token_ttl_minutes: int = 30
    refresh_token_ttl_days: int = 30

    #: Explicit origin allowlist. Never "*" when credentials are enabled.
    cors_origins: list[str] = Field(
        default_factory=lambda: ["http://localhost:3000", "http://127.0.0.1:3000"]
    )

    # -- Data --------------------------------------------------------------
    database_url: str = "postgresql+psycopg://preppoint:preppoint@localhost:5432/preppoint"
    redis_url: str = "redis://localhost:6379/0"
    #: Object storage for resume originals. Uploads are never stored in the DB.
    storage_backend: Literal["local", "s3"] = "local"
    storage_local_path: str = "/var/lib/preppoint/uploads"
    max_upload_bytes: int = 5 * 1024 * 1024

    # -- AI providers ------------------------------------------------------
    #: Preference order. The gateway tries these in sequence and falls back on
    #: failure. Empty string means "not configured".
    ai_provider_order: list[str] = Field(default_factory=lambda: ["gemini", "openai", "groq", "local"])

    gemini_api_key: str = ""
    gemini_model: str = "gemini-1.5-pro"

    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"

    groq_api_key: str = ""
    groq_model: str = "llama-3.3-70b-versatile"

    #: Self-hosted / OpenAI-compatible endpoint (Ollama, vLLM, TGI).
    local_ai_base_url: str = ""
    local_ai_model: str = ""

    #: Speech providers for the optional voice interview.
    stt_provider: Literal["none", "whisper_local", "openai"] = "none"
    tts_provider: Literal["none", "piper_local", "openai"] = "none"

    # -- Sandbox -----------------------------------------------------------
    #: DSA execution is delegated to the sandbox service; the API never runs
    #: candidate code in-process.
    sandbox_url: str = "http://sandbox:8100"
    sandbox_timeout_seconds: int = 10
    sandbox_memory_limit_mb: int = 256
    sandbox_cpu_limit: float = 1.0

    # -- Product -----------------------------------------------------------
    #: Minimum evidence coverage before the Career Match Index is displayed.
    min_evidence_coverage: float = 0.60
    #: Whether candidates may invite recruiter visibility at all (tenant policy).
    recruiter_sharing_enabled: bool = True

    # -- Derived helpers ---------------------------------------------------

    @field_validator("cors_origins", "ai_provider_order", mode="before")
    @classmethod
    def split_comma_separated(cls, value: object) -> object:
        """Accept ``a,b,c`` from the environment as well as a JSON list."""
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return []
            if stripped.startswith("["):
                return value
            return [item.strip() for item in stripped.split(",") if item.strip()]
        return value

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    def configured_ai_providers(self) -> list[str]:
        available: list[str] = []
        if self.gemini_api_key:
            available.append("gemini")
        if self.openai_api_key:
            available.append("openai")
        if self.groq_api_key:
            available.append("groq")
        if self.local_ai_base_url and self.local_ai_model:
            available.append("local")
        return available

    def ai_provider_available(self) -> bool:
        return bool(self.configured_ai_providers())

    def ai_status(self) -> dict[str, object]:
        """Non-secret AI status, safe to return from the health endpoint.

        Never returns key material, prefixes, lengths or hashes of keys.
        """
        configured = self.configured_ai_providers()
        return {
            "configured": configured,
            "preference_order": self.ai_provider_order,
            "degraded": len(configured) == 0,
            "stt": self.stt_provider,
            "tts": self.tts_provider,
        }


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Cached settings accessor."""
    return Settings()


settings = get_settings()


__all__ = ["Settings", "get_settings", "settings"]
