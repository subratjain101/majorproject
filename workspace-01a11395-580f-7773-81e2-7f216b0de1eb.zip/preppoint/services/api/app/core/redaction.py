"""Identifier redaction (SRS §8).

Resume text is stripped of directly identifying information *before* it is sent
to any external model. This is a privacy control, and it is also a scoring
control: a model that can see a candidate's name, gender, nationality or age
can be influenced by it, even when it has been instructed not to be.

Design notes
------------
* **Deterministic and reversible within the request only.** We substitute typed
  placeholders (``[EMAIL_1]``) so the model can still reason about structure --
  "contact block present" -- without seeing the value. The mapping is returned
  to the caller and is never persisted alongside the AI payload.
* **Fail closed.** If redaction raises, the caller must not send the document.
  ``RedactionResult.redaction_failed`` makes that decision explicit rather than
  leaving it to a try/except that someone will eventually delete.
* **Over-redaction is preferred to under-redaction.** A false positive costs a
  little model context. A false negative leaks a candidate's identity to a
  third party. The asymmetry justifies aggressive matching.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

# Deliberately permissive. Resumes contain hand-formatted contact details that
# strict RFC-compliant patterns miss, and a missed email is a privacy incident.
_EMAIL = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
)

# International and Indian formats, with optional separators.
_PHONE = re.compile(
    r"(?:(?:\+|00)\d{1,3}[\s.\-]?)?"          # country code
    r"(?:\(?\d{2,5}\)?[\s.\-]?)?"              # area code
    r"\d{3,5}[\s.\-]?\d{3,5}"                  # subscriber number
    r"(?:\s*(?:x|ext\.?|extension)\s*\d{1,6})?",  # extension
    re.IGNORECASE,
)

_URL = re.compile(
    r"\b(?:https?://|www\.)[^\s<>\"')]+"
    r"|\b(?:linkedin\.com|github\.com|gitlab\.com|behance\.net|dribbble\.com|medium\.com)/[^\s<>\"')]+",
    re.IGNORECASE,
)

# URLs that contain an identity token and must never reach a provider.
_SENSITIVE_URL_QUERY = re.compile(r"[?&](?:token|key|sig|auth|session|access_token)=[^\s&]+", re.IGNORECASE)

# Social handles, e.g. "@aarav.dev" in a contact block.
_SOCIAL_HANDLE = re.compile(r"(?<![\w.])@[A-Za-z0-9_.\-]{2,30}\b")

# Postal addresses: a number followed by 2-4 capitalised words, then a PIN/ZIP.
_ADDRESS = re.compile(
    r"\b\d{1,5}[\s,]+(?:[A-Z][A-Za-z.'\-]+\s+){1,3}(?:[A-Z][A-Za-z.'\-]+)"
    r"(?:[\s,]+(?:[A-Z]{2})?[\s\-]?\d{5,6}(?:-\d{4})?)?"
)

# Indian PIN code and US ZIP, standing alone.
_PIN = re.compile(r"\b\d{5,6}\b(?=\s*(?:$|\n))", re.MULTILINE)

# Dates of birth: an age or DOB line is a protected-attribute proxy even when
# the model is instructed to ignore it.
_DOB_LABELLED = re.compile(
    r"^\s*(?:date\s+of\s+birth|d\.?o\.?b\.?|born|birth\s*date)\s*[:\-]?\s*.*$",
    re.IGNORECASE | re.MULTILINE,
)

# Explicit age statements.
_AGE = re.compile(r"\b(?:age|aged)\s*[:\-]?\s*\d{1,2}\b", re.IGNORECASE)

# Protected-attribute declarations that must not reach a model at all.
_PROTECTED_LABELLED = re.compile(
    r"^\s*(?:gender|sex|marital\s+status|caste|religion|nationality|"
    r"father'?s?\s+name|mother'?s?\s+name|category|community|"
    r"blood\s+group|disability|physically\s+challenged)\s*[:\-]?\s*.*$",
    re.IGNORECASE | re.MULTILINE,
)

# Photographs referenced as image links.
_PHOTO = re.compile(r"\b(?:photo|photograph|headshot|profile\s*picture)\b", re.IGNORECASE)

_LINE_LABEL = re.compile(r"^\s*([A-Za-z][A-Za-z\s.]{1,28}?)\s*[:\-]\s*(.+)$")


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class RedactionCounts:
    """What was removed, by type. Logged in aggregate; never with the values."""

    emails: int = 0
    phones: int = 0
    urls: int = 0
    social_handles: int = 0
    addresses: int = 0
    dates_of_birth: int = 0
    protected_attributes: int = 0
    names: int = 0
    other: int = 0

    @property
    def total(self) -> int:
        return (
            self.emails
            + self.phones
            + self.urls
            + self.social_handles
            + self.addresses
            + self.dates_of_birth
            + self.protected_attributes
            + self.names
            + self.other
        )

    def to_dict(self) -> dict[str, int]:
        return {
            "emails": self.emails,
            "phones": self.phones,
            "urls": self.urls,
            "social_handles": self.social_handles,
            "addresses": self.addresses,
            "dates_of_birth": self.dates_of_birth,
            "protected_attributes": self.protected_attributes,
            "names": self.names,
            "other": self.other,
            "total": self.total,
        }


@dataclass(slots=True)
class RedactionResult:
    """Redacted text plus the information needed to audit the operation.

    ``mapping`` maps placeholders back to originals and must be held only for
    the lifetime of the request. It is never written to the AI audit log.
    """

    text: str
    counts: RedactionCounts
    mapping: dict[str, str] = field(default_factory=dict)
    #: True when the redactor itself errored; callers must NOT transmit.
    redaction_failed: bool = False
    error: str | None = None

    @property
    def safe_to_transmit(self) -> bool:
        return not self.redaction_failed

    def to_audit_dict(self) -> dict[str, object]:
        """Audit-safe summary. Contains no candidate data whatsoever."""
        return {
            "redaction_applied": not self.redaction_failed,
            "redactions": self.counts.to_dict(),
            "error": self.error,
        }


# ---------------------------------------------------------------------------
# Name detection
# ---------------------------------------------------------------------------

#: Labels whose value is a person's name (possibly the candidate's).
_NAME_LABELS = frozenset(
    {
        "name",
        "full name",
        "candidate name",
        "applicant name",
        "first name",
        "last name",
        "surname",
        "given name",
    }
)

#: Labels whose value is another person's name. Redacted for consistency.
_REFERENCE_LABELS = frozenset({"referee", "reference", "referred by", "recommender"})


def _redact_labelled_names(lines: list[str], mapping: dict[str, str], counter: list[int]) -> tuple[list[str], int]:
    """Redact ``Name: Aarav Sharma`` style lines, and a leading bare name.

    The hardest case in resume redaction is a standalone name at the top of the
    document with no label. We handle the common, high-confidence form -- a
    first line containing exactly two to four capitalised tokens and no digits
    or sentence punctuation -- and accept that it can occasionally miss. In
    that case the email and phone on the same line are still redacted, so the
    document as a whole remains non-identifying.
    """
    output: list[str] = []
    names_found = 0

    for index, line in enumerate(lines):
        match = _LINE_LABEL.match(line)
        if match:
            label = match.group(1).strip().casefold()
            value = match.group(2).strip()
            if label in _NAME_LABELS or label in _REFERENCE_LABELS:
                if value:
                    names_found += 1
                    counter[0] += 1
                    placeholder = f"[NAME_{names_found}]"
                    mapping[placeholder] = value
                    output.append(f"{match.group(1).strip()}: {placeholder}")
                    continue

        # Leading standalone name: first non-empty line, 2-4 capitalised words.
        if index < 6 and not output:
            stripped = line.strip()
            tokens = stripped.split()
            if (
                2 <= len(tokens) <= 4
                and all(t[:1].isupper() and t.replace(".", "").replace("-", "").isalpha() for t in tokens)
                and not any(char.isdigit() for char in stripped)
                and len(stripped) < 50
            ):
                names_found += 1
                counter[0] += 1
                placeholder = f"[NAME_{names_found}]"
                mapping[placeholder] = stripped
                output.append(placeholder)
                continue

        output.append(line)

    return output, names_found


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def redact_identifiers(text: str, *, redact_names: bool = True) -> RedactionResult:
    """Remove directly identifying information from resume text.

    Returns a :class:`RedactionResult` whose ``text`` is safe to send to an
    external provider. On internal error the result is flagged and
    ``safe_to_transmit`` is False.
    """
    try:
        mapping: dict[str, str] = {}
        counters = {"emails": 0, "phones": 0, "urls": 0, "handles": 0, "names": 0}
        name_counter = [0]

        working = text

        # --- URLs first: an email inside a URL must not be double-processed ---
        def _url_replace(match: re.Match[str]) -> str:
            counters["urls"] += 1
            placeholder = f"[LINK_{counters['urls']}]"
            mapping[placeholder] = _SENSITIVE_URL_QUERY.sub("", match.group(0))
            return placeholder

        working = _URL.sub(_url_replace, working)
        working = _SENSITIVE_URL_QUERY.sub("", working)

        # --- Emails ---
        def _email_replace(match: re.Match[str]) -> str:
            counters["emails"] += 1
            placeholder = f"[EMAIL_{counters['emails']}]"
            mapping[placeholder] = match.group(0)
            return placeholder

        working = _EMAIL.sub(_email_replace, working)

        # --- Phones: only after emails are gone, so digits inside addresses and
        #     emails cannot be mistaken for a phone number.
        def _phone_replace(match: re.Match[str]) -> str:
            value = match.group(0)
            # Require a plausible number of digits to avoid swallowing years.
            if sum(char.isdigit() for char in value) < 8:
                return value
            counters["phones"] += 1
            placeholder = f"[PHONE_{counters['phones']}]"
            mapping[placeholder] = value.strip()
            return placeholder

        working = _PHONE.sub(_phone_replace, working)

        # --- Standalone PIN/ZIP at end of line ---
        working = _PIN.sub("[POSTCODE]", working)

        # --- Social handles ---
        def _handle_replace(match: re.Match[str]) -> str:
            counters["handles"] += 1
            placeholder = f"[HANDLE_{counters['handles']}]"
            mapping[placeholder] = match.group(0)
            return placeholder

        working = _SOCIAL_HANDLE.sub(_handle_replace, working)

        # --- Addresses ---
        working = _ADDRESS.sub("[ADDRESS]", working)

        # --- Protected attributes: whole line removed, not substituted. ---
        protected_hits = len(_PROTECTED_LABELLED.findall(working))
        working = _PROTECTED_LABELLED.sub("[REDACTED: PROTECTED ATTRIBUTE]", working)

        # --- Date of birth and age ---
        dob_hits = len(_DOB_LABELLED.findall(working))
        working = _DOB_LABELLED.sub("[REDACTED: DATE OF BIRTH]", working)
        working = _AGE.sub("[REDACTED: AGE]", working)

        # --- Names ---
        names_found = 0
        if redact_names:
            lines, names_found = _redact_labelled_names(working.splitlines(), mapping, name_counter)
            working = "\n".join(lines)

        counts = RedactionCounts(
            emails=counters["emails"],
            phones=counters["phones"],
            urls=counters["urls"],
            social_handles=counters["handles"],
            addresses=len(re.findall(r"\[ADDRESS\]", working)) + len(re.findall(r"\[POSTCODE\]", working)),
            dates_of_birth=dob_hits,
            protected_attributes=protected_hits,
            names=names_found,
        )

        return RedactionResult(text=working, counts=counts, mapping=mapping)

    except Exception as exc:  # noqa: BLE001 - fail closed, never transmit
        return RedactionResult(
            text="",
            counts=RedactionCounts(),
            mapping={},
            redaction_failed=True,
            error=f"{type(exc).__name__}: {exc}",
        )


def assert_redaction_safe(result: RedactionResult) -> None:
    """Guard for call sites that are about to make an external request.

    Raising is the correct behaviour: silently sending an unredacted resume is
    a privacy breach, and a failed pipeline run is not.
    """
    if not result.safe_to_transmit:
        raise RuntimeError(
            "Redaction failed; refusing to transmit resume content to an external "
            f"provider. Cause: {result.error}"
        )


__all__ = [
    "RedactionCounts",
    "RedactionResult",
    "assert_redaction_safe",
    "redact_identifiers",
]
