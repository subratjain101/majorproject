"""AI gateway: retries, schema validation, fallback and safe degradation.

Implements the flow required by SRS §17 in one place, so no call site has to
re-implement it (and, more importantly, so no call site can forget the final
clause and fabricate a result).

    AI CALL -> VALIDATE JSON -> valid? persist
                             -> invalid? retry (bounded)
                             -> exhausted? fall back to next provider
                             -> all failed? SAFE DEGRADATION, never fabrication
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from typing import Any, Generic, Sequence, TypeVar

from pydantic import BaseModel, ValidationError

from .providers.base import (
    AIProvider,
    AIProviderError,
    AIRequest,
    AIResponse,
    AISchemaValidationError,
    AIUsage,
)

T = TypeVar("T", bound=BaseModel)


@dataclass(frozen=True, slots=True)
class GatewayPolicy:
    """Retry and fallback behaviour. Configurable, not hard-coded."""

    max_attempts_per_provider: int = 2
    #: Extra instruction appended on the final retry, when a model has returned
    #: prose instead of JSON.
    strict_json_nudge: str = (
        "Your previous response was not valid JSON matching the required schema. "
        "Respond with JSON only: no prose, no markdown fences, no explanation."
    )
    backoff_base_seconds: float = 0.5


@dataclass(frozen=True, slots=True)
class GatewayResult(Generic[T]):
    """Outcome of a gateway call.

    ``value`` is None exactly when no provider produced a schema-valid result.
    Callers must handle that branch; the type makes the empty case impossible
    to overlook accidentally.
    """

    value: T | None
    provider: str | None
    model: str | None
    model_version: str | None
    latency_ms: int
    usage: AIUsage
    attempts: int
    #: Failures across every provider, in order, for the audit record.
    failures: tuple[str, ...] = ()
    #: True when the caller should fall back to a deterministic scorer.
    degraded: bool = False

    @property
    def ok(self) -> bool:
        return self.value is not None

    def to_provenance(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "model": self.model,
            "model_version": self.model_version,
            "latency_ms": self.latency_ms,
            "prompt_tokens": self.usage.prompt_tokens,
            "completion_tokens": self.usage.completion_tokens,
            "retries": max(0, self.attempts - 1),
            "is_fallback": self.degraded,
            "failure_reason": "; ".join(self.failures) if self.failures else None,
        }


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------

_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


def extract_json(text: str) -> str:
    """Pull a JSON document out of a model response.

    Models wrap JSON in prose or markdown fences often enough that failing on
    the first non-brace character would waste most of our retry budget. We
    therefore attempt a bounded, deterministic extraction *before* counting an
    attempt as a validation failure -- but we never guess at values, and a
    response with no JSON object at all is still a failure.
    """
    stripped = text.strip()

    fenced = _FENCE_RE.search(stripped)
    if fenced:
        stripped = fenced.group(1).strip()

    if stripped.startswith(("{", "[")):
        return stripped

    # Fall back to the outermost brace pair.
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start != -1 and end != -1 and end > start:
        return stripped[start : end + 1]

    return stripped


def validate_against_schema(text: str, schema: type[T]) -> T:
    """Validate raw text against a Pydantic model, raising a typed error."""
    try:
        payload = json.loads(extract_json(text))
    except json.JSONDecodeError as exc:
        raise AISchemaValidationError(f"Response was not parseable JSON: {exc}", raw_text=text) from exc

    try:
        return schema.model_validate(payload)
    except ValidationError as exc:
        raise AISchemaValidationError(
            f"Response did not match {schema.__name__}: {exc.error_count()} validation error(s)",
            raw_text=text,
        ) from exc


# ---------------------------------------------------------------------------
# Gateway
# ---------------------------------------------------------------------------


class AIGateway:
    """Routes generation requests across providers with validation and fallback.

    Providers are ordered by preference. Each is tried in turn; within a
    provider we retry only errors marked retryable, because retrying a
    non-retryable error wastes quota and delays the fallback that would have
    succeeded.
    """

    def __init__(
        self,
        providers: Sequence[AIProvider],
        *,
        policy: GatewayPolicy | None = None,
    ) -> None:
        self.providers = [p for p in providers if p.is_configured()]
        self._all_providers = list(providers)
        self.policy = policy or GatewayPolicy()

    # -- introspection ------------------------------------------------------

    @property
    def configured_count(self) -> int:
        return len(self.providers)

    def status(self) -> dict[str, Any]:
        """Health summary for the admin console and system-health page."""
        return {
            "configured_providers": [p.name for p in self.providers],
            "unconfigured_providers": [
                p.name for p in self._all_providers if not p.is_configured()
            ],
            "degraded": self.configured_count == 0,
        }

    # -- generation ---------------------------------------------------------

    async def generate_structured(
        self,
        request: AIRequest,
        schema: type[T],
    ) -> GatewayResult[T]:
        """Generate and validate structured output, with fallback.

        Returns ``degraded=True`` with ``value=None`` when no provider could
        produce valid output. It never returns a partially-filled or
        best-guess object.
        """
        if not self.providers:
            return GatewayResult(
                value=None,
                provider=None,
                model=None,
                model_version=None,
                latency_ms=0,
                usage=AIUsage(),
                attempts=0,
                failures=("No AI provider is configured.",),
                degraded=True,
            )

        attempts = 0
        failures: list[str] = []
        total_latency = 0

        for provider in self.providers:
            for attempt in range(1, self.policy.max_attempts_per_provider + 1):
                attempts += 1
                effective_request = request

                if attempt > 1 and request.response_schema is not None:
                    # Nudge toward strict JSON on the retry.
                    effective_request = AIRequest(
                        prompt=f"{request.prompt}\n\n{self.policy.strict_json_nudge}",
                        system=request.system,
                        messages=request.messages,
                        response_schema=request.response_schema,
                        temperature=0.0,
                        max_tokens=request.max_tokens,
                        correlation_id=request.correlation_id,
                    )

                try:
                    response = await provider.generate(effective_request)
                except AIProviderError as exc:
                    total_latency += 0
                    failures.append(f"{provider.name}: {exc}")
                    if not exc.retryable:
                        break  # stop retrying this provider, move to the next
                    if attempt < self.policy.max_attempts_per_provider:
                        await asyncio.sleep(self.policy.backoff_base_seconds * attempt)
                    continue
                except Exception as exc:  # noqa: BLE001 - provider SDKs raise widely
                    failures.append(f"{provider.name}: unexpected {type(exc).__name__}: {exc}")
                    break

                total_latency += response.latency_ms

                try:
                    value = validate_against_schema(response.text, schema)
                except AISchemaValidationError as exc:
                    failures.append(f"{provider.name}: {exc}")
                    if attempt < self.policy.max_attempts_per_provider:
                        await asyncio.sleep(self.policy.backoff_base_seconds * attempt)
                    continue

                return GatewayResult(
                    value=value,
                    provider=response.provider,
                    model=response.model,
                    model_version=response.model_version,
                    latency_ms=total_latency,
                    usage=response.usage,
                    attempts=attempts,
                    failures=tuple(failures),
                    degraded=False,
                )

        # Every provider and every attempt failed. Degrade -- do not invent.
        return GatewayResult(
            value=None,
            provider=None,
            model=None,
            model_version=None,
            latency_ms=total_latency,
            usage=AIUsage(),
            attempts=attempts,
            failures=tuple(failures),
            degraded=True,
        )


__all__ = [
    "AIGateway",
    "GatewayPolicy",
    "GatewayResult",
    "extract_json",
    "validate_against_schema",
]
