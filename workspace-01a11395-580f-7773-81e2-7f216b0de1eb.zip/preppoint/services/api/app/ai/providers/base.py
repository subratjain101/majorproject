"""AI provider abstraction (SRS §17).

THE RULE
--------
No vendor SDK is imported anywhere outside this package. Business logic depends
on the protocols below, never on a concrete vendor. That is what makes it
possible to swap providers, run fully self-hosted, or degrade gracefully during
an outage without touching domain code.

Every AI call in PrepPoint follows the same contract:

    AI CALL
      -> VALIDATE JSON against a schema
      -> VALID  ? persist
      -> INVALID? bounded retries
      -> still failing? fall back to another adapter
      -> no adapter available? safe degradation
      -> NEVER fabricate a result

The final clause is the important one. A missing score is recoverable; a
confidently wrong score is not, because the candidate has no way to tell it
apart from a correct one.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Generic, Protocol, TypeVar, runtime_checkable

from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)


# ---------------------------------------------------------------------------
# Request / response envelopes
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class AIMessage:
    """One turn in a conversation sent to a provider."""

    role: str  # "system" | "user" | "assistant"
    content: str


@dataclass(frozen=True, slots=True)
class AIRequest:
    """A provider-agnostic generation request.

    ``system`` is kept separate from ``messages`` on purpose. In every adapter
    it is rendered into the provider's *system* channel, never concatenated
    into user content -- that separation is the first line of defence against
    prompt injection from uploaded documents.
    """

    prompt: str
    system: str | None = None
    messages: tuple[AIMessage, ...] = ()
    #: JSON Schema the response must satisfy. Providers that support native
    #: structured output use this; others receive it as a textual instruction.
    response_schema: dict[str, Any] | None = None
    temperature: float = 0.2
    max_tokens: int = 2048
    #: Caller-supplied id, propagated into logs so a result can be traced.
    correlation_id: str | None = None


@dataclass(frozen=True, slots=True)
class AIUsage:
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    total_tokens: int | None = None

    def to_dict(self) -> dict[str, int | None]:
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
        }


@dataclass(frozen=True, slots=True)
class AIResponse:
    """Raw provider output plus the provenance the SRS requires us to store."""

    text: str
    provider: str
    model: str
    latency_ms: int
    usage: AIUsage = field(default_factory=AIUsage)
    model_version: str | None = None
    raw: dict[str, Any] | None = None
    received_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class AIProviderError(Exception):
    """Base class for provider failures.

    ``retryable`` drives the retry policy: a 429 or a timeout is worth another
    attempt, a 400 for a malformed prompt is not, and retrying it just burns
    quota.
    """

    def __init__(self, message: str, *, retryable: bool = False, status: int | None = None) -> None:
        super().__init__(message)
        self.retryable = retryable
        self.status = status


class AIProviderUnavailable(AIProviderError):
    """No provider is configured, or all providers failed. Triggers degradation."""


class AISchemaValidationError(AIProviderError):
    """The provider responded, but not in the shape we require.

    Deliberately retryable: a model that emits prose around valid JSON often
    gets it right on a second, more explicit attempt.
    """

    def __init__(self, message: str, *, raw_text: str = "") -> None:
        super().__init__(message, retryable=True)
        self.raw_text = raw_text


# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class AIProvider(Protocol):
    """Text generation with structured output."""

    name: str

    def is_configured(self) -> bool:
        """Whether credentials/config are present.

        Checked before use so an unconfigured adapter is skipped rather than
        raising at call time.
        """
        ...

    async def generate(self, request: AIRequest) -> AIResponse:
        ...


@runtime_checkable
class STTProvider(Protocol):
    """Speech to text. Used only by the optional voice interview."""

    name: str

    def is_configured(self) -> bool:
        ...

    async def transcribe(self, audio: bytes, *, language: str = "en") -> str:
        ...


@runtime_checkable
class TTSProvider(Protocol):
    """Text to speech."""

    name: str

    def is_configured(self) -> bool:
        ...

    async def synthesize(self, text: str, *, voice: str | None = None) -> bytes:
        ...


@runtime_checkable
class EmbeddingProviderProtocol(Protocol):
    """Embeddings for the semantic-fit term."""

    name: str

    def is_configured(self) -> bool:
        ...

    async def embed(self, texts: list[str]) -> list[list[float]]:
        ...


# ---------------------------------------------------------------------------
# Base implementations
# ---------------------------------------------------------------------------


class UnconfiguredProvider:
    """Mixin that reports cleanly when credentials are absent.

    Adapters are registered whether or not they are configured, so the gateway
    can reason about *why* degradation happened ("no provider configured")
    rather than hitting an AttributeError.
    """

    name: str = "unconfigured"
    _configured: bool = False

    def is_configured(self) -> bool:
        return self._configured


class NotConfiguredAIMixin(UnconfiguredProvider):
    async def generate(self, request: AIRequest) -> AIResponse:  # pragma: no cover - guard path
        raise AIProviderUnavailable(
            f"{self.name} is not configured. Set its credentials, or rely on the "
            "deterministic fallback.",
            retryable=False,
        )
