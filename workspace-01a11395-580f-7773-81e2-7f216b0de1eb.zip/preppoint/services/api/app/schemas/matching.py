"""Pydantic schemas for the matching API.

These are the wire contract (SRS §3: OpenAPI). They deliberately mirror the
domain dataclasses rather than being generated from the ORM -- the domain types
are the source of truth, and a schema change that diverges from them should
fail a test, not silently reshape what the engine means.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from app.domain.matching.types import EducationLevel, EvidenceSource, SkillRequirementKind


# ---------------------------------------------------------------------------
# Requests
# ---------------------------------------------------------------------------


class SkillEvidenceIn(BaseModel):
    skill_id: str = Field(min_length=1, max_length=120, examples=["system-design"])
    proficiency: float = Field(ge=0.0, le=1.0)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    source: EvidenceSource = EvidenceSource.RESUME
    evidence: list[str] = Field(default_factory=list, max_length=50)
    years_used: float | None = Field(default=None, ge=0, le=60)


class EducationIn(BaseModel):
    level: EducationLevel = EducationLevel.UNKNOWN
    degree_name: str | None = None
    institution: str | None = None
    field_of_study: str | None = None
    start_year: int | None = Field(default=None, ge=1950, le=2100)
    end_year: int | None = Field(default=None, ge=1950, le=2100)
    grade: str | None = None


class ExperienceIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    company: str | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    is_current: bool = False
    description: str = ""
    skill_ids: list[str] = Field(default_factory=list)

    @field_validator("end_date")
    @classmethod
    def end_after_start(cls, value: datetime | None, info) -> datetime | None:
        start = info.data.get("start_date")
        if value is not None and start is not None:
            # Compare in a timezone-safe way; a naive end date against an aware
            # start would otherwise raise here rather than in the domain layer.
            left = start.replace(tzinfo=None) if start.tzinfo else start
            right = value.replace(tzinfo=None) if value.tzinfo else value
            if right < left:
                raise ValueError("end_date must not be earlier than start_date")
        return value


class CandidateProfileIn(BaseModel):
    skills: list[SkillEvidenceIn] = Field(default_factory=list, max_length=500)
    educations: list[EducationIn] = Field(default_factory=list, max_length=20)
    experiences: list[ExperienceIn] = Field(default_factory=list, max_length=100)
    summary_text: str = Field(default="", max_length=20_000)
    total_years_experience: float | None = Field(default=None, ge=0, le=60)


class RoleSkillIn(BaseModel):
    skill_id: str = Field(min_length=1, max_length=120)
    canonical_name: str = Field(min_length=1, max_length=120)
    kind: SkillRequirementKind = SkillRequirementKind.REQUIRED
    importance: float = Field(default=1.0, ge=0.0, le=1.0)
    required_proficiency: float = Field(default=0.5, ge=0.0, le=1.0)
    prep_hours_from_zero: float = Field(default=8.0, ge=0, le=2000)
    category: str | None = None
    prerequisites: list[str] = Field(default_factory=list)
    interview_relevant: bool = True


class RoleProfileIn(BaseModel):
    role_id: str = Field(min_length=1, max_length=120)
    title: str = Field(min_length=1, max_length=200)
    requirements: list[RoleSkillIn] = Field(default_factory=list, max_length=200)
    min_years_experience: float | None = Field(default=None, ge=0, le=60)
    max_years_experience: float | None = Field(default=None, ge=0, le=60)
    education_level: EducationLevel = EducationLevel.UNKNOWN
    seniority: str | None = None
    description: str = Field(default="", max_length=40_000)
    company: str | None = None
    location: str | None = None


class MatchRequest(BaseModel):
    candidate: CandidateProfileIn
    role: RoleProfileIn
    #: Pin a configuration version to replay a historical score. When omitted
    #: the currently active configuration is used.
    config_version: str | None = None


class MatchManyRequest(BaseModel):
    candidate: CandidateProfileIn
    roles: list[RoleProfileIn] = Field(min_length=1, max_length=100)
    limit: int = Field(default=20, ge=1, le=100)


class GapAnalysisRequest(BaseModel):
    candidate: CandidateProfileIn
    role: RoleProfileIn


# ---------------------------------------------------------------------------
# Responses
# ---------------------------------------------------------------------------


class ComponentOut(BaseModel):
    """One assessed or explicitly not-assessed term of the index."""

    key: str
    label: str
    weight: float
    status: str
    #: null means NOT_ASSESSED. Clients must render the empty state from this
    #: being null rather than treating it as zero.
    value: float | None
    percent: float | None
    confidence: float
    rationale: str
    evidence: list[str]
    missing_evidence: list[str]


class MatchResultOut(BaseModel):
    role_id: str
    #: null when evidence coverage is too low to publish a number.
    display_index: float | None
    index: float
    index_zero_filled: float
    evidence_coverage: float
    is_reportable: bool
    config_version: str
    computed_at: datetime
    explanation: str
    warnings: list[str]
    components: list[ComponentOut]


class MatchManyResultOut(BaseModel):
    results: list[MatchResultOut]
    count: int


class RecommendedActionOut(BaseModel):
    action: str
    estimated_effort: str
    estimated_hours: float
    practice_modules: list[str]


class SkillGapOut(BaseModel):
    skill_id: str
    name: str
    severity: str
    reason: str
    importance: float
    requirement_kind: str
    role_relevance: str
    candidate_proficiency: float | None
    required_proficiency: float
    severity_score: float
    evidence: list[str]
    missing_evidence: list[str]
    estimated_preparation_hours: float
    interview_relevant: bool
    prerequisites: list[str]
    reassessment: str
    actions: list[RecommendedActionOut]


class SkillGapReportOut(BaseModel):
    role_id: str
    role_title: str
    summary: str
    total_estimated_hours: float
    roadmap_order: list[str]
    config_version: str
    counts: dict[str, int]
    matched: list[SkillGapOut]
    high: list[SkillGapOut]
    medium: list[SkillGapOut]
    low: list[SkillGapOut]
    strengths: list[SkillGapOut]


class HealthOut(BaseModel):
    status: str
    version: str
    match_config_version: str
    rubric_version: str
    ai_providers: dict[str, object]


__all__ = [
    "CandidateProfileIn",
    "ComponentOut",
    "GapAnalysisRequest",
    "HealthOut",
    "MatchManyRequest",
    "MatchManyResultOut",
    "MatchRequest",
    "MatchResultOut",
    "RoleProfileIn",
    "SkillGapReportOut",
]
