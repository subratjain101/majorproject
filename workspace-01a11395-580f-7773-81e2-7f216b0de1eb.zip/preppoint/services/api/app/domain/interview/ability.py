"""Adaptive ability estimation (SRS section 13).

The SRS specifies:

    E_t   = 1 / (1 + e^(-a(θ_t - d_t)))
    θ_t+1 = clip(θ_t + η(s_t - E_t), 0, 1)

with θ = estimated ability, d_t = difficulty of the item just answered,
s_t = observed score on that item (normalised to [0, 1]), a = discrimination,
η = learning rate.

WHY THIS FORM
-------------
E_t is the *expected* score on an item of difficulty d_t for a candidate of
ability θ. When the item is far easier than the candidate (θ >> d), E_t → 1 and
a correct answer produces almost no update -- the engine already knew. When the
item is far harder (θ << d), E_t → 0 and even a failure barely moves θ. The
update is driven by *surprise*, which is what makes it adaptive rather than a
running average.

This is a deliberately simple, auditable estimator. It is not IRT with
per-item calibration, and we do not pretend it is: item discrimination is a
per-item configurable parameter rather than a fitted value, and the SRS's
piecewise fallback (θ = mean of item difficulties seen) is retained as the
cold-start path until enough evidence accumulates.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import StrEnum


class Difficulty(StrEnum):
    """The SRS's three-band difficulty scale."""

    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"

    @property
    def anchor(self) -> float:
        """Position of this band on the [0, 1] ability scale.

        Chosen so the bands tile the scale with overlap at the boundaries:
        EASY items are expected to be answerable by anyone above ~0.25 ability,
        HARD items only by those above ~0.75.
        """
        return {Difficulty.EASY: 0.25, Difficulty.MEDIUM: 0.55, Difficulty.HARD: 0.82}[self]

    def bump_up(self) -> "Difficulty":
        """Next band up, saturating at HARD (SRS: never exceed Hard)."""
        return {Difficulty.EASY: Difficulty.MEDIUM, Difficulty.MEDIUM: Difficulty.HARD}.get(self, self)

    def bump_down(self) -> "Difficulty":
        """Next band down, saturating at EASY (SRS: never go below Easy)."""
        return {Difficulty.MEDIUM: Difficulty.EASY, Difficulty.HARD: Difficulty.MEDIUM}.get(self, self)


@dataclass(frozen=True, slots=True)
class AdaptationPolicy:
    """Configurable thresholds and constants for adaptation.

    SRS defaults: >= 7.8 raises, < 5.0 lowers, 5.0-7.8 maintains. The boundary
    is deliberately asymmetric -- the bar to move *up* is higher than the bar to
    hold steady, so a candidate is never escalated on a single lucky answer.
    """

    #: Normalised score (out of 10) at or above which difficulty increases.
    raise_threshold: float = 7.8
    #: Normalised score below which difficulty decreases.
    lower_threshold: float = 5.0
    #: Learning rate eta.
    learning_rate: float = 0.28
    #: Suppress item-level noise by tempering updates early in a session.
    initial_learning_rate_scale: float = 0.8
    #: Number of items over which the learning rate reaches full strength.
    warmup_items: int = 3
    #: Mean discrimination for items that do not specify one.
    default_discrimination: float = 1.9
    #: Ability evidence required before we trust theta over the piecewise mean.
    items_for_theta_confidence: int = 4
    #: Minimum items between difficulty changes, to stop oscillation.
    min_items_between_changes: int = 1

    def learning_rate_for(self, items_seen: int) -> float:
        """Ramp eta from a tempered value to full strength across the warm-up.

        Rationale: after one item, a 0.28-step update can leap θ across an
        entire difficulty band on the strength of a single answer. Tempering the
        first few updates costs nothing in accuracy and removes the "the
        interview suddenly felt like a different interview" failure mode.
        """
        if self.warmup_items <= 0:
            return self.learning_rate
        progress = min(1.0, (items_seen + 1) / (self.warmup_items + 1))
        scale = self.initial_learning_rate_scale + (1.0 - self.initial_learning_rate_scale) * progress
        return self.learning_rate * scale


DEFAULT_POLICY = AdaptationPolicy()


@dataclass(slots=True)
class AbilityState:
    """Mutable estimate of a candidate's ability during one interview session.

    ``history`` is retained in full because the SRS requires that a candidate
    can see *why* the interview went the way it did. An adaptation step that
    cannot be replayed is indistinguishable from an arbitrary one.
    """

    theta: float = 0.5
    difficulty: Difficulty = Difficulty.MEDIUM
    items_seen: int = 0
    #: (item_id, difficulty, observed_score_0_10, expected, theta_before, theta_after)
    history: list["AbilityUpdate"] = field(default_factory=list)
    #: Difficulty anchors of the items actually attempted, for the piecewise mean.
    _difficulty_anchors: list[float] = field(default_factory=list, repr=False)

    # -- expected score ----------------------------------------------------

    @staticmethod
    def expected_score(
        theta: float,
        difficulty: Difficulty,
        discrimination: float = DEFAULT_POLICY.default_discrimination,
    ) -> float:
        """E_t = 1 / (1 + e^(-a(θ_t - d_t))).

        Returned on [0, 1]. Callers converting to a 10-point display score must
        do so explicitly, so a units mix-up cannot silently corrupt θ.
        """
        exponent = -discrimination * (theta - difficulty.anchor)
        # Guard against overflow on extreme inputs; the logistic saturates
        # gracefully but math.exp raises for very large arguments.
        if exponent > 700:
            return 0.0
        if exponent < -700:
            return 1.0
        return 1.0 / (1.0 + math.exp(exponent))

    # -- update ------------------------------------------------------------

    def record(
        self,
        *,
        item_id: str,
        score_out_of_10: float | None,
        difficulty: Difficulty | None = None,
        discrimination: float | None = None,
        policy: AdaptationPolicy = DEFAULT_POLICY,
        assessed: bool = True,
    ) -> "AbilityUpdate":
        """Fold one item result into the ability estimate.

        ``assessed=False`` (an insufficient-evidence evaluation, per SRS
        section 14) records the item as seen but does **not** update θ and does
        **not** change difficulty. A score we refused to fabricate cannot be
        allowed to steer the interview.
        """
        item_difficulty = difficulty or self.difficulty
        a = discrimination if discrimination is not None else policy.default_discrimination

        theta_before = self.theta
        items_before = self.items_seen
        difficulty_before = self.difficulty

        if not assessed or score_out_of_10 is None:
            update = AbilityUpdate(
                item_id=item_id,
                difficulty=item_difficulty,
                observed_score=None,
                observed_normalised=None,
                expected=self.expected_score(theta_before, item_difficulty, a),
                theta_before=theta_before,
                theta_after=theta_before,
                learning_rate=0.0,
                assessed=False,
                difficulty_changed=False,
                rationale=(
                    "This answer was not scored because there was insufficient evidence, "
                    "so it did not affect your ability estimate or the difficulty of the "
                    "next question."
                ),
            )
            self.items_seen += 1
            self._difficulty_anchors.append(item_difficulty.anchor)
            self.history.append(update)
            return update

        observed = _clamp01(score_out_of_10 / 10.0)
        expected = self.expected_score(theta_before, item_difficulty, a)
        eta = policy.learning_rate_for(items_before)

        theta_after = _clip(theta_before + eta * (observed - expected), 0.0, 1.0)

        self.theta = theta_after
        self.items_seen += 1
        self._difficulty_anchors.append(item_difficulty.anchor)

        # -- difficulty transition (SRS piecewise rules, on the 0-10 scale) --
        difficulty_changed = False
        rationale_bits: list[str] = []
        if (
            items_before >= policy.min_items_between_changes
        ):
            if score_out_of_10 >= policy.raise_threshold:
                new_difficulty = self.difficulty.bump_up()
                if new_difficulty is not self.difficulty:
                    difficulty_changed = True
                    rationale_bits.append(
                        f"Score {score_out_of_10:.1f} is at or above {policy.raise_threshold}; "
                        f"difficulty raised {self.difficulty.value} -> {new_difficulty.value}."
                    )
                else:
                    rationale_bits.append("Already at maximum difficulty; difficulty held.")
                self.difficulty = new_difficulty
            elif score_out_of_10 < policy.lower_threshold:
                new_difficulty = self.difficulty.bump_down()
                if new_difficulty is not self.difficulty:
                    difficulty_changed = True
                    rationale_bits.append(
                        f"Score {score_out_of_10:.1f} is below {policy.lower_threshold}; "
                        f"difficulty lowered {self.difficulty.value} -> {new_difficulty.value}."
                    )
                else:
                    rationale_bits.append("Already at minimum difficulty; difficulty held.")
                self.difficulty = new_difficulty
            else:
                rationale_bits.append(
                    f"Score {score_out_of_10:.1f} is inside the steady band "
                    f"({policy.lower_threshold}-{policy.raise_threshold}); difficulty held at "
                    f"{self.difficulty.value}."
                )
        else:
            rationale_bits.append("Warm-up item; difficulty held.")

        update = AbilityUpdate(
            item_id=item_id,
            difficulty=item_difficulty,
            observed_score=score_out_of_10,
            observed_normalised=observed,
            expected=expected,
            theta_before=theta_before,
            theta_after=theta_after,
            learning_rate=eta,
            assessed=True,
            difficulty_changed=difficulty_changed,
            difficulty_after=self.difficulty if difficulty_changed else difficulty_before,
            rationale=" ".join(rationale_bits),
        )
        self.history.append(update)
        return update

    # -- read-outs ---------------------------------------------------------

    @property
    def is_confident(self) -> bool:
        """Whether θ is backed by enough items to outrank the piecewise mean."""
        return self.items_seen >= DEFAULT_POLICY.items_for_theta_confidence

    def piecewise_estimate(self) -> float:
        """SRS fallback: mean difficulty of items attempted so far.

        Used only when θ is not yet confident, and reported as such so the
        scorecard can distinguish "estimated from item difficulty" from
        "estimated from performance".
        """
        if not self._difficulty_anchors:
            return 0.5
        return sum(self._difficulty_anchors) / len(self._difficulty_anchors)

    def effective_theta(self) -> float:
        """θ when confident, tempered toward the piecewise estimate when not.

        Blending rather than switching avoids a visible jump in behaviour when
        the confidence threshold is crossed mid-session.
        """
        if self.is_confident:
            return self.theta
        weight = self.items_seen / max(DEFAULT_POLICY.items_for_theta_confidence, 1)
        return _clip(weight * self.theta + (1 - weight) * self.piecewise_estimate(), 0.0, 1.0)

    def next_difficulty_band(self) -> Difficulty:
        """Difficulty suggested by current ability, independent of the last transition.

        Used when a session resumes or when the next item must come from a
        section the previous band has exhausted.
        """
        theta = self.effective_theta()
        if theta < 0.38:
            return Difficulty.EASY
        if theta < 0.70:
            return Difficulty.MEDIUM
        return Difficulty.HARD

    def to_dict(self) -> dict[str, object]:
        return {
            "theta": round(self.theta, 4),
            "effective_theta": round(self.effective_theta(), 4),
            "difficulty": self.difficulty.value,
            "items_seen": self.items_seen,
            "is_confident": self.is_confident,
            "piecewise_estimate": round(self.piecewise_estimate(), 4),
            "history": [h.to_dict() for h in self.history],
        }


@dataclass(frozen=True, slots=True)
class AbilityUpdate:
    """Audit record of one adaptation decision. Replayable, by construction."""

    item_id: str
    difficulty: Difficulty
    observed_score: float | None
    observed_normalised: float | None
    expected: float
    theta_before: float
    theta_after: float
    learning_rate: float
    assessed: bool
    difficulty_changed: bool
    difficulty_after: Difficulty | None = None
    rationale: str = ""

    @property
    def surprise(self) -> float:
        """s_t - E_t. Positive means the candidate beat the model's expectation."""
        if self.observed_normalised is None:
            return 0.0
        return self.observed_normalised - self.expected

    def to_dict(self) -> dict[str, object]:
        return {
            "item_id": self.item_id,
            "difficulty": self.difficulty.value,
            "observed_score": self.observed_score,
            "expected_score": round(self.expected * 10, 2),
            "surprise": round(self.surprise, 4),
            "theta_before": round(self.theta_before, 4),
            "theta_after": round(self.theta_after, 4),
            "learning_rate": round(self.learning_rate, 4),
            "assessed": self.assessed,
            "difficulty_changed": self.difficulty_changed,
            "difficulty_after": self.difficulty_after.value if self.difficulty_after else None,
            "rationale": self.rationale,
        }


def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _clamp01(value: float) -> float:
    return _clip(value, 0.0, 1.0)


__all__ = [
    "AbilityState",
    "AbilityUpdate",
    "AdaptationPolicy",
    "DEFAULT_POLICY",
    "Difficulty",
]
