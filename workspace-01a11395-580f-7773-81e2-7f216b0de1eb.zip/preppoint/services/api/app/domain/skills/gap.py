"""Skill gap engine (SRS section 10).

The SRS is explicit that "missing Python" is not an acceptable output. Every
gap carries: importance, evidence, reason, role relevance, a recommended
action, an estimated preparation effort, linked practice modules and an
interview-relevance flag.

SEVERITY IS NOT JUST "AM I MISSING IT"
--------------------------------------
Severity blends four signals:
  1. role importance of the skill,
  2. whether the skill is required or merely preferred,
  3. how far the candidate's evidenced proficiency sits below the bar,
  4. interview relevance (a gap that will be probed out loud next week stings
     more than one that only matters on paper).

That blend is what turns a flat list of missing keywords into a prioritisation
a candidate can actually act on Monday morning.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from ..matching.config import CareerMatchConfig, DEFAULT_CAREER_MATCH_CONFIG
from ..matching.types import (
    CandidateProfile,
    RoleProfile,
    RoleSkillRequirement,
    SkillRequirementKind,
    clamp,
    round_half_up,
)


class GapSeverity(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    NONE = "none"


class GapReason(StrEnum):
    """Why a skill appears in the report at all.

    Distinguishing "you do not have this" from "you have this but we have weak
    evidence" is the single most useful thing the gap engine can tell someone.
    The remedies are completely different: learn versus document.
    """

    MISSING = "missing"                     # no evidence at all
    WEAK_EVIDENCE = "weak_evidence"          # present but below the bar, or low confidence
    UNDOCUMENTED = "undocumented"            # interview/practice shows it, resume does not
    STRENGTH = "strength"                    # above the bar -- shown for balance


@dataclass(frozen=True, slots=True)
class RecommendedAction:
    """One concrete, checkable step. Never "learn Python"."""

    action: str
    #: Human-readable estimate, e.g. "6-10 hours".
    estimated_effort: str
    estimated_hours: float
    #: Practice module slugs the candidate can start immediately.
    practice_modules: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SkillGap:
    """A single skill's verdict for a single role."""

    skill_id: str
    canonical_name: str
    severity: GapSeverity
    reason: GapReason
    importance: float
    requirement_kind: SkillRequirementKind
    role_relevance: str
    #: Candidate's evidenced proficiency, or None if never evidenced.
    candidate_proficiency: float | None
    required_proficiency: float
    #: 0-1 severity score before bucketing, retained for explainability/sorting.
    severity_score: float
    evidence: tuple[str, ...] = ()
    missing_evidence: tuple[str, ...] = ()
    actions: tuple[RecommendedAction, ...] = ()
    estimated_preparation_hours: float = 0.0
    interview_relevant: bool = True
    #: Skill ids that block this one; roadmap uses these to order work.
    prerequisites: tuple[str, ...] = ()
    #: How to prove improvement -- the reassessment path.
    reassessment: str = ""

    @property
    def is_actionable(self) -> bool:
        return self.severity in (GapSeverity.HIGH, GapSeverity.MEDIUM)

    def to_dict(self) -> dict[str, object]:
        return {
            "skill_id": self.skill_id,
            "name": self.canonical_name,
            "severity": self.severity.value,
            "reason": self.reason.value,
            "importance": round_half_up(self.importance, 2),
            "requirement_kind": self.requirement_kind.value,
            "role_relevance": self.role_relevance,
            "candidate_proficiency": (
                None if self.candidate_proficiency is None
                else round_half_up(self.candidate_proficiency, 3)
            ),
            "required_proficiency": round_half_up(self.required_proficiency, 2),
            "severity_score": round_half_up(self.severity_score, 3),
            "evidence": list(self.evidence),
            "missing_evidence": list(self.missing_evidence),
            "estimated_preparation_hours": round_half_up(self.estimated_preparation_hours, 1),
            "interview_relevant": self.interview_relevant,
            "prerequisites": list(self.prerequisites),
            "reassessment": self.reassessment,
            "actions": [
                {
                    "action": a.action,
                    "estimated_effort": a.estimated_effort,
                    "estimated_hours": a.estimated_hours,
                    "practice_modules": list(a.practice_modules),
                }
                for a in self.actions
            ],
        }


@dataclass(frozen=True, slots=True)
class SkillGapReport:
    """The complete gap analysis for one candidate against one role."""

    role_id: str
    role_title: str
    matched: tuple[SkillGap, ...]
    high: tuple[SkillGap, ...]
    medium: tuple[SkillGap, ...]
    low: tuple[SkillGap, ...]
    strengths: tuple[SkillGap, ...]
    total_estimated_hours: float
    #: Suggested order of attack, respecting prerequisites.
    roadmap_order: tuple[str, ...]
    config_version: str
    summary: str

    def to_dict(self) -> dict[str, object]:
        return {
            "role_id": self.role_id,
            "role_title": self.role_title,
            "summary": self.summary,
            "total_estimated_hours": round_half_up(self.total_estimated_hours, 1),
            "roadmap_order": list(self.roadmap_order),
            "config_version": self.config_version,
            "counts": {
                "high": len(self.high),
                "medium": len(self.medium),
                "low": len(self.low),
                "matched": len(self.matched),
                "strengths": len(self.strengths),
            },
            "matched": [g.to_dict() for g in self.matched],
            "high": [g.to_dict() for g in self.high],
            "medium": [g.to_dict() for g in self.medium],
            "low": [g.to_dict() for g in self.low],
            "strengths": [g.to_dict() for g in self.strengths],
        }


# ---------------------------------------------------------------------------
# Severity thresholds (configurable, versioned with the match config)
# ---------------------------------------------------------------------------

@dataclass(frozen=True, slots=True)
class SeverityThresholds:
    """Bucketing thresholds for severity_score. Tune in config, not in code."""

    high: float = 0.62
    medium: float = 0.34
    low: float = 0.12

    def classify(self, score: float) -> GapSeverity:
        if score >= self.high:
            return GapSeverity.HIGH
        if score >= self.medium:
            return GapSeverity.MEDIUM
        if score >= self.low:
            return GapSeverity.LOW
        return GapSeverity.NONE


DEFAULT_SEVERITY_THRESHOLDS = SeverityThresholds()


def _kind_ceiling(kind: SkillRequirementKind) -> float:
    """Upper bound on severity imposed by how much the role actually cares.

    These sit just below the band thresholds, which makes the rule exact rather
    than approximate: a gap on a *preferred* skill can reach at most 0.60 and
    therefore can never be reported as HIGH, no matter how large the shortfall.
    Likewise a nice-to-have skill is capped below MEDIUM.

    The alternative -- relying on the multipliers alone to keep preferred gaps
    out of HIGH -- is fragile: retune any weight and the guarantee silently
    disappears.
    """
    return {
        SkillRequirementKind.REQUIRED: 1.0,
        SkillRequirementKind.PREFERRED: 0.60,
        SkillRequirementKind.NICE_TO_HAVE: 0.33,
    }[kind]


# ---------------------------------------------------------------------------
# Practice module catalogue
# ---------------------------------------------------------------------------
#
# Maps a skill to the practice surfaces that can close it. Kept as data so the
# roadmap can link straight into the practice modules without the gap engine
# knowing anything about them.

_PRACTICE_MAP: dict[str, tuple[str, ...]] = {
    "system-design": ("dsa:scalability-basics", "interview:system-design", "aptitude:estimation"),
    "dsa": ("dsa:arrays-strings", "dsa:trees-graphs", "dsa:dynamic-programming"),
    "algorithms": ("dsa:complexity-analysis", "dsa:sorting-searching"),
    "sql": ("dsa:sql-fundamentals", "dsa:query-optimisation"),
    "python": ("dsa:python-basics", "interview:python-fundamentals"),
    "typescript": ("dsa:typescript-basics",),
    "react": ("interview:react-patterns", "dsa:frontend-state"),
    "docker": ("interview:containers", "dsa:devops-basics"),
    "kubernetes": ("interview:orchestration", "dsa:devops-basics"),
    "aws": ("interview:cloud-architecture",),
    "communication": ("interview:behavioural", "aptitude:verbal"),
    "machine-learning": ("interview:ml-fundamentals", "dsa:ml-pipelines"),
}

_DEFAULT_PRACTICE = ("interview:role-fundamentals",)


def _actions_for(
    requirement: RoleSkillRequirement,
    reason: GapReason,
    shortfall_ratio: float,
    hours_needed: float,
) -> tuple[RecommendedAction, ...]:
    """Build concrete next steps. The shape of the advice depends on the reason."""
    modules = _PRACTICE_MAP.get(requirement.skill_id, _DEFAULT_PRACTICE)
    name = requirement.canonical_name

    if reason is GapReason.UNDOCUMENTED:
        return (
            RecommendedAction(
                action=(
                    f"Your interview and practice results show working {name}, but your "
                    f"resume carries no evidence of it. Add one project or role bullet "
                    f"that states what you built with {name} and what it changed."
                ),
                estimated_effort="1-2 hours",
                estimated_hours=1.5,
                practice_modules=(),
            ),
            RecommendedAction(
                action=f"Re-run the resume analysis afterwards so {name} appears on your profile as evidence, not a claim.",
                estimated_effort="2 minutes",
                estimated_hours=0.05,
                practice_modules=("resume:reanalyse",),
            ),
        )

    if reason is GapReason.WEAK_EVIDENCE:
        return (
            RecommendedAction(
                action=(
                    f"Strengthen {name} from {shortfall_ratio:.0%} below the role's bar to it. "
                    "Work through the linked modules, then build one small artefact you can "
                    "point at."
                ),
                estimated_effort=_effort_label(hours_needed),
                estimated_hours=hours_needed,
                practice_modules=modules,
            ),
            RecommendedAction(
                action=f"Take an adaptive {name} interview to check whether the gap is real or just under-documented.",
                estimated_effort="25 minutes",
                estimated_hours=0.4,
                practice_modules=("interview:adaptive",),
            ),
        )

    # MISSING
    return (
        RecommendedAction(
            action=(
                f"Learn {name} fundamentals end to end. Start with the linked modules in "
                "order rather than jumping to advanced material."
            ),
            estimated_effort=_effort_label(hours_needed),
            estimated_hours=hours_needed,
            practice_modules=modules,
        ),
        RecommendedAction(
            action=f"Practise applied {name} on at least two DSA or project exercises so you have something concrete to describe.",
            estimated_effort=f"{hours_needed * 0.5:.0f}-{hours_needed * 0.8:.0f} hours",
            estimated_hours=round(hours_needed * 0.65, 1),
            practice_modules=modules[:2],
        ),
        RecommendedAction(
            action=f"Re-run this match and take a {name} interview to convert study into measured evidence.",
            estimated_effort="40 minutes",
            estimated_hours=0.7,
            practice_modules=("interview:adaptive", "resume:reanalyse"),
        ),
    )


def _effort_label(hours: float) -> str:
    """Render hours as a human range, not a false-precision number."""
    if hours <= 1:
        return "under an hour"
    if hours <= 4:
        return f"{max(1, int(hours * 0.75))}-{int(hours * 1.25) + 1} hours"
    if hours <= 20:
        return f"{int(hours * 0.8)}-{int(hours * 1.2)} hours (about a focused week of evenings)"
    if hours <= 60:
        return f"{int(hours * 0.8)}-{int(hours * 1.2)} hours (a few weeks part-time)"
    return f"{int(hours // 10) * 10}-{int(hours * 1.2 // 10) * 10} hours (a structured multi-month track)"


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------


class SkillGapEngine:
    """Turns a candidate + role into an actionable, prioritised gap report."""

    def __init__(
        self,
        *,
        config: CareerMatchConfig | None = None,
        thresholds: SeverityThresholds | None = None,
    ) -> None:
        self.config = config or DEFAULT_CAREER_MATCH_CONFIG
        self.thresholds = thresholds or DEFAULT_SEVERITY_THRESHOLDS

    def analyse(self, candidate: CandidateProfile, role: RoleProfile) -> SkillGapReport:
        skill_index = candidate.skill_index()
        gaps: list[SkillGap] = []
        matched: list[SkillGap] = []
        strengths: list[SkillGap] = []

        for requirement in role.requirements:
            gap = self._evaluate(requirement, skill_index)
            if gap.reason is GapReason.STRENGTH:
                strengths.append(gap)
                matched.append(gap)
            elif gap.severity is GapSeverity.NONE:
                matched.append(gap)
            else:
                gaps.append(gap)

        high = tuple(sorted((g for g in gaps if g.severity is GapSeverity.HIGH), key=_severity_sort))
        medium = tuple(sorted((g for g in gaps if g.severity is GapSeverity.MEDIUM), key=_severity_sort))
        low = tuple(sorted((g for g in gaps if g.severity is GapSeverity.LOW), key=_severity_sort))

        actionable = high + medium
        total_hours = sum(g.estimated_preparation_hours for g in actionable)
        roadmap = self._order(tuple(high) + tuple(medium) + tuple(low))

        return SkillGapReport(
            role_id=role.role_id,
            role_title=role.title,
            matched=tuple(matched),
            high=high,
            medium=medium,
            low=low,
            strengths=tuple(strengths),
            total_estimated_hours=total_hours,
            roadmap_order=roadmap,
            config_version=self.config.version,
            summary=self._summarise(role, high, medium, strengths, total_hours),
        )

    # -- internals ---------------------------------------------------------

    def _evaluate(self, requirement: RoleSkillRequirement, skill_index: dict) -> SkillGap:
        evidence_item = skill_index.get(requirement.skill_id)
        name = requirement.canonical_name
        modules = _PRACTICE_MAP.get(requirement.skill_id, _DEFAULT_PRACTICE)

        # ---- no evidence at all ----
        if evidence_item is None:
            shortfall = 1.0
            hours = requirement.prep_hours_from_zero * (0.6 + 0.8 * requirement.importance)
            return SkillGap(
                skill_id=requirement.skill_id,
                canonical_name=name,
                severity=self.thresholds.classify(
                    self._severity_score(requirement, shortfall, reason=GapReason.MISSING)
                ),
                reason=GapReason.MISSING,
                importance=requirement.importance,
                requirement_kind=requirement.kind,
                role_relevance=self._relevance(requirement),
                candidate_proficiency=None,
                required_proficiency=requirement.required_proficiency,
                severity_score=self._severity_score(requirement, shortfall, reason=GapReason.MISSING),
                missing_evidence=(
                    f"Any resume line, project or role that demonstrates {name}",
                    f"An interview answer that shows working {name}",
                ),
                actions=_actions_for(requirement, GapReason.MISSING, shortfall, hours),
                estimated_preparation_hours=round(hours, 1),
                interview_relevant=requirement.interview_relevant,
                prerequisites=requirement.prerequisites,
                reassessment=(
                    f"Re-run this match after completing the modules, then take a {name} "
                    "adaptive interview. Both feed back into this report."
                ),
            )

        proficiency = evidence_item.proficiency
        confidence = evidence_item.confidence
        bar = max(requirement.required_proficiency, self.config.skill.min_proficiency)

        # ---- evidenced, but below the bar OR on thin evidence ----
        if proficiency < bar or confidence < self.config.evidence.min_assessable_confidence:
            shortfall = clamp((bar - proficiency) / bar if bar > 0 else 0.0)
            if confidence < self.config.evidence.min_assessable_confidence:
                shortfall = max(shortfall, 0.5)  # unknown is treated as a risk, not a pass
            hours = requirement.prep_hours_from_zero * shortfall * (0.8 + 0.4 * requirement.importance)
            reason = GapReason.WEAK_EVIDENCE
            return SkillGap(
                skill_id=requirement.skill_id,
                canonical_name=name,
                severity=self.thresholds.classify(
                    self._severity_score(requirement, shortfall, reason=reason)
                ),
                reason=reason,
                importance=requirement.importance,
                requirement_kind=requirement.kind,
                role_relevance=self._relevance(requirement),
                candidate_proficiency=proficiency,
                required_proficiency=requirement.required_proficiency,
                severity_score=self._severity_score(requirement, shortfall, reason=reason),
                evidence=evidence_item.evidence,
                missing_evidence=(
                    f"Evidence of {name} at or above {bar:.0%} proficiency (currently {proficiency:.0%})",
                ),
                actions=_actions_for(requirement, reason, shortfall, hours),
                estimated_preparation_hours=round(hours, 1),
                interview_relevant=requirement.interview_relevant,
                prerequisites=requirement.prerequisites,
                reassessment=f"Re-run the match once you can point at a {name} artefact.",
            )

        # ---- met, and clearly so ----
        if proficiency >= max(bar, self.config.skill.full_proficiency):
            return SkillGap(
                skill_id=requirement.skill_id,
                canonical_name=name,
                severity=GapSeverity.NONE,
                reason=GapReason.STRENGTH,
                importance=requirement.importance,
                requirement_kind=requirement.kind,
                role_relevance=self._relevance(requirement),
                candidate_proficiency=proficiency,
                required_proficiency=requirement.required_proficiency,
                severity_score=0.0,
                evidence=evidence_item.evidence,
                reassessment="",
            )

        # ---- met, but only just: worth a nudge, never a "high" ----
        headroom = clamp(max(bar, self.config.skill.full_proficiency) - proficiency)
        return SkillGap(
            skill_id=requirement.skill_id,
            canonical_name=name,
            severity=GapSeverity.LOW,
            reason=GapReason.WEAK_EVIDENCE,
            importance=requirement.importance,
            requirement_kind=requirement.kind,
            role_relevance=self._relevance(requirement),
            candidate_proficiency=proficiency,
            required_proficiency=requirement.required_proficiency,
            severity_score=self._severity_score(requirement, headroom * 0.5, reason=GapReason.WEAK_EVIDENCE),
            evidence=evidence_item.evidence,
            missing_evidence=(
                f"Stronger evidence of {name} -- you meet the bar but have room to demonstrate depth",
            ),
            actions=(
                RecommendedAction(
                    action=f"You already meet the {name} bar. One deeper project or an advanced module would move this to a strength.",
                    estimated_effort=_effort_label(max(2.0, requirement.prep_hours_from_zero * 0.35)),
                    estimated_hours=max(2.0, requirement.prep_hours_from_zero * 0.35),
                    practice_modules=modules,
                ),
            ),
            estimated_preparation_hours=round(max(2.0, requirement.prep_hours_from_zero * 0.35), 1),
            interview_relevant=requirement.interview_relevant,
            prerequisites=requirement.prerequisites,
            reassessment=f"Re-run the match after adding {name} depth.",
        )

    @staticmethod
    def _severity_score(
        requirement: RoleSkillRequirement,
        shortfall: float,
        *,
        reason: GapReason,
    ) -> float:
        """Blend how much the role cares with how big the gap actually is.

        THE MISTAKE THIS FORMULA EXISTS TO AVOID
        ----------------------------------------
        An earlier version added a flat ``+0.20 * kind_factor`` for being a
        required skill. The effect was that *every* required skill cleared the
        HIGH threshold regardless of gap size: a candidate 8% below the bar on
        an important skill (a two-hour fix) was flagged HIGH priority alongside
        a genuinely absent, forty-hour skill. Severity was measuring the shape
        of the job description rather than the candidate's deficiency, which
        makes the whole report untrustworthy.

        The corrected shape:

            severity = kind_factor * importance * (base + (1-base)*shortfall)
                       + interview_bonus * (weighted by shortfall)

        so a large gap in an important role skill approaches 1.0, while a small
        shortfall in the same skill lands in MEDIUM. The interview bonus is
        damped by shortfall too: a gap you have essentially closed should not
        be inflated by the fact that interviewers like to ask about it.

        Requirement kind then caps the result (see ``_kind_ceiling``): a missing
        *preferred* skill can never outrank a required one, however large the
        shortfall.
        """
        kind_factor = {
            SkillRequirementKind.REQUIRED: 1.0,
            SkillRequirementKind.PREFERRED: 0.7,
            SkillRequirementKind.NICE_TO_HAVE: 0.4,
        }[requirement.kind]

        reason_factor = {
            GapReason.MISSING: 1.0,
            GapReason.WEAK_EVIDENCE: 0.85,
            GapReason.UNDOCUMENTED: 0.6,
            GapReason.STRENGTH: 0.0,
        }[reason]

        base = 0.35
        gap_size = clamp(shortfall)
        shortfall_factor = base + (1.0 - base) * gap_size

        interview_bonus = (
            0.10 * (0.40 + 0.60 * gap_size) if requirement.interview_relevant else 0.0
        )

        score = (
            kind_factor
            * clamp(requirement.importance)
            * shortfall_factor
            * reason_factor
            + interview_bonus
        )
        return clamp(min(score, _kind_ceiling(requirement.kind)))

    @staticmethod
    def _relevance(requirement: RoleSkillRequirement) -> str:
        kind = {
            SkillRequirementKind.REQUIRED: "listed as a required skill",
            SkillRequirementKind.PREFERRED: "listed as a preferred skill",
            SkillRequirementKind.NICE_TO_HAVE: "listed as nice-to-have",
        }[requirement.kind]
        probe = (
            " Interviewers commonly probe this, so it affects both your resume screen and your interview."
            if requirement.interview_relevant
            else " This is unlikely to be probed directly in an interview."
        )
        return f"{requirement.canonical_name} is {kind} for this role at {requirement.importance:.0%} importance.{probe}"

    @staticmethod
    def _order(gaps: tuple[SkillGap, ...]) -> tuple[str, ...]:
        """Order work by prerequisite then severity.

        Prerequisites first is non-negotiable: telling someone to learn
        Kubernetes before they understand containers is how roadmaps lose
        people in week one.
        """
        by_id = {g.skill_id: g for g in gaps}
        ordered: list[str] = []
        visited: set[str] = set()

        def visit(skill_id: str, stack: frozenset[str]) -> None:
            if skill_id in visited or skill_id not in by_id or skill_id in stack:
                return  # cycle guard: a malformed taxonomy must not hang the worker
            gap = by_id[skill_id]
            for prerequisite in gap.prerequisites:
                visit(prerequisite, stack | {skill_id})
            visited.add(skill_id)
            ordered.append(skill_id)

        severity_rank = {GapSeverity.HIGH: 0, GapSeverity.MEDIUM: 1, GapSeverity.LOW: 2, GapSeverity.NONE: 3}
        for gap in sorted(gaps, key=lambda g: (severity_rank[g.severity], -g.severity_score)):
            visit(gap.skill_id, frozenset())

        return tuple(ordered)

    @staticmethod
    def _summarise(
        role: RoleProfile,
        high: tuple[SkillGap, ...],
        medium: tuple[SkillGap, ...],
        strengths: tuple[SkillGap, ...],
        total_hours: float,
    ) -> str:
        if not high and not medium:
            return (
                f"You meet every required and preferred skill for {role.title}. "
                f"The remaining work is depth, not coverage: {len(strengths)} skills are already "
                "clear strengths. Shift your effort to interview practice and evidence quality."
            )

        parts: list[str] = []
        if high:
            names = ", ".join(g.canonical_name for g in high[:3])
            more = f" and {len(high) - 3} more" if len(high) > 3 else ""
            parts.append(f"{len(high)} high-priority gap{'s' if len(high) != 1 else ''} ({names}{more})")
        if medium:
            parts.append(f"{len(medium)} medium-priority gap{'s' if len(medium) != 1 else ''}")
        if strengths:
            parts.append(f"{len(strengths)} confirmed strength{'s' if len(strengths) != 1 else ''}")

        estimate = (
            f"roughly {total_hours:.0f} focused hours"
            if total_hours < 40
            else f"roughly {total_hours / 10:.1f} focused weeks at 10 hours per week"
        )
        return (
            f"Against {role.title}: {'; '.join(parts)}. "
            f"Closing the actionable gaps is about {estimate}. "
            "Start at the top of the roadmap -- it already accounts for prerequisites."
        )


def _severity_sort(gap: SkillGap) -> tuple[int, float, str]:
    """Sort key for actionable gaps: severity desc, then score desc, then name."""
    return (-int(gap.severity_score * 1000), -gap.importance, gap.canonical_name)


__all__ = [
    "DEFAULT_SEVERITY_THRESHOLDS",
    "GapReason",
    "GapSeverity",
    "RecommendedAction",
    "SeverityThresholds",
    "SkillGap",
    "SkillGapEngine",
    "SkillGapReport",
]
