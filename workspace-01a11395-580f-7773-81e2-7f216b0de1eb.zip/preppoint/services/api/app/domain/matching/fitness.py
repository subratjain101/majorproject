"""The four fitness terms of the Career Match Index.

Each term is a pure function returning a :class:`ComponentScore`. Keeping them
separate and independently testable is the whole point: when a candidate asks
"why is my experience fit 74%?", exactly one function is responsible for that
number, and it has a documented rationale string attached.
"""

from __future__ import annotations

from .config import (
    CareerMatchConfig,
    EducationFitConfig,
    ExperienceFitConfig,
    SkillFitConfig,
)
from .types import (
    CandidateProfile,
    ComponentScore,
    ComponentStatus,
    EducationLevel,
    RoleProfile,
    RoleSkillRequirement,
    clamp,
    safe_ratio,
)


# ---------------------------------------------------------------------------
# fsk -- skill fit (SRS section 9)
# ---------------------------------------------------------------------------


def _matched_requirement(
    requirement: RoleSkillRequirement,
    skill_index: dict,
    cfg: SkillFitConfig,
) -> tuple[bool, float, str | None]:
    """Decide whether a listed skill requirement is satisfied.

    Returns (matched, credit, evidence_note).

    Matching is evidence-gated. A keyword in a skills list with no proficiency
    estimate does not satisfy a requirement -- otherwise every candidate who
    lists "Kubernetes" becomes a Kubernetes engineer, and the whole index
    becomes a keyword-density metric.
    """
    evidence = skill_index.get(requirement.skill_id)
    if evidence is None:
        return False, 0.0, None

    threshold = max(cfg.min_proficiency, requirement.required_proficiency)
    if evidence.proficiency < threshold:
        return (
            False,
            0.0,
            f"{requirement.canonical_name} present but below the role's "
            f"{threshold:.0%} proficiency bar ({evidence.proficiency:.0%} evidenced)",
        )

    if not cfg.partial_credit_enabled:
        # SRS-literal path: a match is a match.
        return True, 1.0, f"{requirement.canonical_name} evidenced at {evidence.proficiency:.0%}"

    # Optional refinement: credit scales from min_proficiency -> full_proficiency.
    span = max(cfg.full_proficiency - cfg.min_proficiency, 1e-6)
    credit = clamp((evidence.proficiency - cfg.min_proficiency) / span, 0.0, 1.0)
    credit = max(credit, 0.35)  # a matched skill is never worth near-zero credit
    return True, credit, f"{requirement.canonical_name} evidenced at {evidence.proficiency:.0%}"


def skill_fit(
    candidate: CandidateProfile,
    role: RoleProfile,
    config: CareerMatchConfig,
) -> ComponentScore:
    """Compute fsk = min(1, (|SC ∩ SR| + 0.5*|SC ∩ SP|) / |SR|).

    SC = candidate skills, SR = required role skills, SP = preferred role skills.
    For a role with no required skills the term is NOT_ASSESSED rather than
    0/0 -- we cannot judge skill fit against an empty specification.
    """
    cfg = config.skill
    weights = config.weights
    skill_index = candidate.skill_index()

    required = role.required_skills()
    preferred = role.preferred_skills()

    if not required:
        return ComponentScore(
            key="skill",
            label="Skill fit",
            weight=weights.skill,
            status=ComponentStatus.NOT_ASSESSED,
            value=None,
            confidence=0.0,
            rationale=(
                "This role does not specify required skills, so skill fit cannot be "
                "judged. We show no score rather than a misleading 0%."
            ),
            missing_evidence=("A role definition with at least one required skill",),
        )

    matched_required = 0.0
    matched_preferred = 0.0
    evidence: list[str] = []
    missing: list[str] = []

    for requirement in required:
        matched, credit, note = _matched_requirement(requirement, skill_index, cfg)
        if matched:
            matched_required += credit
            if note:
                evidence.append(f"✓ {note}")
        else:
            missing.append(requirement.canonical_name)

    for requirement in preferred:
        matched, credit, note = _matched_requirement(requirement, skill_index, cfg)
        if matched:
            matched_preferred += credit
            if note:
                evidence.append(f"✓ {note} (preferred)")

    raw = (matched_required + cfg.preferred_credit * matched_preferred) / len(required)
    value = clamp(raw)

    required_count = len(required)
    matched_count = sum(
        1
        for r in required
        if _matched_requirement(r, skill_index, cfg)[0]
    )

    rationale_parts = [
        f"{matched_count} of {required_count} required skills evidenced at or above the role's bar."
    ]
    if preferred:
        matched_pref_count = sum(
            1 for r in preferred if _matched_requirement(r, skill_index, cfg)[0]
        )
        rationale_parts.append(
            f"{matched_pref_count} of {len(preferred)} preferred skills present "
            f"(each worth {cfg.preferred_credit:.0%} of a required skill)."
        )
    if missing:
        rationale_parts.append("Required skills not evidenced: " + ", ".join(missing) + ".")
    if raw >= 1.0 and required_count:
        rationale_parts.append("Skill fit is capped at 100% by design.")

    # Confidence blends two signals, and both are necessary:
    #
    #   count_factor  -- how many skills we have to reason about relative to
    #                    what the role asks for (breadth of evidence)
    #   mean_evidence -- how strongly each of those skills is actually
    #                    evidenced (depth of evidence)
    #
    # Counting alone is not enough. A resume that lists thirty skills with no
    # supporting detail would otherwise score maximum confidence on the basis
    # of keyword volume -- which is exactly the failure mode this platform
    # exists to avoid.
    count_factor = min(1.0, len(skill_index) / max(required_count, 1))
    mean_evidence_confidence = (
        sum(item.confidence for item in skill_index.values()) / len(skill_index)
        if skill_index
        else 0.0
    )
    confidence = clamp(0.25 + 0.45 * count_factor + 0.30 * mean_evidence_confidence)

    return ComponentScore(
        key="skill",
        label="Skill fit",
        weight=weights.skill,
        status=ComponentStatus.ASSESSED,
        value=value,
        confidence=confidence,
        rationale=" ".join(rationale_parts),
        evidence=tuple(evidence),
        missing_evidence=tuple(missing),
    )


# ---------------------------------------------------------------------------
# fex -- experience fit
# ---------------------------------------------------------------------------


def experience_fit(
    candidate: CandidateProfile,
    role: RoleProfile,
    config: CareerMatchConfig,
) -> ComponentScore:
    """Band-based experience fit.

    Rationale for bands rather than a ratio: a linear
    ``candidate_years / required_years`` punishes a 2-year candidate applying
    for a 3-year role at 67%, and simultaneously *rewards over-qualification*
    past 100%, which is not what "fit" means. Bands model what recruiters
    actually do: there is a band of acceptable experience, and falling short of
    it degrades gradually with a floor.
    """
    cfg: ExperienceFitConfig = config.experience
    weights = config.weights

    candidate_years = candidate.effective_years_experience()
    required_min = role.min_years_experience
    required_max = role.max_years_experience

    if candidate_years is None:
        return ComponentScore(
            key="experience",
            label="Experience fit",
            weight=weights.experience,
            status=ComponentStatus.NOT_ASSESSED,
            value=None,
            confidence=0.0,
            rationale=(
                "We could not determine your years of experience from the resume, so "
                "this term is left unassessed instead of being scored as zero."
            ),
            missing_evidence=(
                "A dated work history or an explicit total-years figure",
                "Start and end dates on each role (month and year)",
            ),
        )

    if required_min is None and required_max is None:
        return ComponentScore(
            key="experience",
            label="Experience fit",
            weight=weights.experience,
            status=ComponentStatus.NOT_ASSESSED,
            value=None,
            confidence=0.0,
            rationale="This role does not state an experience requirement, so there is nothing to fit against.",
            missing_evidence=("An experience requirement on the job posting",),
        )

    low = (required_min or 0.0) - cfg.tolerance_years
    high = (required_max if required_max is not None else float("inf"))
    if required_max is not None:
        high += cfg.tolerance_years
    else:
        high = float("inf")

    evidence = [f"Detected {candidate_years:g} years of experience from dated work history."]

    if low <= candidate_years <= high:
        value = 1.0
        rationale = (
            f"Your {candidate_years:g} years sits inside the role's acceptable band "
            f"({low:g}-{'∞' if high == float('inf') else f'{high:g}'} years including tolerance)."
        )
    elif candidate_years < low:
        shortfall = low - candidate_years
        if cfg.max_shortfall_years <= 0:
            value = cfg.shortfall_floor
        else:
            decay = clamp(shortfall / cfg.max_shortfall_years, 0.0, 1.0)
            value = clamp(1.0 - decay * (1.0 - cfg.shortfall_floor), cfg.shortfall_floor, 1.0)
        rationale = (
            f"Your {candidate_years:g} years is {shortfall:g} years below the role's band "
            f"(starts at {low:g}). Fit decreases gradually and floors at "
            f"{cfg.shortfall_floor:.0%} -- a shortfall is a stretch, not a disqualification, "
            "and projects or strong interview evidence can offset it."
        )
        evidence.append(f"Shortfall of {shortfall:g} years against a {required_min:g}-year expectation.")
    else:
        # Over-qualified. Experience fit saturates at 1.0 by default: having
        # more experience than a role asks for is not a deficiency we will
        # deduct for. When an operator explicitly enables the penalty it is
        # applied at the configured floor, never as a hard zero.
        value = cfg.overshoot_floor if cfg.overqualification_penalty_enabled else 1.0
        rationale = (
            f"Your {candidate_years:g} years exceeds the role's band "
            f"({required_min:g}-{required_max if required_max is not None else '∞'} years). "
            + (
                "Experience fit is capped at 100% rather than increased further; "
                "this is not a penalty you need to fix, though the role may be pitched "
                "below your level."
                if not cfg.overqualification_penalty_enabled
                else "This configuration applies a reduced fit for over-qualification."
            )
        )
        # Only meaningful when the band has a real upper bound; an open-ended
        # requirement ("3+ years") cannot be exceeded.
        if required_max is not None:
            overshoot = candidate_years - required_max
            if overshoot > 0:
                evidence.append(f"{overshoot:g} years beyond the stated upper bound of {required_max:g}.")
        value = clamp(value, 0.0, 1.0)

    confidence = 0.8 if candidate.total_years_experience is None else 0.95

    return ComponentScore(
        key="experience",
        label="Experience fit",
        weight=weights.experience,
        status=ComponentStatus.ASSESSED,
        value=value,
        confidence=confidence,
        rationale=rationale,
        evidence=tuple(evidence),
    )


# ---------------------------------------------------------------------------
# fed -- education fit
# ---------------------------------------------------------------------------


def education_fit(
    candidate: CandidateProfile,
    role: RoleProfile,
    config: CareerMatchConfig,
) -> ComponentScore:
    """Ordinal education fit.

    Steps of shortfall map to fixed credits. A candidate one level below the
    requirement keeps 60% of this term; two or more levels below keeps 30%.
    The term is worth 10% of the index by default, so failing it entirely costs
    a candidate at most 10 points -- which is the intended proportionality for
    a signal that correlates weakly with job performance.
    """
    cfg: EducationFitConfig = config.education
    weights = config.weights

    if role.education_level is EducationLevel.UNKNOWN:
        return ComponentScore(
            key="education",
            label="Education fit",
            weight=weights.education,
            status=ComponentStatus.ASSESSED,
            value=cfg.unspecified_credit,
            confidence=0.6,
            rationale=(
                "This role does not specify an education requirement, so education "
                "neither helps nor hurts your match."
            ),
        )

    candidate_level = max((e.level for e in candidate.educations), default=EducationLevel.UNKNOWN)

    if candidate_level is EducationLevel.UNKNOWN:
        return ComponentScore(
            key="education",
            label="Education fit",
            weight=weights.education,
            status=ComponentStatus.NOT_ASSESSED,
            value=None,
            confidence=0.0,
            rationale=(
                "No education section could be read from your resume, so we have no "
                "evidence either way. This term is excluded and the remaining weights "
                "are renormalised -- it is not counted as a zero."
            ),
            missing_evidence=(
                "An Education section with degree name and completion year",
                "Or an explicit statement that you are self-taught / bootcamp-trained",
            ),
        )

    gap = int(role.education_level) - int(candidate_level)

    if gap <= 0:
        value = cfg.meet_credit
        rationale = (
            f"Your {candidate_level.name.title()} qualification meets the role's "
            f"{role.education_level.name.title()} expectation."
        )
    elif gap == 1:
        value = cfg.one_step_below_credit
        rationale = (
            f"The role prefers {role.education_level.name.title()} and you hold a "
            f"{candidate_level.name.title()} -- one level below. Practical experience, "
            "certifications and interview performance routinely close this gap, so you "
            f"retain {cfg.one_step_below_credit:.0%} of this term."
        )
    else:
        value = cfg.two_steps_below_credit
        rationale = (
            f"The role prefers {role.education_level.name.title()} and your highest "
            f"qualification is {candidate_level.name.title()} ({gap} levels below). "
            "This is usually a screening rather than a capability signal."
        )

    best = max(candidate.educations, key=lambda e: e.level, default=None)
    evidence = []
    if best is not None:
        label = best.degree_name or best.level.name.title()
        where = f" at {best.institution}" if best.institution else ""
        when = f" ({best.end_year})" if best.end_year else ""
        evidence.append(f"{label}{where}{when}")

    return ComponentScore(
        key="education",
        label="Education fit",
        weight=weights.education,
        status=ComponentStatus.ASSESSED,
        value=clamp(value),
        confidence=0.85,
        rationale=rationale,
        evidence=tuple(evidence),
    )


__all__ = ["education_fit", "experience_fit", "skill_fit"]
