"""Scoring configuration for the Career Match Index.

WHY THIS MODULE EXISTS
----------------------
The SRS requires that *no scoring weight is hard-coded in business logic*.
Every weight, threshold and curve parameter lives here, is versioned, and is
persisted alongside every score we emit so a score can always be replayed.

A score with no version is not auditable, and an unauditable score has no
business telling a candidate what to learn next.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Versioned configuration
# ---------------------------------------------------------------------------

CAREER_MATCH_CONFIG_VERSION = "cmi-2024.1"


@dataclass(frozen=True, slots=True)
class MatchWeights:
    """Top-level weights of the Career Match Index (SRS section 9).

    M = 100 * min(1, w_skill*fsk + w_semantic*fse + w_exp*fex + w_edu*fed)

    Invariant: the weights must sum to 1.0 for the zero-filled form of the
    index to be bounded by 100. We assert this at construction time rather
    than trusting whoever edits the config.
    """

    skill: float = 0.50
    semantic: float = 0.25
    experience: float = 0.15
    education: float = 0.10

    def __post_init__(self) -> None:
        total = self.skill + self.semantic + self.experience + self.education
        if abs(total - 1.0) > 1e-6:
            raise ValueError(
                f"MatchWeights must sum to 1.0, got {total!r}. "
                "Adjust the versioned config, never a call site."
            )

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class SkillFitConfig:
    """Parameters of the skill-fit term fsk (SRS section 9)."""

    #: Credit granted for a preferred (non-required) skill match.
    preferred_credit: float = 0.5
    #: Skills below this proficiency are not counted as matched evidence.
    min_proficiency: float = 0.25
    #: Proficiency at or above which a skill counts as fully demonstrated.
    full_proficiency: float = 0.70
    #: Proficiency-weighted credit, scaled between min_proficiency (partial)
    #: and full_proficiency (full).
    #:
    #: DEFAULT IS False ON PURPOSE. With this flag off, fsk is *exactly* the
    #: SRS section 9 formula -- a count of matched skills, nothing more:
    #:     fsk = min(1, (|SC ∩ SR| + 0.5|SC ∩ SP|) / |SR|)
    #: Turning it on credits a candidate whose "Docker" evidence is a single
    #: tutorial project less than one with production Docker evidence. That is
    #: a better signal, but it is a *deviation from the authoritative spec*,
    #: so it must be an explicit, versioned product decision -- not a default.
    partial_credit_enabled: bool = False


@dataclass(frozen=True, slots=True)
class ExperienceFitConfig:
    """Parameters of the experience-fit term fex.

    Experience fit is deliberately *banded* rather than linear. A candidate
    two years short of a 5-year requirement is a different conversation from a
    candidate ten years short, and a candidate who overshoots is not "more
    than perfect" -- the index saturates at 1.0.
    """

    #: Candidate YoE within [required_min - tolerance, required_max + tolerance] => 1.0
    tolerance_years: float = 1.0
    #: Fit decays linearly to this floor as the shortfall grows to max_shortfall.
    shortfall_floor: float = 0.20
    max_shortfall_years: float = 5.0
    #: Over-qualification handling.
    #:
    #: DEFAULT IS False, AND THAT IS A DELIBERATE PRODUCT DECISION. A candidate
    #: with 12 years applying to a 3-7 year role is not a *worse* fit on the
    #: merits; they are a different conversation. Penalising them inside a term
    #: called "experience fit" would quietly mark down strong candidates, and
    #: the SRS formula contains no over-qualification term. We therefore
    #: saturate at 1.0 and raise an explicit warning instead, so the signal
    #: reaches the candidate as context rather than as a deduction.
    overqualification_penalty_enabled: bool = False
    overshoot_floor: float = 0.75


@dataclass(frozen=True, slots=True)
class EducationFitConfig:
    """Parameters of the education-fit term fed.

    Education is ordinal, not interval: a B.Tech and an M.Tech are one step
    apart, not "two points apart". We therefore map levels to an ordinal scale
    and apply a fixed credit per step of shortfall.
    """

    #: Credit when the candidate meets or exceeds the required level.
    meet_credit: float = 1.0
    #: Credit when one level below the requirement.
    one_step_below_credit: float = 0.6
    #: Credit when two or more levels below the requirement.
    two_steps_below_credit: float = 0.3
    #: Credit when the requirement is unspecified / open.
    unspecified_credit: float = 1.0


@dataclass(frozen=True, slots=True)
class EvidenceConfig:
    """How we treat *missing* information.

    SRS section 9: "Missing resume sections must NOT automatically become zero."
    A missing section means we have no evidence -- not that the candidate
    failed. We therefore mark the component NOT_ASSESSED, exclude it from the
    weighted average, renormalise the remaining weights, and report an
    evidence-coverage figure so the candidate can see what is unknown.
    """

    #: Minimum confidence in a signal before we are willing to assess on it.
    min_assessable_confidence: float = 0.35
    #: Minimum confidence-weighted evidence coverage before the index is
    #: displayed as a headline number. Coverage is computed as
    #: Σ(w_i · confidence_i) / Σ(w_i), so thin evidence lowers coverage even
    #: when every term technically produced a value.
    min_reportable_coverage: float = 0.60


@dataclass(frozen=True, slots=True)
class CareerMatchConfig:
    """Complete, immutable, versioned scoring configuration."""

    version: str = CAREER_MATCH_CONFIG_VERSION
    weights: MatchWeights = field(default_factory=MatchWeights)
    skill: SkillFitConfig = field(default_factory=SkillFitConfig)
    experience: ExperienceFitConfig = field(default_factory=ExperienceFitConfig)
    education: EducationFitConfig = field(default_factory=EducationFitConfig)
    evidence: EvidenceConfig = field(default_factory=EvidenceConfig)

    def as_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "weights": self.weights.as_dict(),
            "skill": asdict(self.skill),
            "experience": asdict(self.experience),
            "education": asdict(self.education),
            "evidence": asdict(self.evidence),
        }


#: The configuration used when a caller does not pin an explicit version.
#: Real call sites should resolve the active version from the database so that
#: historical scores keep replaying against the config that produced them.
DEFAULT_CAREER_MATCH_CONFIG = CareerMatchConfig()
