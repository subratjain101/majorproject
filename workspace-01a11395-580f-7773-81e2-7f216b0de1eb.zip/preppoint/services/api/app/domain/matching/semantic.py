"""Semantic similarity between a candidate's evidence and a role description.

The SRS lists fse as the second-heaviest term (0.25). Two design rules govern
this module:

1. **Embeddings are a provider, not a dependency.** ``EmbeddingProvider`` is a
   protocol. A hosted embedding model, a self-hosted sentence-transformer and
   the offline lexical fallback below are all valid implementations. The
   matcher never imports a vendor SDK.

2. **The offline fallback must be honest.** If we cannot compute embeddings we
   say so by lowering confidence and grading the result as lexical overlap --
   we do not silently present token overlap as semantic understanding.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from typing import Protocol, Sequence, runtime_checkable

# ---------------------------------------------------------------------------
# Tokenisation
# ---------------------------------------------------------------------------

_TOKEN_RE = re.compile(r"[a-z0-9][a-z0-9+#.\-]*")

_STOPWORDS = frozenset(
    """
    a an the and or but if then than that this these those of in on at to for with
    from by as is are was were be been being am do does did doing have has had
    having will would shall should can could may might must not no nor so such
    we you they he she it i our your their its about into over under again more
    most other some any each few both own same too very s t just don now
    """.split()
)

#: Terms that appear in almost every posting and therefore carry no signal.
_BOILERPLATE = frozenset(
    """
    job role position candidate candidates applicant applicants company team teams
    work working experience experienced years year required requirement requirements
    responsibilities responsibility skills skill ability able strong good excellent
    plus preferred nice must should will you your we our looking join opportunity
    """.split()
)


def tokenize(text: str) -> list[str]:
    """Lowercase token stream with stopwords removed.

    Keeps ``c++``, ``c#`` and ``node.js`` intact -- naive whitespace splitting
    destroys exactly the tokens that matter most in a technical resume.
    """
    tokens = _TOKEN_RE.findall(text.casefold().replace("/", " "))
    return [t for t in tokens if t not in _STOPWORDS and not t.isdigit()]


# ---------------------------------------------------------------------------
# Provider protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class EmbeddingProvider(Protocol):
    """Anything that can turn text into a fixed-length vector."""

    name: str

    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        """Embed a batch of texts. Must preserve input order and length."""
        ...


# ---------------------------------------------------------------------------
# Offline fallback: TF-IDF cosine, pure standard library
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class LexicalSimilarity:
    """Result of a lexical comparison, plus how much to trust it."""

    score: float
    #: The shared terms that produced the score -- shown to the candidate.
    shared_terms: tuple[str, ...]
    #: Lexical overlap is a weaker signal than true semantic similarity.
    confidence: float
    method: str
    #: Salient terms the role emphasises that the candidate never mentions.
    #: Surfaced on the scorecard as "concepts this role stresses that your
    #: resume does not address" -- often the single most actionable output.
    missing_terms: tuple[str, ...] = ()


def role_coverage(
    candidate_text: str,
    role_text: str,
    *,
    top_terms: int = 12,
) -> tuple[float, tuple[str, ...], tuple[str, ...]]:
    """Asymmetric IDF-weighted coverage of the role's terms by the candidate.

    WHY THIS EXISTS ALONGSIDE COSINE
    --------------------------------
    Cosine similarity is symmetric and length-normalised, which makes it the
    wrong instrument for "does this resume reflect what the job asks for". A
    40-word candidate document compared against a 400-word job description can
    share every concept the role names and still score ~0.4, because cosine
    penalises the *difference in surface area*. That bias is not random: it
    drags every candidate down by roughly the same amount, which compresses the
    term's discriminative range and makes the 25% weight nearly decorative.

    Coverage asks the asymmetric question directly: of the concepts the role
    emphasises (IDF-weighted so that "distributed" counts for more than
    "team"), how many appear in the candidate's evidence?

    Returns (covered_fraction, matched_terms, notable_missing_terms).
    """
    candidate_tokens = {t for t in tokenize(candidate_text) if t not in _BOILERPLATE}
    role_tokens = [t for t in tokenize(role_text) if t not in _BOILERPLATE]

    if not role_tokens or not candidate_tokens:
        return 0.0, (), ()

    role_counts = Counter(role_tokens)

    # IDF within the role document: terms appearing in most of the role text
    # are generic filler for *this* role and should not dominate coverage.
    total_role_terms = sum(role_counts.values())
    matched: list[tuple[str, float]] = []
    missing: list[tuple[str, float]] = []
    covered_weight = 0.0
    total_weight = 0.0

    for term, count in role_counts.items():
        specificity = 1.0 - (count / total_role_terms)  # 0 for ubiquitous, ~1 for rare
        term_weight = count * (0.35 + 0.65 * specificity)
        total_weight += term_weight
        if term in candidate_tokens:
            covered_weight += term_weight
            matched.append((term, term_weight))
        else:
            missing.append((term, term_weight))

    if total_weight == 0:
        return 0.0, (), ()

    matched.sort(key=lambda kv: (-kv[1], kv[0]))
    missing.sort(key=lambda kv: (-kv[1], kv[0]))

    return (
        covered_weight / total_weight,
        tuple(t for t, _ in matched[:top_terms]),
        # Only surface genuinely salient omissions: a term the role mentions
        # once in passing is not a gap worth naming.
        tuple(t for t, w in missing if w >= 0.8)[:top_terms],
    )


def blended_lexical_similarity(
    candidate_text: str,
    role_text: str,
    *,
    coverage_weight: float = 0.6,
    top_terms: int = 12,
) -> LexicalSimilarity:
    """Cosine blended with asymmetric coverage.

    The blend is weighted toward coverage because coverage is the question we
    actually want answered. Cosine is retained because it captures overall
    topical proximity that coverage cannot: a candidate covering 70% of the
    role's vocabulary but in a completely unrelated domain should not score
    the same as one whose whole document is about that domain.
    """
    cosine = tfidf_cosine(candidate_text, role_text, top_terms=top_terms)
    covered, matched, missing = role_coverage(candidate_text, role_text, top_terms=top_terms)

    if cosine.shared_terms == () and not matched:
        return cosine

    blended = max(0.0, min(1.0, coverage_weight * covered + (1 - coverage_weight) * cosine.score))

    # Report the union, preferring terms that drove coverage, then list what
    # the role emphasises but the candidate never mentions.
    combined: list[str] = list(matched)
    for term in cosine.shared_terms:
        if term not in combined:
            combined.append(term)

    return LexicalSimilarity(
        score=blended,
        shared_terms=tuple(combined[:top_terms]),
        confidence=cosine.confidence,
        method=f"blended(cosine+coverage):{covered:.2f} covered",
        missing_terms=missing,
    )


def tfidf_cosine(text_a: str, text_b: str, *, top_terms: int = 12) -> LexicalSimilarity:
    """Cosine similarity over TF-IDF-weighted token counts.

    No external dependencies by design: this runs inside the worker, inside
    tests, and inside air-gapped deployments without pulling a model.
    """
    tokens_a = [t for t in tokenize(text_a) if t not in _BOILERPLATE]
    tokens_b = [t for t in tokenize(text_b) if t not in _BOILERPLATE]

    if not tokens_a or not tokens_b:
        return LexicalSimilarity(score=0.0, shared_terms=(), confidence=0.2, method="tfidf")

    counts_a = Counter(tokens_a)
    counts_b = Counter(tokens_b)
    vocabulary = set(counts_a) | set(counts_b)

    # IDF over a two-document corpus. Terms in both documents get weight ~0.41,
    # terms in one get ~0.69 -- enough to stop generic filler from dominating.
    idf = {
        term: math.log((2 + 1) / (1 + int(term in counts_a) + int(term in counts_b)) ) + 1
        for term in vocabulary
    }

    def vectorize(counts: Counter[str]) -> dict[str, float]:
        total = sum(counts.values()) or 1
        return {
            term: (count / total) * idf.get(term, 1.0)
            for term, count in counts.items()
        }

    vec_a = vectorize(counts_a)
    vec_b = vectorize(counts_b)

    dot = sum(vec_a.get(term, 0.0) * vec_b.get(term, 0.0) for term in vocabulary)
    norm_a = math.sqrt(sum(v * v for v in vec_a.values()))
    norm_b = math.sqrt(sum(v * v for v in vec_b.values()))

    if norm_a == 0 or norm_b == 0:
        return LexicalSimilarity(score=0.0, shared_terms=(), confidence=0.2, method="tfidf")

    score = dot / (norm_a * norm_b)

    # Weight shared terms by their contribution so the explanation lists what
    # actually drove the number, not just what happened to appear twice.
    contributions = {
        term: vec_a.get(term, 0.0) * vec_b.get(term, 0.0)
        for term in (set(counts_a) & set(counts_b))
    }
    ranked = sorted(contributions.items(), key=lambda kv: (-kv[1], kv[0]))
    shared = tuple(term for term, _ in ranked[:top_terms])

    return LexicalSimilarity(
        score=max(0.0, min(1.0, score)),
        shared_terms=shared,
        # Lexical overlap underestimates true semantic similarity (synonyms
        # score 0), so we report reduced confidence rather than an inflated score.
        confidence=0.62,
        method="tfidf",
    )


# ---------------------------------------------------------------------------
# Provider-backed similarity with graceful degradation
# ---------------------------------------------------------------------------


def embedding_cosine(vec_a: Sequence[float], vec_b: Sequence[float]) -> float:
    """Cosine similarity mapped from [-1, 1] to [0, 1].

    Mapping matters: raw cosine on typical embedding spaces sits in ~[0.3, 0.9],
    and feeding that straight into the index would make the semantic term
    systematically drag the headline down. The affine map preserves ordering
    while using the full range the weight expects.
    """
    if not vec_a or not vec_b or len(vec_a) != len(vec_b):
        return 0.0
    dot = sum(a * b for a, b in zip(vec_a, vec_b))
    norm_a = math.sqrt(sum(a * a for a in vec_a))
    norm_b = math.sqrt(sum(b * b for b in vec_b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    cosine = dot / (norm_a * norm_b)
    return max(0.0, min(1.0, (cosine + 1.0) / 2.0))


def semantic_similarity(
    candidate_text: str,
    role_text: str,
    *,
    provider: EmbeddingProvider | None = None,
) -> LexicalSimilarity:
    """Compute semantic similarity, preferring a real embedder when available.

    Falls back to the blended lexical measure on any provider failure. A failed
    embedding call must not fail the candidate's match calculation -- degraded
    and labelled beats absent.
    """
    if provider is not None:
        try:
            vectors = provider.embed([candidate_text, role_text])
            if len(vectors) == 2:
                score = embedding_cosine(vectors[0], vectors[1])
                _, matched, missing = role_coverage(candidate_text, role_text)
                return LexicalSimilarity(
                    score=score,
                    shared_terms=matched,
                    confidence=0.9,
                    method=f"embedding:{provider.name}",
                    missing_terms=missing,
                )
        except Exception:  # noqa: BLE001 - deliberate: any provider error degrades
            pass

    return blended_lexical_similarity(candidate_text, role_text)


__all__ = [
    "EmbeddingProvider",
    "LexicalSimilarity",
    "blended_lexical_similarity",
    "embedding_cosine",
    "role_coverage",
    "semantic_similarity",
    "tfidf_cosine",
    "tokenize",
]
