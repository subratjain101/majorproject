"""Domain value objects for career matching and skill gap analysis.

These types are deliberately framework-free: no SQLAlchemy, no Pydantic, no
FastAPI. The scoring engine must be unit-testable without a database, a web
server or a network connection, and it must be reusable by the worker service
and the sandbox runner without dragging the web stack along.

Persistence-layer models are mapped *to* these types at the repository
boundary. Nothing here knows what a database is.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import IntEnum, StrEnum
from typing import Iterable, Mapping, Sequence


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------


class SkillRequirementKind(StrEnum):
    """How central a skill is to a role."""

    REQUIRED = "required"
    PREFERRED = "preferred"
    NICE_TO_HAVE = "nice_to_have"


class ComponentStatus(StrEnum):
    """Assessment status of one component of the Career Match Index.

    NOT_ASSESSED is a first-class outcome, not an error. It is how PrepPoint
    says "we do not know" instead of inventing a zero.
    """

    ASSESSED = "assessed"
    NOT_ASSESSED = "not_assessed"


class EvidenceSource(StrEnum):
    """Where a piece of skill evidence came from.

    The source matters: resume evidence is a claim, interview evidence is a
    demonstration under time pressure, and DSA evidence is a verified artefact.
    They are not equally strong, and the engine says so.
    """

    RESUME = "resume"
    PROJECT = "project"
    WORK_HISTORY = "work_history"
    CERTIFICATION = "certification"
    INTERVIEW = "interview"
    DSA_SUBMISSION = "dsa_submission"
    APTITUDE = "aptitude"
    SELF_REPORTED = "self_reported"


class EducationLevel(IntEnum):
    """Ordinal education scale.

    Ordinal, not interval -- see EducationFitConfig for why that distinction is
    load-bearing in the fitness function.
    """

    UNKNOWN = 0
    SECONDARY = 1
    HIGHER_SECONDARY = 2
    DIPLOMA = 3
    BACHELORS = 4
    MASTERS = 5
    DOCTORATE = 6

    @classmethod
    def from_label(cls, label: str | None) -> "EducationLevel":
        """Best-effort parse of free-text degree labels.

        Resume text is uncontrolled. We normalise conservatively and fall back
        to UNKNOWN rather than guessing upward -- guessing upward flatters the
        candidate and corrupts the education-fit term.
        """
        if not label:
            return cls.UNKNOWN
        text = label.casefold()
        # Order matters: check the most specific tokens first.
        if any(t in text for t in ("phd", "ph.d", "doctorate", "doctoral")):
            return cls.DOCTORATE
        if any(t in text for t in ("m.tech", "mtech", "m.e", "m.sc", "msc", "mba", "mca", "master", "m.s.", "m.a.")):
            return cls.MASTERS
        if any(t in text for t in ("b.tech", "btech", "b.e", "b.sc", "bsc", "bca", "bachelor", "b.s.", "b.a.", "b.com")):
            return cls.BACHELORS
        if any(t in text for t in ("diploma", "polytechnic")):
            return cls.DIPLOMA
        if any(t in text for t in ("higher secondary", "senior secondary", "12th", "intermediate")):
            return cls.HIGHER_SECONDARY
        if any(t in text for t in ("secondary", "10th", "matriculation")):
            return cls.SECONDARY
        return cls.UNKNOWN


# ---------------------------------------------------------------------------
# Candidate-side value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SkillEvidence:
    """One skill the candidate has, with the evidence behind it.

    ``proficiency`` is our confidence that the candidate can *use* the skill,
    in [0, 1]. ``confidence`` is our confidence in that estimate, in [0, 1].
    A skill asserted only by a keyword in a resume skills list and a skill
    demonstrated by three shipped projects should not score identically, and
    they do not: they differ in both fields.
    """

    skill_id: str
    proficiency: float
    confidence: float = 1.0
    source: EvidenceSource = EvidenceSource.RESUME
    #: Human-readable pointers to *where* this came from, e.g.
    #: "Experience: Backend Engineer, Acme (2022-2024): 'Built Docker CI pipeline'".
    evidence: tuple[str, ...] = ()
    years_used: float | None = None

    def __post_init__(self) -> None:
        _check_unit_interval(self.proficiency, "proficiency")
        _check_unit_interval(self.confidence, "confidence")


@dataclass(frozen=True, slots=True)
class EducationRecord:
    level: EducationLevel
    degree_name: str | None = None
    institution: str | None = None
    field_of_study: str | None = None
    start_year: int | None = None
    end_year: int | None = None
    grade: str | None = None


def ensure_utc(value: datetime) -> datetime:
    """Coerce a datetime to timezone-aware UTC.

    Dates parsed out of resumes are almost always naive ("July 2023"), while
    anything we generate is aware. Subtracting one from the other raises
    ``TypeError``, which is precisely the bug that reaches production because
    the happy-path fixture happened to be consistent.

    Rather than sprinkling try/excepts at call sites, every datetime that
    enters a duration calculation goes through here. Naive values are assumed
    UTC -- resumes carry no timezone, and assuming UTC is the only choice that
    keeps arithmetic in whole days stable.
    """
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True)
class ExperienceRecord:
    title: str
    company: str | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    is_current: bool = False
    description: str = ""
    skill_ids: tuple[str, ...] = ()

    def duration_months(self, *, now: datetime | None = None) -> float:
        """Duration in months, treating an open end date as 'until now'."""
        if self.start_date is None:
            return 0.0
        end = ensure_utc(self.end_date or (now or datetime.now(timezone.utc)))
        start = ensure_utc(self.start_date)
        months = (end.year - start.year) * 12 + (end.month - start.month)
        return float(max(0, months))


@dataclass(frozen=True, slots=True)
class CandidateProfile:
    """The candidate side of the match equation.

    ``evidence_coverage_hint`` lets the resume pipeline tell the matcher how
    much of the document we actually managed to parse -- a resume that yielded
    no education section should weaken, not zero, the education term.
    """

    skills: tuple[SkillEvidence, ...] = ()
    educations: tuple[EducationRecord, ...] = ()
    experiences: tuple[ExperienceRecord, ...] = ()
    summary_text: str = ""
    total_years_experience: float | None = None
    #: Section name -> parse confidence in [0, 1], produced by the resume pipeline.
    section_confidence: Mapping[str, float] = field(default_factory=dict)

    def skill_index(self) -> dict[str, SkillEvidence]:
        """Highest-confidence evidence per skill, merged across sources.

        When several rows describe the same skill we take the strongest
        proficiency rather than summing, so duplication (a skill listed in both
        Skills and Experience) cannot inflate a score.
        """
        best: dict[str, SkillEvidence] = {}
        for item in self.skills:
            current = best.get(item.skill_id)
            if current is None or (item.proficiency, item.confidence) > (current.proficiency, current.confidence):
                best[item.skill_id] = item
        return best

    def effective_years_experience(self, *, now: datetime | None = None) -> float | None:
        """Total experience, preferring the explicit value when present."""
        if self.total_years_experience is not None:
            return self.total_years_experience
        if not self.experiences:
            return None
        # Merge overlapping roles rather than summing, so parallel part-time
        # work does not double-count into five "years" of experience.
        reference = ensure_utc(now or datetime.now(timezone.utc))
        intervals = [
            (ensure_utc(r.start_date), ensure_utc(r.end_date) if r.end_date else reference)
            for r in self.experiences
            if r.start_date is not None
        ]
        if not intervals:
            return None
        intervals.sort(key=lambda pair: pair[0])
        merged: list[list[datetime]] = []
        for start, end in intervals:
            if merged and start <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], end)
            else:
                merged.append([start, end])
        total_days = sum((end - start).days for start, end in merged)
        return round(total_days / 365.25, 2)


# ---------------------------------------------------------------------------
# Role-side value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class RoleSkillRequirement:
    """One skill a target role asks for, with everything the gap engine needs."""

    skill_id: str
    canonical_name: str
    kind: SkillRequirementKind = SkillRequirementKind.REQUIRED
    #: Relative importance within the role, in [0, 1]. Drives gap severity.
    importance: float = 1.0
    #: Proficiency the role assumes; a candidate below this is not yet "matched".
    required_proficiency: float = 0.5
    #: Baseline hours of focused study a typical learner needs from zero.
    prep_hours_from_zero: float = 8.0
    category: str | None = None
    #: Skill ids that should be learned first. Powers roadmap ordering.
    prerequisites: tuple[str, ...] = ()
    #: Whether interviewers commonly probe this skill, and thus whether
    #: practicing it has interview leverage beyond the resume.
    interview_relevant: bool = True

    def __post_init__(self) -> None:
        _check_unit_interval(self.importance, "importance")
        _check_unit_interval(self.required_proficiency, "required_proficiency")


@dataclass(frozen=True, slots=True)
class RoleProfile:
    """A job or a target role, normalised into the shape the matcher expects."""

    role_id: str
    title: str
    requirements: tuple[RoleSkillRequirement, ...] = ()
    min_years_experience: float | None = None
    max_years_experience: float | None = None
    education_level: EducationLevel = EducationLevel.UNKNOWN
    seniority: str | None = None
    description: str = ""
    company: str | None = None
    location: str | None = None

    def required_skills(self) -> tuple[RoleSkillRequirement, ...]:
        return tuple(r for r in self.requirements if r.kind is SkillRequirementKind.REQUIRED)

    def preferred_skills(self) -> tuple[RoleSkillRequirement, ...]:
        return tuple(r for r in self.requirements if r.kind is SkillRequirementKind.PREFERRED)

    def nice_to_have_skills(self) -> tuple[RoleSkillRequirement, ...]:
        return tuple(r for r in self.requirements if r.kind is SkillRequirementKind.NICE_TO_HAVE)


# ---------------------------------------------------------------------------
# Result value objects
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ComponentScore:
    """One assessed (or explicitly not-assessed) term of the index.

    This object *is* the product differentiator. It is the reason a candidate
    can answer "why 74?" without reading our source code.
    """

    key: str
    label: str
    weight: float
    status: ComponentStatus
    #: Normalised fit in [0, 1] when assessed, else None. Never 0 for unknown.
    value: float | None
    confidence: float
    rationale: str
    evidence: tuple[str, ...] = ()
    missing_evidence: tuple[str, ...] = ()

    @property
    def contribution(self) -> float:
        """Weighted contribution in index points, or 0 when not assessed."""
        if self.status is not ComponentStatus.ASSESSED or self.value is None:
            return 0.0
        return self.weight * self.value

    @property
    def is_assessed(self) -> bool:
        return self.status is ComponentStatus.ASSESSED


@dataclass(frozen=True, slots=True)
class MatchResult:
    """The full, explainable output of the Career Match Index."""

    role_id: str
    #: Headline index: weights renormalised over assessed components only.
    index: float
    #: Spec-literal index (M = 100*min(1, Σ w_i f_i)) with unassessed terms as 0.
    #: Kept for audit and comparison; NOT shown as the headline, because a
    #: resume with no parseable education section should not lose 10 points.
    index_zero_filled: float
    #: Fraction of total weight we were able to assess, in [0, 1].
    evidence_coverage: float
    #: True when coverage is high enough for the index to be shown as a headline.
    is_reportable: bool
    components: tuple[ComponentScore, ...]
    config_version: str
    computed_at: datetime
    #: Plain-language explanation assembled from the components.
    explanation: str
    warnings: tuple[str, ...] = ()

    def component(self, key: str) -> ComponentScore:
        for item in self.components:
            if item.key == key:
                return item
        raise KeyError(key)

    @property
    def unassessed(self) -> tuple[ComponentScore, ...]:
        return tuple(c for c in self.components if not c.is_assessed)

    @property
    def display_index(self) -> float | None:
        """The index as it may be shown to a candidate, or None.

        This exists so the "do not publish an indefensible number" rule is
        enforced *by the type system* rather than by every caller remembering
        to check ``is_reportable``. Any UI or API path that renders a headline
        score must go through this property; ``index`` remains available for
        ranking, admin views and auditing, where an unrounded internal value is
        what is actually wanted.
        """
        return self.index if self.is_reportable else None

    @property
    def is_assessable(self) -> bool:
        """Whether any rubric term at all could be measured."""
        return any(c.is_assessed for c in self.components)

    def to_dict(self) -> dict[str, object]:
        return {
            "role_id": self.role_id,
            # None when coverage is too low to defend. Clients render the
            # "not enough evidence yet" state from this being null, which makes
            # it impossible to leak an unreliable score by forgetting a flag.
            "display_index": self.display_index,
            "index": round(self.index, 1),
            "index_zero_filled": round(self.index_zero_filled, 1),
            "evidence_coverage": round(self.evidence_coverage, 3),
            "is_reportable": self.is_reportable,
            "config_version": self.config_version,
            "computed_at": self.computed_at.isoformat(),
            "explanation": self.explanation,
            "warnings": list(self.warnings),
            "components": [
                {
                    "key": c.key,
                    "label": c.label,
                    "weight": c.weight,
                    "status": c.status.value,
                    "value": None if c.value is None else round(c.value, 4),
                    "percent": None if c.value is None else round(c.value * 100, 1),
                    "confidence": round(c.confidence, 3),
                    "rationale": c.rationale,
                    "evidence": list(c.evidence),
                    "missing_evidence": list(c.missing_evidence),
                }
                for c in self.components
            ],
        }


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _check_unit_interval(value: float, name: str) -> None:
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"{name} must be within [0, 1], got {value!r}")


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    """Clamp to an interval. Used by every fitness term."""
    return max(low, min(high, value))


def round_half_up(value: float, digits: int = 1) -> float:
    """Deterministic rounding for display, so scores never flicker between runs."""
    factor = 10**digits
    return float(int(value * factor + 0.5)) / factor


def safe_ratio(numerator: float, denominator: float, *, default: float | None = None) -> float | None:
    """Division that refuses to invent a value for an empty denominator."""
    if denominator == 0:
        return default
    return numerator / denominator


__all__ = [
    "CandidateProfile",
    "ComponentScore",
    "ComponentStatus",
    "EducationLevel",
    "EducationRecord",
    "EvidenceSource",
    "ExperienceRecord",
    "MatchResult",
    "RoleProfile",
    "RoleSkillRequirement",
    "SkillEvidence",
    "SkillRequirementKind",
    "clamp",
    "round_half_up",
    "safe_ratio",
]
