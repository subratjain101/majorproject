"""The Career Match Index calculator (SRS section 9).

    M = 100 * min(1, 0.50*fsk + 0.25*fse + 0.15*fex + 0.10*fed)

Two things this module does that a naive implementation does not:

1. **Renormalises over assessed components.** Unassessed terms are excluded
   from both numerator and denominator, so a missing resume section dilutes
   confidence instead of manufacturing a zero. The spec-literal zero-filled
   value is still computed and stored, for audit and for spec conformance.

2. **Reports evidence coverage.** The candidate is told how much of the index
   is actually backed by evidence, and the headline number is withheld below a
   configurable coverage floor -- because a confident-looking "94% match"
   built on one parsed skill is worse than no number at all.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Sequence

from .config import CareerMatchConfig, DEFAULT_CAREER_MATCH_CONFIG
from .fitness import education_fit, experience_fit, skill_fit
from .semantic import EmbeddingProvider, semantic_similarity
from .types import (
    CandidateProfile,
    ComponentScore,
    ComponentStatus,
    MatchResult,
    RoleProfile,
    clamp,
    round_half_up,
)


class CareerMatchCalculator:
    """Computes explainable Career Match Index results.

    Stateless and dependency-injected. Construct once per process; pass the
    active config and (optionally) an embedding provider.
    """

    def __init__(
        self,
        *,
        config: CareerMatchConfig | None = None,
        embedding_provider: EmbeddingProvider | None = None,
    ) -> None:
        self.config = config or DEFAULT_CAREER_MATCH_CONFIG
        self.embedding_provider = embedding_provider

    # -- public API --------------------------------------------------------

    def compute(
        self,
        candidate: CandidateProfile,
        role: RoleProfile,
        *,
        now: datetime | None = None,
    ) -> MatchResult:
        """Compute the full, explainable match result."""
        components: list[ComponentScore] = [
            skill_fit(candidate, role, self.config),
            self._semantic_component(candidate, role),
            experience_fit(candidate, role, self.config),
            education_fit(candidate, role, self.config),
        ]

        assessed = [c for c in components if c.is_assessed]
        total_weight = sum(c.weight for c in components)
        assessed_weight = sum(c.weight for c in assessed)

        # --- zero-filled, spec-literal value (audit trail) ---
        zero_filled = sum(
            c.weight * (c.value or 0.0) for c in components
        )
        index_zero_filled = 100.0 * min(1.0, zero_filled)

        # --- renormalised value (what the candidate sees) ---
        if assessed_weight <= 0:
            index = 0.0
        else:
            weighted = sum(c.weight * (c.value or 0.0) for c in assessed)
            normalised = weighted / assessed_weight
            index = 100.0 * clamp(normalised)

        # Coverage is CONFIDENCE-WEIGHTED, not merely weight-presence.
        # A term that produced a value from thin evidence must count for less
        # than one backed by a full work history -- otherwise a resume with a
        # single listed skill would report the same coverage as a detailed one.
        confidence_weighted = sum(c.weight * c.confidence for c in assessed)
        coverage = clamp(confidence_weighted / total_weight) if total_weight else 0.0
        reportable = coverage >= self.config.evidence.min_reportable_coverage

        warnings = self._warnings(components, coverage, reportable)
        explanation = self._explain(components, index, coverage, reportable)

        return MatchResult(
            role_id=role.role_id,
            index=round_half_up(index, 1),
            index_zero_filled=round_half_up(index_zero_filled, 1),
            evidence_coverage=coverage,
            is_reportable=reportable,
            components=tuple(components),
            config_version=self.config.version,
            computed_at=now or datetime.now(timezone.utc),
            explanation=explanation,
            warnings=tuple(warnings),
        )

    def compute_many(
        self,
        candidate: CandidateProfile,
        roles: Sequence[RoleProfile],
        *,
        now: datetime | None = None,
    ) -> list[MatchResult]:
        """Compute matches for many roles, best first.

        Ties break on evidence coverage so that, between two roles scoring 78,
        the one we understand better ranks higher.
        """
        results = [self.compute(candidate, role, now=now) for role in roles]
        return sorted(results, key=lambda r: (-r.index, -r.evidence_coverage, r.role_id))

    # -- internals ---------------------------------------------------------

    def _semantic_component(self, candidate: CandidateProfile, role: RoleProfile) -> ComponentScore:
        """fse -- semantic similarity between candidate evidence and role text."""
        weights = self.config.weights

        candidate_text = self._candidate_document(candidate)
        role_text = self._role_document(role)

        if not candidate_text.strip() or not role_text.strip():
            return ComponentScore(
                key="semantic",
                label="Semantic fit",
                weight=weights.semantic,
                status=ComponentStatus.NOT_ASSESSED,
                value=None,
                confidence=0.0,
                rationale=(
                    "There was not enough readable text on one side of the comparison "
                    "to measure semantic overlap."
                ),
                missing_evidence=("Parseable resume text", "A role description"),
            )

        result = semantic_similarity(
            candidate_text, role_text, provider=self.embedding_provider
        )

        # Embedding scores are already on [0, 1] after the affine map, but a
        # strong lexical match with rich shared vocabulary deserves its full
        # range; compression here would systematically penalise the fallback.
        value = clamp(result.score)

        rationale = (
            f"Comparison method: {result.method}. "
            + (
                f"The strongest shared concepts were {', '.join(result.shared_terms[:6])}."
                if result.shared_terms
                else "Similarity was measured over full-document embeddings."
            )
        )

        return ComponentScore(
            key="semantic",
            label="Semantic fit",
            weight=weights.semantic,
            status=ComponentStatus.ASSESSED,
            value=value,
            confidence=result.confidence,
            rationale=rationale,
            evidence=result.shared_terms,
            missing_evidence=(
                ("A richer role description would sharpen this measurement",)
                if len(role_text.split()) < 60
                else ()
            ),
        )

    @staticmethod
    def _candidate_document(candidate: CandidateProfile) -> str:
        """Flatten candidate evidence into one comparison document.

        Deliberately concatenates *evidence*, not just the skills list: a role
        asking for "distributed systems" should be findable in the candidate's
        project descriptions even if that exact phrase is nowhere in a skills
        list.
        """
        parts: list[str] = []
        if candidate.summary_text:
            parts.append(candidate.summary_text)
        parts.extend(s.skill_id.replace("-", " ") for s in candidate.skills)
        for exp in candidate.experiences:
            parts.append(f"{exp.title} {exp.description}")
        for edu in candidate.educations:
            parts.append(f"{edu.degree_name or ''} {edu.field_of_study or ''}")
        return "\n".join(p for p in parts if p)

    @staticmethod
    def _role_document(role: RoleProfile) -> str:
        parts = [role.title, role.description]
        parts.extend(r.canonical_name for r in role.requirements)
        parts.extend(r.category or "" for r in role.requirements)
        return "\n".join(p for p in parts if p)

    @staticmethod
    def _warnings(
        components: Sequence[ComponentScore],
        coverage: float,
        reportable: bool,
    ) -> list[str]:
        warnings: list[str] = []
        unassessed = [c for c in components if not c.is_assessed]
        for component in unassessed:
            missing = ", ".join(component.missing_evidence) or "more information"
            warnings.append(
                f"{component.label} could not be assessed. To include it: {missing}."
            )
        if not reportable:
            warnings.append(
                f"Only {coverage:.0%} of this match is backed by evidence, so the "
                "index is hidden until coverage improves. Adding the missing "
                "resume sections will fix this."
            )
        return warnings

    @staticmethod
    def _explain(
        components: Sequence[ComponentScore],
        index: float,
        coverage: float,
        reportable: bool,
    ) -> str:
        if not reportable:
            return (
                "There is not yet enough evidence to report a Career Match Index for "
                "this role. Resolve the warnings below and the index will appear. "
                "We would rather show you nothing than a number we cannot defend."
            )

        # Rank by *contribution to the shortfall*, not by raw value: the lowest
        # component is not necessarily the biggest opportunity if it carries a
        # small weight.
        gaps = sorted(
            (c for c in components if c.is_assessed and (c.value or 0.0) < 0.95),
            key=lambda c: (c.value or 0.0) * c.weight,
        )

        lead = f"Career Match Index {index:.1f}/100, based on {coverage:.0%} evidence coverage."
        if not gaps:
            return lead + " Every measurable term is at or near full fit for this role."

        worst = gaps[0]
        second = f" next is {gaps[1].label.lower()}" if len(gaps) > 1 else ""
        return (
            f"{lead} The largest lever is {worst.label.lower()} at "
            f"{(worst.value or 0.0):.0%}, worth up to "
            f"{worst.weight * 100 * (1 - (worst.value or 0.0)):.1f} index points;"
            f"{second}. Treat the index as a prioritisation signal, not a verdict."
        )


__all__ = ["CareerMatchCalculator"]
