"""Career Match Index and skill gap endpoints.

Transport-only: parse, delegate to the domain service, serialise. No scoring
logic lives here, which is what keeps the engines testable without a web server
and prevents "just a small tweak in the route" from becoming an untested change
to how candidates are measured.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from app.domain.matching.config import CareerMatchConfig
from app.domain.matching.index import CareerMatchCalculator
from app.domain.matching.types import (
    CandidateProfile,
    EducationRecord,
    ExperienceRecord,
    RoleProfile,
    RoleSkillRequirement,
    SkillEvidence,
)
from app.domain.skills.gap import SkillGapEngine
from app.schemas.matching import (
    CandidateProfileIn,
    GapAnalysisRequest,
    MatchManyRequest,
    MatchManyResultOut,
    MatchRequest,
    MatchResultOut,
    RoleProfileIn,
    SkillGapReportOut,
)

router = APIRouter(prefix="/matching", tags=["matching"])


# ---------------------------------------------------------------------------
# Dependency wiring
# ---------------------------------------------------------------------------
#
# Replaced at application startup with the config version resolved from the
# database. Declared as functions so tests can override them without patching
# module globals.


def get_match_config() -> CareerMatchConfig:
    return CareerMatchConfig()


def get_calculator(config: CareerMatchConfig = Depends(get_match_config)) -> CareerMatchCalculator:
    return CareerMatchCalculator(config=config)


def get_gap_engine(config: CareerMatchConfig = Depends(get_match_config)) -> SkillGapEngine:
    return SkillGapEngine(config=config)


# ---------------------------------------------------------------------------
# Mappers: wire -> domain
# ---------------------------------------------------------------------------


def to_candidate(payload: CandidateProfileIn) -> CandidateProfile:
    return CandidateProfile(
        skills=tuple(
            SkillEvidence(
                skill_id=item.skill_id,
                proficiency=item.proficiency,
                confidence=item.confidence,
                source=item.source,
                evidence=tuple(item.evidence),
                years_used=item.years_used,
            )
            for item in payload.skills
        ),
        educations=tuple(
            EducationRecord(
                level=item.level,
                degree_name=item.degree_name,
                institution=item.institution,
                field_of_study=item.field_of_study,
                start_year=item.start_year,
                end_year=item.end_year,
                grade=item.grade,
            )
            for item in payload.educations
        ),
        experiences=tuple(
            ExperienceRecord(
                title=item.title,
                company=item.company,
                start_date=item.start_date,
                end_date=item.end_date,
                is_current=item.is_current,
                description=item.description,
                skill_ids=tuple(item.skill_ids),
            )
            for item in payload.experiences
        ),
        summary_text=payload.summary_text,
        total_years_experience=payload.total_years_experience,
    )


def to_role(payload: RoleProfileIn) -> RoleProfile:
    return RoleProfile(
        role_id=payload.role_id,
        title=payload.title,
        requirements=tuple(
            RoleSkillRequirement(
                skill_id=item.skill_id,
                canonical_name=item.canonical_name,
                kind=item.kind,
                importance=item.importance,
                required_proficiency=item.required_proficiency,
                prep_hours_from_zero=item.prep_hours_from_zero,
                category=item.category,
                prerequisites=tuple(item.prerequisites),
                interview_relevant=item.interview_relevant,
            )
            for item in payload.requirements
        ),
        min_years_experience=payload.min_years_experience,
        max_years_experience=payload.max_years_experience,
        education_level=payload.education_level,
        seniority=payload.seniority,
        description=payload.description,
        company=payload.company,
        location=payload.location,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/match",
    response_model=MatchResultOut,
    summary="Compute the explainable Career Match Index for one role",
)
def match(
    payload: MatchRequest,
    calculator: CareerMatchCalculator = Depends(get_calculator),
) -> MatchResultOut:
    """Score a candidate against a role and explain every component.

    ``display_index`` is null when evidence coverage is below the configured
    floor. That is a deliberate outcome, not an error: the result still carries
    the component breakdown and the specific missing evidence, so the client
    can tell the candidate exactly what to add.
    """
    if payload.role.min_years_experience is not None and payload.role.max_years_experience is not None:
        if payload.role.min_years_experience > payload.role.max_years_experience:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="min_years_experience must not exceed max_years_experience",
            )

    result = calculator.compute(to_candidate(payload.candidate), to_role(payload.role))
    return MatchResultOut.model_validate(result.to_dict() | {"role_id": result.role_id})


@router.post(
    "/match-many",
    response_model=MatchManyResultOut,
    summary="Rank a candidate against many roles",
)
def match_many(
    payload: MatchManyRequest,
    calculator: CareerMatchCalculator = Depends(get_calculator),
) -> MatchManyResultOut:
    results = calculator.compute_many(
        to_candidate(payload.candidate),
        [to_role(role) for role in payload.roles],
    )[: payload.limit]

    return MatchManyResultOut(
        results=[
            MatchResultOut.model_validate(r.to_dict() | {"role_id": r.role_id}) for r in results
        ],
        count=len(results),
    )


@router.post(
    "/skill-gaps",
    response_model=SkillGapReportOut,
    summary="Generate the prioritised skill gap report and roadmap",
)
def skill_gaps(
    payload: GapAnalysisRequest,
    engine: SkillGapEngine = Depends(get_gap_engine),
) -> SkillGapReportOut:
    report = engine.analyse(to_candidate(payload.candidate), to_role(payload.role))
    return SkillGapReportOut.model_validate(report.to_dict())
