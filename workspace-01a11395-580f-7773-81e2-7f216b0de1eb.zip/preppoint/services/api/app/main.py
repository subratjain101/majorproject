"""PrepPoint API application.

Composition root and nothing else: build the app, wire routes, install
middleware. No business logic lives in this file, by design -- see
``app/domain`` for the engines and ``app/api/v1/routes`` for transport.
"""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1.routes import matching
from app.core.config import settings
from app.domain.evaluation.rubric import RUBRIC_VERSION
from app.domain.matching.config import CAREER_MATCH_CONFIG_VERSION
from app.schemas.matching import HealthOut

logger = logging.getLogger("preppoint.api")

API_VERSION = "0.1.0"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Startup and shutdown.

    Fails loudly on misconfiguration rather than starting in a half-working
    state, because a service that boots with a broken AI layer will be
    discovered by a candidate, not by an operator.
    """
    logger.info(
        "preppoint api starting",
        extra={
            "environment": settings.environment,
            "match_config_version": CAREER_MATCH_CONFIG_VERSION,
            "rubric_version": RUBRIC_VERSION,
            "ai_providers_configured": settings.configured_ai_providers(),
        },
    )
    if settings.is_production and not settings.ai_provider_available():
        logger.warning(
            "No AI provider is configured. Resume analysis and interview evaluation "
            "will run in degraded mode and will report scores as fallback results."
        )
    yield
    logger.info("preppoint api shutting down")


app = FastAPI(
    title="PrepPoint API",
    version=API_VERSION,
    description=(
        "Career intelligence, preparation and transparent recruitment API.\n\n"
        "Scoring is explainable by construction: every result carries the "
        "component breakdown, the evidence behind it, and the versioned "
        "configuration that produced it."
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

# CORS is an explicit allowlist. Wildcard origins with credentials are never
# acceptable in a platform that handles candidate documents.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
    max_age=600,
)


@app.middleware("http")
async def request_context(request: Request, call_next):
    """Attach a correlation id and emit a structured access log.

    The id is returned on the response and echoed in every log line for the
    request, so a candidate support ticket can be traced to the exact
    computation that produced their score.
    """
    request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    started = time.perf_counter()

    try:
        response = await call_next(request)
    except Exception:
        duration_ms = int((time.perf_counter() - started) * 1000)
        logger.exception(
            "unhandled error", extra={"request_id": request_id, "path": request.url.path, "duration_ms": duration_ms}
        )
        return JSONResponse(
            status_code=500,
            content={
                "detail": "An internal error occurred.",
                "request_id": request_id,
            },
            headers={"X-Request-ID": request_id},
        )

    duration_ms = int((time.perf_counter() - started) * 1000)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    logger.info(
        "request",
        extra={
            "request_id": request_id,
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_ms": duration_ms,
        },
    )
    return response


app.include_router(matching.router, prefix="/api/v1")


@app.get("/api/v1/health", response_model=HealthOut, tags=["system"])
def health() -> HealthOut:
    """Liveness plus the configuration versions actually in force.

    Reporting the active config version here means a deployment can be checked
    against the scores it is producing without reading the database.
    """
    return HealthOut(
        status="ok",
        version=API_VERSION,
        match_config_version=CAREER_MATCH_CONFIG_VERSION,
        rubric_version=RUBRIC_VERSION,
        ai_providers=settings.ai_status(),
    )


@app.get("/", include_in_schema=False)
def root() -> dict[str, str]:
    return {
        "service": "PrepPoint API",
        "version": API_VERSION,
        "docs": "/docs",
        "health": "/api/v1/health",
    }
