# syntax=docker/dockerfile:1.7
# =============================================================================
# PrepPoint sandbox runner
#
# Executes candidate code. Treated as hostile input at every layer:
#   - no network (enforced by the compose network, not here)
#   - read-only root filesystem (enforced by compose)
#   - no capabilities, no privilege escalation (enforced by compose)
#   - drops to an unprivileged user before running anything
# =============================================================================
FROM python:3.13-slim
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1
RUN apt-get update && \
    apt-get install --no-install-recommends -y curl && \
    rm -rf /var/lib/apt/lists/* && \
    useradd --create-home --uid 10003 --shell /usr/sbin/nologin runner
WORKDIR /app
COPY --chown=runner:runner services/sandbox/ /app/
USER runner
EXPOSE 8100
HEALTHCHECK --interval=30s --timeout=5s --retries=3 \
    CMD curl -fsS http://localhost:8100/health || exit 1
CMD ["python", "-m", "runner.server"]
