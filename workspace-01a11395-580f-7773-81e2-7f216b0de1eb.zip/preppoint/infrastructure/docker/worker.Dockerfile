# syntax=docker/dockerfile:1.7
# Background worker: resume processing, AI evaluation, moderation, notifications.
FROM python:3.13-slim AS builder
ENV PIP_NO_CACHE_DIR=1
WORKDIR /build
COPY services/api/requirements.txt .
RUN python -m venv /opt/venv && \
    /opt/venv/bin/pip install --upgrade pip wheel && \
    /opt/venv/bin/pip install -r requirements.txt

FROM python:3.13-slim AS runtime
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PATH="/opt/venv/bin:$PATH"
RUN useradd --create-home --uid 10002 --shell /usr/sbin/nologin preppoint
COPY --from=builder /opt/venv /opt/venv
WORKDIR /app
COPY --chown=preppoint:preppoint services/api/ /app/
COPY --chown=preppoint:preppoint services/worker/ /app/worker/
USER preppoint
# Long-running queue consumer. The entrypoint is intentionally a placeholder
# until the queue adapter is wired; see README "Status".
CMD ["python", "-m", "worker.main"]
