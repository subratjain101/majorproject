# The PrepPoint scoring model

Every number this platform shows a candidate must survive the question *"why
this number?"*. This document is the answer, written so that it can be checked
against the code — and the code is written so that this document can be checked
against it.

Everything here is **versioned configuration**, not hard-coded behaviour. The
active version string is persisted with every score, so a historical result can
always be replayed against the configuration that produced it.

| Component | Version constant | Location |
|---|---|---|
| Career Match Index | `cmi-2024.1` | `domain/matching/config.py` |
| Interview rubric | `interview-rubric-2024.1` | `domain/evaluation/rubric.py` |
| Evaluation prompt | `interview-eval-prompt-2024.1` | `domain/evaluation/rubric.py` |
| Scorecard schema | `scorecard-schema-1.0` | `schemas/` |

---

## 1. Career Match Index

```
M = 100 × min(1, 0.50·fsk + 0.25·fse + 0.15·fex + 0.10·fed)
```

Weights must sum to 1.0; `MatchWeights.__post_init__` raises otherwise, because
a zero-filled index that can exceed 100 is not a valid index.

### 1.1 `fsk` — skill fit (weight 0.50)

```
fsk = min(1, (|SC ∩ SR| + 0.5·|SC ∩ SP|) / |SR|)
```

`SC` candidate skills, `SR` required role skills, `SP` preferred role skills.

Two behaviours worth stating explicitly:

- **Default is the literal count formula.** A proficiency-weighted refinement
  exists (`partial_credit_enabled`) but is **off by default**, because enabling
  it changes what the published formula means. See `ASSUMPTIONS.md §2.2`.
- **A skill counts as matched only above the role's proficiency bar.**
  `threshold = max(min_proficiency, required_proficiency)`. This is not a
  deviation from the formula; it defines what "the candidate has this skill"
  means. Without it, the index degenerates into a keyword-density metric and
  every resume listing "Kubernetes" becomes a Kubernetes engineer.

If the role specifies no required skills, the term is `NOT_ASSESSED` — we do not
report 0/0 as 0%.

### 1.2 `fse` — semantic fit (weight 0.25)

With an embedding provider configured, cosine similarity over embeddings,
affinely mapped from `[-1, 1]` to `[0, 1]`. Without one, an offline blend:

```
fse = 0.60 × IDF-weighted_concept_coverage + 0.40 × TF-IDF_cosine
```

Why not cosine alone: cosine is symmetric and length-normalised, so a 40-word
resume against a 400-word posting shares every concept the role names and still
scores ~0.4. That bias is uniform across candidates, which compresses the term's
discriminative range and makes its 25% weight nearly decorative. The asymmetric
coverage term asks the question we actually want answered — *of the concepts the
role emphasises, how many appear in the candidate's evidence?*

The fallback reports `confidence = 0.62` and labels its method, so a degraded
measurement is never presented as an embedding-grade one.

### 1.3 `fex` — experience fit (weight 0.15)

Band-based, not a ratio:

| Situation | Value |
|---|---|
| Within `[min − tolerance, max + tolerance]` | 1.0 |
| Below the band | Linear decay to `shortfall_floor` (0.20) over `max_shortfall_years` (5) |
| Above the band | 1.0 (**default**), plus a warning |

A linear `candidate_years / required_years` punishes a 2-year candidate applying
for a 3-year role at 67% while simultaneously *rewarding* over-qualification
past 100%. Neither matches what a "fit" should mean. Over-qualification is
surfaced as context, not deducted — see `ASSUMPTIONS.md §2.1`.

Duration arithmetic merges overlapping roles rather than summing them, so two
concurrent two-year roles are two years of experience, not four. Every datetime
passing through a duration calculation is coerced to timezone-aware UTC
(`ensure_utc`), because resume dates are naive and generated timestamps are
aware — mixing them raises at runtime and would otherwise reach production.

### 1.4 `fed` — education fit (weight 0.10)

Ordinal, not interval: a B.Tech and an M.Tech are one step apart, not "two
points". Steps of shortfall map to fixed credits (1.0 / 0.6 / 0.3). Degree
labels are parsed conservatively and **never guessed upward** — guessing upward
flatters the candidate and corrupts the term.

### 1.5 Evidence coverage and the reporting gate

```python
coverage = Σ(wᵢ · confidenceᵢ) / Σ(wᵢ)     # over assessed components only
```

Coverage is **confidence-weighted**, not merely weight-presence. A term produced
from thin evidence counts for less than one backed by a full work history.

- The index is renormalised over assessed components: `Σ(wᵢ·fᵢ) / Σ(wᵢ)` for
  assessed `i`. A missing resume section costs confidence, not points.
- The spec-literal zero-filled value (`index_zero_filled`) is computed and stored
  for audit and comparison, and is never shown as the headline.
- Below `min_reportable_coverage` (0.60) the headline is withheld. The API
  returns `display_index: null` — **never 0** — so a client cannot render an
  indefensible number by forgetting to check a flag. The internal `index` remains
  available for ranking and admin views.

---

## 2. Skill gap severity

```
severity = kind_factor × importance × (0.35 + 0.65 × shortfall) × reason_factor
           + interview_bonus × (0.40 + 0.60 × shortfall)
```

then capped by requirement kind:

| Kind | `kind_factor` | Ceiling | Meaning |
|---|---|---|---|
| required | 1.0 | 1.00 | May be reported HIGH |
| preferred | 0.7 | 0.60 | **Can never be HIGH** |
| nice_to_have | 0.4 | 0.33 | **Can never be MEDIUM** |

The ceilings sit just below the band thresholds, which makes the guarantee exact
rather than approximate: retune any weight and the property still holds, because
it is enforced by `min()` rather than by multipliers happening to work out.

### The bug this formula replaced

The first version added a flat `+0.20 × kind_factor` for a skill being required.
Every required skill therefore cleared the HIGH threshold *regardless of gap
size*: a candidate 8% below the bar on an important skill (a four-hour fix) was
reported HIGH alongside a genuinely absent forty-hour skill. Severity was
measuring the shape of the job description rather than the candidate's
deficiency, which makes the whole report untrustworthy and trains people to
ignore it. Guarded by
`test_skill_gap.py::TestSeverityReflectsGapSize`.

### Reason codes

| Reason | Meaning | The remedy differs |
|---|---|---|
| `missing` | No evidence at all | Learn it |
| `weak_evidence` | Present but below the bar, or low confidence | Strengthen and document it |
| `undocumented` | Interview/practice shows it; resume does not | Add it to the resume |
| `strength` | Above the bar | Nothing — shown for balance |

Distinguishing *"you do not have this"* from *"you have this but we have weak
evidence"* is the single most useful thing a gap report can say. The remedies are
completely different, so the report never collapses them.

Roadmap ordering is topological over `prerequisites`, with a cycle guard — a
malformed taxonomy must degrade, not hang the worker.

---

## 3. Adaptive interview

```
E_t   = 1 / (1 + e^(−a(θ_t − d_t)))
θ_t+1 = clip(θ_t + η(s_t − E_t), 0, 1)
```

`θ` ability, `d_t` item difficulty, `s_t` observed score normalised to `[0,1]`,
`a` discrimination, `η` learning rate.

`E_t` is the expected score for a candidate of ability `θ` on an item of
difficulty `d_t`. When `θ >> d`, `E_t → 1` and a correct answer produces almost
no update — the model already knew. When `θ << d`, `E_t → 0` and even failure
barely moves `θ`. **The update is driven by surprise**, which is what makes it
adaptive rather than a running average.

| Parameter | Default | Rationale |
|---|---|---|
| `raise_threshold` | 7.8 | Asymmetric by design: the bar to escalate is higher than the bar to hold |
| `lower_threshold` | 5.0 | SRS-specified |
| `learning_rate` (η) | 0.28 | |
| `warmup_items` | 3 | Tempered to 0.8× and ramped, so one lucky answer cannot leap a difficulty band |

Difficulty transitions follow the SRS rules exactly, saturating at HARD and EASY.
An **unassessed** answer (insufficient evidence, §4) is recorded as seen but does
not update `θ` and does not change difficulty — a score we refused to fabricate
cannot be allowed to steer the interview.

Cold start blends toward the SRS piecewise estimate (mean difficulty attempted)
until `items_for_theta_confidence` items have accumulated, so behaviour does not
jump when the confidence threshold is crossed mid-session.

---

## 4. Evidence-linked evaluation

```
Overall = Σ(wₖ · Dₖ) / Σ(wₖ)     over assessed dimensions only
```

| Dimension | Weight |
|---|---|
| Technical correctness | 0.40 |
| Problem solving | 0.30 |
| Communication | 0.20 |
| Role relevance | 0.10 |

**The renormalisation is the feature.** Excluding an unassessable dimension and
redistributing its weight is what prevents *"we could not tell"* from silently
becoming *"you were average"* — the most common way AI interview tools mislead
candidates.

Honest side effect, documented in the UI rather than hidden: excluding a
*below-average* dimension raises the mean. That is true of any renormalisation.
It is exactly why evidence coverage is published alongside, and why the scorecard
shows the worked arithmetic.

Every dimension carries: score, weight, status, rationale, cited quotes, missing
rubric points, improvement, rubric version, and confidence. If `Σ assessed
weight < min_assessed_weight` (0.5) the overall is labelled `PARTIAL`.

### Prohibited inferences

The rubric's system guidance forbids inference of personality, emotion, health,
age, gender, or any protected attribute, and directs the model to cite the
specific phrases it relied on. Communication is judged on structure, ordering and
clarity — **never** accent, second-language grammar, speech rate, or emotional
tone. Structural tests assert that AI output shapes contain no control fields, so
model output cannot mutate permissions, roles, scores or moderation state.

### Degradation

Per SRS §17: validate → bounded retries → fall back to the next provider →
**safe degradation, never fabrication**. A degraded result carries
`is_fallback: true`, the failure reason, and the retry count. The candidate is
told the score is a fallback rather than being shown a number of unknown origin.
