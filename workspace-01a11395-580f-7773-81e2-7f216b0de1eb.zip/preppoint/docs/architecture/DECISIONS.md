# Architecture decision records

Decisions are recorded with their reasoning and the conditions that would
justify revisiting them. Statuses: **Accepted**, **Superseded**, **Proposed**.

---

## ADR-001 — Domain logic is framework-free, with no ORM or vendor SDK

**Status:** Accepted

**Context.** Scoring logic is the product. It must be testable, reviewable, and
reusable by the API, the worker and any future CLI or batch job. The baseline
repository mixed Flask routes, PyMongo calls and prompt strings in single files,
which made the scoring impossible to test without a database and a live API key.

**Decision.** `services/api/app/domain/**` imports no web framework, no ORM, no
vendor SDK and no HTTP client. Persistence models are mapped *to* domain types at
the repository boundary. Nothing in `domain/` knows what a database is.

**Consequences.**

- The whole scoring suite runs in ~3 seconds with no fixtures, database or
  network. 145 tests, no mocks in the domain layer.
- Business logic can be reused by the worker service without dragging FastAPI in.
- Requires explicit mappers at the repository boundary. Accepted as the cost of
  testability: a mapper is a smaller liability than an untestable engine.

---

## ADR-002 — PostgreSQL over MongoDB

**Status:** Accepted

**Context.** The baseline used MongoDB via PyMongo with no schema and no
migrations. The product brief mandates SQLAlchemy 2 and Alembic.

**Decision.** PostgreSQL with SQLAlchemy 2 and Alembic migrations.

**Consequences.** Versioned scoring, audit logs and consent records all need
transactions, foreign keys and point-in-time consistency — a candidate's
historical score must be provably tied to the resume version and rubric version
that produced it. Document-shaped data (parsed resume sections, AI payloads) is
stored in `JSONB` columns, so nothing is lost.

---

## ADR-003 — Scoring configuration is versioned data, never constants

**Status:** Accepted

**Context.** The brief requires that weights "must be configuration-driven" and
that scoring configuration/version be stored.

**Decision.** All weights, thresholds, curves and ceilings live in frozen
dataclasses in `domain/matching/config.py` and `domain/evaluation/rubric.py`.
Every result carries the `config_version` that produced it. `MatchWeights`
validates that weights sum to 1.0 at construction.

**Consequences.**

- A historical score can be replayed and defended.
- Changing behaviour requires a new version string, which makes scoring changes
  visible in review rather than buried in a diff.
- `compute()` accepts an explicit config, so tests and the admin console can
  compare versions.

---

## ADR-004 — An unreportable index is `null`, not `0`

**Status:** Accepted

**Context.** The brief requires the index not be displayed when evidence is
insufficient. A boolean flag plus a display convention leaves the door open for
any future client to print the raw number.

**Decision.** `MatchResult.display_index` returns `None` when coverage is below
the floor. `index` remains available for ranking and admin. The API returns
`display_index: null`.

**Consequences.** Rendering an indefensible score requires actively defeating the
type system rather than merely forgetting a check. `display_index: null` is now
part of the tested wire contract.

---

## ADR-005 — Over-qualification does not reduce experience fit

**Status:** Accepted

**Context.** A linear experience ratio would *reward* over-qualification past
100%. An early implementation deducted for it.

**Decision.** Experience fit saturates at 1.0. Over-qualification raises a
warning. A penalty exists behind `overqualification_penalty_enabled` and is off
by default.

**Consequences.** A candidate with twelve years is not marked down for applying
to a mid-level role. If a product owner wants the penalty, it is a config change
plus a version bump. See `ASSUMPTIONS.md §2.1`.

---

## ADR-006 — Severity is capped by requirement kind

**Status:** Accepted (supersedes the initial severity formula)

**Context.** The first severity formula added a flat bonus for a skill being
*required*, so every required skill cleared the HIGH threshold regardless of gap
size. A four-hour fix was reported with the same severity as a forty-hour gap.

**Decision.** `severity = kind_factor × importance × (0.35 + 0.65·shortfall) ×
reason_factor + interview_bonus·(...)`, capped so preferred skills cannot reach
HIGH and nice-to-have skills cannot reach MEDIUM.

**Consequences.** The ceilings are placed just below the band thresholds so the
guarantee is exact rather than incidental — retune any weight and the property
still holds. Guarded by `TestSeverityReflectsGapSize` and
`TestKindActsAsCeiling`.

---

## ADR-007 — Coverage is confidence-weighted

**Status:** Accepted (supersedes weight-presence coverage)

**Context.** Coverage was originally the fraction of total weight that produced
*any* value. A resume containing one listed skill reported 75% coverage and
published a headline match index off a single keyword.

**Decision.** `coverage = Σ(wᵢ · confidenceᵢ) / Σ(wᵢ)` over assessed terms.

**Consequences.** Thin evidence lowers coverage even when every term technically
produced a value. `min_reportable_coverage` was raised to 0.60 accordingly.
Regression-guarded by `test_low_coverage_hides_headline` and
`test_thin_evidence_costs_more_coverage_than_thick_evidence`.

---

## ADR-008 — Unassessed interview answers cannot steer the interview

**Status:** Accepted

**Context.** When evaluation returns `NOT_ASSESSED`, the adaptive engine must
decide what to do with that item.

**Decision.** The item is recorded as seen (for session history and item-repeat
prevention) but does not update `θ` and does not change difficulty.

**Consequences.** A score we refused to fabricate cannot influence the course of
the interview. This closes a subtle loop where a degradation in the evaluation
layer would silently reshape the assessment itself. Guarded by
`TestUnassessedItemsDoNotSteer`.

---

## ADR-009 — Redaction fails closed

**Status:** Accepted

**Context.** Redaction runs on the critical path between an uploaded resume and
an external model.

**Decision.** `redact_identifiers` catches its own errors, flags the result and
returns empty text. `assert_redaction_safe` raises. Call sites about to transmit
must call it.

**Consequences.** A redaction failure fails the pipeline run rather than leaking a
candidate's identity. An unavailable provider is recoverable; a privacy breach is
not.

---

## ADR-010 — The AI gateway never fabricates

**Status:** Accepted

**Context.** SRS §17 requires validation, retries, fallback and safe degradation.

**Decision.** One `AIGateway` implements the whole flow. It returns
`GatewayResult(value=None, degraded=True)` when every provider and attempt fails.
Schema violations are rejected, not clamped.

**Consequences.** Every call site gets the behaviour without re-implementing it,
and no call site can omit the final clause. Degraded results carry
`is_fallback`, failure reason and retry count to the scorecard.

---

## ADR-011 — Datetimes are coerced to timezone-aware UTC at the boundary

**Status:** Accepted

**Context.** A test failure during development: resume dates parse as naive
(`datetime(2019, 7, 1)`), generated timestamps are aware, and subtracting one
from the other raises `TypeError`. This reached a passing state only because the
happy-path fixture happened to be internally consistent.

**Decision.** `ensure_utc()` coerces every datetime entering a duration
calculation. Naive values are assumed UTC — resumes carry no timezone, and UTC is
the only choice that keeps whole-day arithmetic stable.

**Consequences.** Fixing it at the boundary rather than at call sites means the
next duration calculation cannot reintroduce it.

---

## ADR-012 — Difficulty adaptation is tempered through a warm-up

**Status:** Accepted

**Context.** With `η = 0.28`, a single strong answer can move `θ` far enough to
change the difficulty band, so the interview can feel like a different interview
after one lucky answer.

**Decision.** The learning rate ramps from 0.8× to full strength over
`warmup_items` (3). Cold start blends `θ` toward the SRS piecewise estimate until
`items_for_theta_confidence` items have accumulated.

**Consequences.** No visible behaviour change once a session is underway; the
first three updates are simply more conservative. Guarded by
`test_first_update_cannot_leap_across_bands`.

---

## ADR-013 — Semantic fit blends cosine with asymmetric concept coverage

**Status:** Accepted

**Context.** Symmetric TF-IDF cosine is length-biased. A short resume against a
long posting scored ~0.39 while every other term scored 83–100%, uniformly
depressing the headline and making the 25% weight nearly decorative.

**Decision.** 60% IDF-weighted concept coverage of the role's terms, 40% cosine.
An embedding provider, when configured, replaces the blend entirely.

**Consequences.** The term now discriminates between candidates instead of
applying a near-constant penalty. The fallback reports reduced confidence (0.62)
and labels its method, so a degraded measurement is never presented as an
embedding-grade one.

---

## ADR-014 — Server components by default on the web app

**Status:** Accepted

**Context.** The dashboard and scorecard are largely static, data-driven views.

**Decision.** Render on the server by default; opt into client components only
where interaction requires it (the interview runner, the application modal).

**Consequences.** These pages ship minimal JavaScript. Loading, empty and error
states are still designed for, because the data ultimately comes from the API.
