# Assumptions and extrapolations

This file exists because PrepPoint was specified in two parts — a pasted
product brief (§0–§20) and a set of source documents (SRS, technical PPT,
screenshots) — and **only the pasted brief was available when this code was
written.** The brief was also truncated mid-§20.

Rather than silently invent requirements, every decision that goes beyond the
written brief is recorded here with its reasoning and the conditions under
which it should be revisited.

Authority order used, as instructed:

| Source | Status |
|---|---|
| SRS document | **Not provided** — not used |
| Technical implementation PPT | **Not provided** — not used |
| Pasted brief §0–§20 | Authoritative, implemented as written |
| `BnoGaming/PrepPoint` baseline repo | Reference only; see below |
| Dashboard screenshots | **Not provided** — §5 written direction used instead |
| External research | Used for stack and architecture choices |

**If you supply the SRS, PPT or screenshots, re-check the items below against
them.** Anything marked ⚠ conflicts with a plausible reading of the missing
documents and should be verified first.

---

## 1. Baseline repository handling

The baseline is a Flask + MongoDB monolith: six flat Python files, Jinja2
templates, Bootstrap, one commit, no tests, no Docker, no migrations. It was
treated as a **domain reference, not a codebase to extend**. Concretely:

- **Kept as ideas:** the module split (resume analyser / aptitude / interviewer /
  speech interview / admin), the admin CRUD surface, the aptitude question-bank
  concept.
- **Replaced:** MongoDB → PostgreSQL + Alembic (the brief mandates SQLAlchemy 2
  and versioned scoring, neither of which suits a schemaless store); Jinja
  templates → Next.js; free-form Gemini prompts → schema-validated adapters.
- **⚠ Removed:** `speech_interview.py` used OpenCV Haar cascades for facial and
  "behaviour" tracking. This is deleted, not ported, because §2G forbids
  emotion/personality inference. **If the SRS explicitly requires behavioural
  analysis, this decision needs revisiting** — but it would then conflict with
  §2G and the conflict should be resolved by the product owner, not by us
  quietly keeping both.

---

## 2. Scoring decisions

### 2.1 Over-qualification does not reduce experience fit

`ExperienceFitConfig.overqualification_penalty_enabled` defaults to **False**.
A candidate with 12 years applying to a 3–7 year role scores 1.0 on experience
fit and receives a warning instead. Rationale: the published formula
`M = 100 × min(1, Σ wᵢfᵢ)` contains no over-qualification term, and penalising
someone for having *more* experience inside a term called "experience fit" is
hard to defend to the person affected.

*Revisit if:* the SRS specifies an explicit over-qualification penalty. The
flag exists so this is a one-line config change.

### 2.2 Skill fit defaults to the SRS count formula, not proficiency weighting

`SkillFitConfig.partial_credit_enabled` defaults to **False**, so `fsk` is
exactly `min(1, (|SC ∩ SR| + 0.5|SC ∩ SP|) / |SR|)` as written.

A proficiency-weighted refinement is implemented and tested but **off by
default**, because turning it on changes what the published formula means. It
should be enabled only as a deliberate, versioned product decision.

Note: even with partial credit off, a skill only counts as matched if its
evidenced proficiency clears the role's bar. This is *not* a deviation from the
formula — it is a definition of what "candidate has this skill" means. A
keyword with no proficiency estimate is not silently treated as mastery.

### 2.3 Coverage is confidence-weighted

The brief says the index must be renormalised over assessed components but does
not define "evidence coverage". We define it as
`Σ(wᵢ · confidenceᵢ) / Σ(wᵢ)`.

*Why:* a weight-presence definition let a resume containing a single listed
skill report 75% coverage and publish a headline index. Tests
`test_low_coverage_hides_headline` and
`test_thin_evidence_costs_more_coverage_than_thick_evidence` guard this.

### 2.4 `min_reportable_coverage` defaults to 0.60

The brief requires that an index "not be displayed" when coverage is
insufficient but does not give a number. 0.60 is our choice.

*Revisit if:* the SRS gives a threshold.

### 2.5 Semantic fit blends cosine with asymmetric concept coverage

The brief specifies a "semantic similarity" term (weight 0.25) without a
method. We blend TF-IDF cosine (40%) with IDF-weighted coverage of the role's
concepts (60%), weight 0.6/0.4.

*Why:* symmetric cosine is length-biased — a short resume against a long
posting scores ~0.4 even when it covers every concept the role names, dragging
every candidate down uniformly and compressing the term's discriminative range.
An embedding provider, when configured, replaces this entirely.

### 2.6 Severity caps by requirement kind

Severity is `kind_factor × importance × (0.35 + 0.65 × shortfall)`, capped so a
**preferred** skill can never reach HIGH and a **nice-to-have** can never reach
MEDIUM. This is not in the brief.

*Why:* the brief requires high/medium/low buckets but no formula. Our first
implementation produced false HIGHs (see `docs/architecture/DECISIONS.md`), and
the cap makes severity a statement about the candidate rather than about the
shape of the job description.

---

## 3. Architecture decisions not specified in the brief

| Decision | Choice | Reasoning |
|---|---|---|
| Database | PostgreSQL over MongoDB | The brief mandates SQLAlchemy 2 + Alembic; versioned scoring and audit logs need transactions and constraints |
| Resume storage | Object storage, never the DB | Uploads are large binaries with different retention and access needs |
| Sandbox isolation | Separate service, never in-process | §12 is explicit; also keeps the API pod free of a code-execution surface |
| Config resolution | `config_version` pinnable per request | Historical scores must replay against the config that produced them |
| Error shape | `display_index: null`, not `0` | Makes it impossible for a client to render an unreportable score by forgetting a flag |

---

## 4. Extrapolated sections (§21 onward)

The brief was truncated mid-§20. The following were derived from §0–20's stated
principles and **must be reviewed**:

- **Recruiter experience** — built as a separate RBAC role with role-scoped
  visibility, consent-gated, never seeing practice scores as a hiring signal.
  Derived from §2F, §2H.
- **Moderation** — company reviews and interview experiences queue for
  moderated approval with an appeal path and audit trail. Derived from §2I.
- **Admin console** — surfaces enumerated in §6; the brief lists nav entries but
  not their behaviour.
- **Voice interview** — STT/TTS behind adapter interfaces with documented
  fallbacks (STT failure → text; TTS failure → text question; provider failure
  → no fabricated score). Derived from §16 + §17.
- **Compliance posture** — consent records, data export, deletion-on-request,
  audit logging. Derived from §2G, §2H and the general responsibility framing.

---

## 5. Stack substitutions

Everything in §3 and §4 was honoured. Where a package was pinned to a version
that post-dates the brief, the version was chosen for security and support
reasons and is recorded in `package.json` / `requirements.txt`.

**Sandbox language support** beyond Python is specified as "extensible" in §12
but no language list is given. The runner is designed around a per-language
descriptor so adding a language is a data change, not a code change.
